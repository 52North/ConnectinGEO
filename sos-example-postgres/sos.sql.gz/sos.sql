--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

-- Started on 2016-11-17 14:56:44 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 1 (class 3079 OID 12361)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 4019 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- TOC entry 2 (class 3079 OID 18441)
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- TOC entry 4020 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- TOC entry 3 (class 3079 OID 19915)
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- TOC entry 4021 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 206 (class 1259 OID 20537)
-- Name: blobvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE blobvalue (
    observationid bigint NOT NULL,
    value oid
);


ALTER TABLE blobvalue OWNER TO postgres;

--
-- TOC entry 4022 (class 0 OID 0)
-- Dependencies: 206
-- Name: TABLE blobvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE blobvalue IS 'Value table for blob observation';


--
-- TOC entry 4023 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN blobvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN blobvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4024 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN blobvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN blobvalue.value IS 'Blob observation value';


--
-- TOC entry 207 (class 1259 OID 20542)
-- Name: booleanvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE booleanvalue (
    observationid bigint NOT NULL,
    value character(1),
    CONSTRAINT booleanvalue_value_check CHECK ((value = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT booleanvalue_value_check1 CHECK ((value = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE booleanvalue OWNER TO postgres;

--
-- TOC entry 4025 (class 0 OID 0)
-- Dependencies: 207
-- Name: TABLE booleanvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE booleanvalue IS 'Value table for boolean observation';


--
-- TOC entry 4026 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN booleanvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN booleanvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4027 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN booleanvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN booleanvalue.value IS 'Boolean observation value';


--
-- TOC entry 208 (class 1259 OID 20549)
-- Name: categoryvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE categoryvalue (
    observationid bigint NOT NULL,
    value character varying(255)
);


ALTER TABLE categoryvalue OWNER TO postgres;

--
-- TOC entry 4028 (class 0 OID 0)
-- Dependencies: 208
-- Name: TABLE categoryvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE categoryvalue IS 'Value table for category observation';


--
-- TOC entry 4029 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN categoryvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN categoryvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4030 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN categoryvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN categoryvalue.value IS 'Category observation value';


--
-- TOC entry 209 (class 1259 OID 20554)
-- Name: codespace; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE codespace (
    codespaceid bigint NOT NULL,
    codespace character varying(255) NOT NULL
);


ALTER TABLE codespace OWNER TO postgres;

--
-- TOC entry 4031 (class 0 OID 0)
-- Dependencies: 209
-- Name: TABLE codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE codespace IS 'Table to store the gml:identifier and gml:name codespace information. Mapping file: mapping/core/Codespace.hbm.xml';


--
-- TOC entry 4032 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN codespace.codespaceid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN codespace.codespaceid IS 'Table primary key, used for relations';


--
-- TOC entry 4033 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN codespace.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN codespace.codespace IS 'The codespace value';


--
-- TOC entry 238 (class 1259 OID 21060)
-- Name: codespaceid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE codespaceid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE codespaceid_seq OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 20559)
-- Name: compositephenomenon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE compositephenomenon (
    parentobservablepropertyid bigint NOT NULL,
    childobservablepropertyid bigint NOT NULL
);


ALTER TABLE compositephenomenon OWNER TO postgres;

--
-- TOC entry 4034 (class 0 OID 0)
-- Dependencies: 210
-- Name: TABLE compositephenomenon; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE compositephenomenon IS 'NOT YET USED! Relation table to store observableProperty hierarchies, aka compositePhenomenon. E.g. define a parent in a query and all childs are also contained in the response. Mapping file: mapping/transactional/TObservableProperty.hbm.xml';


--
-- TOC entry 4035 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN compositephenomenon.parentobservablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN compositephenomenon.parentobservablepropertyid IS 'Foreign Key (FK) to the related parent observableProperty. Contains "observableProperty".observablePropertyid';


--
-- TOC entry 4036 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN compositephenomenon.childobservablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN compositephenomenon.childobservablepropertyid IS 'Foreign Key (FK) to the related child observableProperty. Contains "observableProperty".observablePropertyid';


--
-- TOC entry 211 (class 1259 OID 20564)
-- Name: countvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE countvalue (
    observationid bigint NOT NULL,
    value integer
);


ALTER TABLE countvalue OWNER TO postgres;

--
-- TOC entry 4037 (class 0 OID 0)
-- Dependencies: 211
-- Name: TABLE countvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE countvalue IS 'Value table for count observation';


--
-- TOC entry 4038 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN countvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN countvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4039 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN countvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN countvalue.value IS 'Count observation value';


--
-- TOC entry 212 (class 1259 OID 20569)
-- Name: featureofinterest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featureofinterest (
    featureofinterestid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    featureofinteresttypeid bigint NOT NULL,
    identifier character varying(255),
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    geom geometry,
    descriptionxml text,
    url character varying(255)
);


ALTER TABLE featureofinterest OWNER TO postgres;

--
-- TOC entry 4040 (class 0 OID 0)
-- Dependencies: 212
-- Name: TABLE featureofinterest; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE featureofinterest IS 'Table to store the FeatureOfInterest information. Mapping file: mapping/core/FeatureOfInterest.hbm.xml';


--
-- TOC entry 4041 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.featureofinterestid IS 'Table primary key, used for relations';


--
-- TOC entry 4042 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.featureofinteresttypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.featureofinteresttypeid IS 'Relation/foreign key to the featureOfInterestType table. Describes the type of the featureOfInterest. Contains "featureOfInterestType".featureOfInterestTypeId';


--
-- TOC entry 4043 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.identifier IS 'The identifier of the featureOfInterest, gml:identifier. Used as parameter for queries. Optional but unique';


--
-- TOC entry 4044 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4045 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.name IS 'The name of the featureOfInterest, gml:name. Optional';


--
-- TOC entry 4046 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.codespacename IS 'The name of the featureOfInterest, gml:name. Optional';


--
-- TOC entry 4047 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.description IS 'Description of the featureOfInterest, gml:description. Optional';


--
-- TOC entry 4048 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.geom; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.geom IS 'The geometry of the featureOfInterest (composed of the “latitude” and “longitude”) . Optional';


--
-- TOC entry 4049 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.descriptionxml; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.descriptionxml IS 'XML description of the feature, used when transactional profile is supported . Optional';


--
-- TOC entry 4050 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.url IS 'Reference URL to the feature if it is stored in another service, e.g. WFS. Optional but unique';


--
-- TOC entry 239 (class 1259 OID 21062)
-- Name: featureofinterestid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featureofinterestid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featureofinterestid_seq OWNER TO postgres;

--
-- TOC entry 213 (class 1259 OID 20577)
-- Name: featureofinteresttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featureofinteresttype (
    featureofinteresttypeid bigint NOT NULL,
    featureofinteresttype character varying(255) NOT NULL
);


ALTER TABLE featureofinteresttype OWNER TO postgres;

--
-- TOC entry 4051 (class 0 OID 0)
-- Dependencies: 213
-- Name: TABLE featureofinteresttype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE featureofinteresttype IS 'Table to store the FeatureOfInterestType information. Mapping file: mapping/core/FeatureOfInterestType.hbm.xml';


--
-- TOC entry 4052 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN featureofinteresttype.featureofinteresttypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinteresttype.featureofinteresttypeid IS 'Table primary key, used for relations';


--
-- TOC entry 4053 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN featureofinteresttype.featureofinteresttype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinteresttype.featureofinteresttype IS 'The featureOfInterestType value, e.g. http://www.opengis.net/def/samplingFeatureType/OGC-OM/2.0/SF_SamplingPoint (OGC OM 2.0 specification) for point features';


--
-- TOC entry 240 (class 1259 OID 21064)
-- Name: featureofinteresttypeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featureofinteresttypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featureofinteresttypeid_seq OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 20582)
-- Name: featurerelation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featurerelation (
    parentfeatureid bigint NOT NULL,
    childfeatureid bigint NOT NULL
);


ALTER TABLE featurerelation OWNER TO postgres;

--
-- TOC entry 4054 (class 0 OID 0)
-- Dependencies: 214
-- Name: TABLE featurerelation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE featurerelation IS 'Relation table to store feature hierarchies. E.g. define a parent in a query and all childs are also contained in the response. Mapping file: mapping/transactional/TFeatureOfInterest.hbm.xml';


--
-- TOC entry 4055 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN featurerelation.parentfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featurerelation.parentfeatureid IS 'Foreign Key (FK) to the related parent featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 4056 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN featurerelation.childfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featurerelation.childfeatureid IS 'Foreign Key (FK) to the related child featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 215 (class 1259 OID 20587)
-- Name: geometryvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE geometryvalue (
    observationid bigint NOT NULL,
    value geometry
);


ALTER TABLE geometryvalue OWNER TO postgres;

--
-- TOC entry 4057 (class 0 OID 0)
-- Dependencies: 215
-- Name: TABLE geometryvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE geometryvalue IS 'Value table for geometry observation';


--
-- TOC entry 4058 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN geometryvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN geometryvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4059 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN geometryvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN geometryvalue.value IS 'Geometry observation value';


--
-- TOC entry 216 (class 1259 OID 20595)
-- Name: numericvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE numericvalue (
    observationid bigint NOT NULL,
    value double precision
);


ALTER TABLE numericvalue OWNER TO postgres;

--
-- TOC entry 4060 (class 0 OID 0)
-- Dependencies: 216
-- Name: TABLE numericvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE numericvalue IS 'Value table for numeric/Measurment observation';


--
-- TOC entry 4061 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN numericvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN numericvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4062 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN numericvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN numericvalue.value IS 'Numeric/Measurment observation value';


--
-- TOC entry 217 (class 1259 OID 20600)
-- Name: observableproperty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observableproperty (
    observablepropertyid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    identifier character varying(255) NOT NULL,
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    disabled character(1) DEFAULT 'F'::bpchar NOT NULL,
    CONSTRAINT observableproperty_disabled_check CHECK ((disabled = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE observableproperty OWNER TO postgres;

--
-- TOC entry 4063 (class 0 OID 0)
-- Dependencies: 217
-- Name: TABLE observableproperty; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observableproperty IS 'Table to store the ObservedProperty/Phenomenon information. Mapping file: mapping/core/ObservableProperty.hbm.xml';


--
-- TOC entry 4064 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.observablepropertyid IS 'Table primary key, used for relations';


--
-- TOC entry 4065 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.identifier IS 'The identifier of the observableProperty, gml:identifier. Used as parameter for queries. Unique';


--
-- TOC entry 4066 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4067 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.name IS 'The name of the observableProperty, gml:name. Optional';


--
-- TOC entry 4068 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.codespacename IS 'Relation/foreign key to the codespace table. Contains the gml:name codespace. Optional';


--
-- TOC entry 4069 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.description IS 'Description of the observableProperty, gml:description. Optional';


--
-- TOC entry 4070 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.disabled IS 'For later use by the SOS. Indicator if this observableProperty should not be provided by the SOS.';


--
-- TOC entry 241 (class 1259 OID 21066)
-- Name: observablepropertyid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observablepropertyid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observablepropertyid_seq OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 20610)
-- Name: observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observation (
    observationid bigint NOT NULL,
    seriesid bigint NOT NULL,
    phenomenontimestart timestamp without time zone NOT NULL,
    phenomenontimeend timestamp without time zone NOT NULL,
    resulttime timestamp without time zone NOT NULL,
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    validtimestart timestamp without time zone,
    validtimeend timestamp without time zone,
    samplinggeometry geometry,
    identifier character varying(255),
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    unitid bigint,
    CONSTRAINT observation_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE observation OWNER TO postgres;

--
-- TOC entry 4071 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE observation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observation IS 'Stores the observations. Mapping file: mapping/series/observation/SeriesObservation.hbm.xml';


--
-- TOC entry 4072 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.identifier IS 'The identifier of the observation, gml:identifier. Used as parameter for queries. Optional but unique';


--
-- TOC entry 4073 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4074 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.name IS 'The name of the observation, gml:name. Optional';


--
-- TOC entry 4075 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.codespacename IS 'The name of the observation, gml:name. Optional';


--
-- TOC entry 4076 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.description IS 'Description of the observation, gml:description. Optional';


--
-- TOC entry 4077 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.unitid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.unitid IS 'Foreign Key (FK) to the related unit of measure. Contains "unit".unitid. Optional';


--
-- TOC entry 219 (class 1259 OID 20620)
-- Name: observationconstellation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observationconstellation (
    observationconstellationid bigint NOT NULL,
    observablepropertyid bigint NOT NULL,
    procedureid bigint NOT NULL,
    observationtypeid bigint,
    offeringid bigint NOT NULL,
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    hiddenchild character(1) DEFAULT 'F'::bpchar NOT NULL,
    CONSTRAINT observationconstellation_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT observationconstellation_hiddenchild_check CHECK ((hiddenchild = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE observationconstellation OWNER TO postgres;

--
-- TOC entry 4078 (class 0 OID 0)
-- Dependencies: 219
-- Name: TABLE observationconstellation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observationconstellation IS 'Table to store the ObservationConstellation information. Contains information about the constellation of observableProperty, procedure, offering and the observationType. Mapping file: mapping/core/ObservationConstellation.hbm.xml';


--
-- TOC entry 4079 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.observationconstellationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.observationconstellationid IS 'Table primary key, used for relations';


--
-- TOC entry 4080 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.observablepropertyid IS 'Foreign Key (FK) to the related observableProperty. Contains "observableproperty".observablepropertyid';


--
-- TOC entry 4081 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureid';


--
-- TOC entry 4082 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.observationtypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.observationtypeid IS 'Foreign Key (FK) to the related observableProperty. Contains "observationtype".observationtypeid';


--
-- TOC entry 4083 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.offeringid IS 'Foreign Key (FK) to the related observableProperty. Contains "offering".offeringid';


--
-- TOC entry 4084 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.deleted IS 'Flag to indicate that this observationConstellation is deleted or not. Set if the related procedure is deleted via DeleteSensor operation (OGC SWES 2.0 - DeleteSensor operation)';


--
-- TOC entry 4085 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.hiddenchild; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.hiddenchild IS 'Flag to indicate that this observationConstellations procedure is a child procedure of another procedure. If true, the related procedure is not contained in OGC SOS 2.0 Capabilities but in OGC SOS 1.0.0 Capabilities.';


--
-- TOC entry 242 (class 1259 OID 21068)
-- Name: observationconstellationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observationconstellationid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observationconstellationid_seq OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 20629)
-- Name: observationhasoffering; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observationhasoffering (
    observationid bigint NOT NULL,
    offeringid bigint NOT NULL
);


ALTER TABLE observationhasoffering OWNER TO postgres;

--
-- TOC entry 4086 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE observationhasoffering; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observationhasoffering IS 'Table to store relations between observation and associated offerings. Mapping file: mapping/ereporting/EReportingObservation.hbm.xml';


--
-- TOC entry 243 (class 1259 OID 21070)
-- Name: observationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observationid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observationid_seq OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 20634)
-- Name: observationtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observationtype (
    observationtypeid bigint NOT NULL,
    observationtype character varying(255) NOT NULL
);


ALTER TABLE observationtype OWNER TO postgres;

--
-- TOC entry 4087 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE observationtype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observationtype IS 'Table to store the observationTypes. Mapping file: mapping/core/ObservationType.hbm.xml';


--
-- TOC entry 4088 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN observationtype.observationtypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationtype.observationtypeid IS 'Table primary key, used for relations';


--
-- TOC entry 4089 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN observationtype.observationtype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationtype.observationtype IS 'The observationType value, e.g. http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement (OGC OM 2.0 specification) for OM_Measurement';


--
-- TOC entry 244 (class 1259 OID 21072)
-- Name: observationtypeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observationtypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observationtypeid_seq OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 20639)
-- Name: offering; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offering (
    offeringid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    identifier character varying(255) NOT NULL,
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    disabled character(1) DEFAULT 'F'::bpchar NOT NULL,
    CONSTRAINT offering_disabled_check CHECK ((disabled = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE offering OWNER TO postgres;

--
-- TOC entry 4090 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE offering; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offering IS 'Table to store the offering information. Mapping file: mapping/core/Offering.hbm.xml';


--
-- TOC entry 4091 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.offeringid IS 'Table primary key, used for relations';


--
-- TOC entry 4092 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.identifier IS 'The identifier of the offering, gml:identifier. Used as parameter for queries. Unique';


--
-- TOC entry 4093 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4094 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.name IS 'The name of the offering, gml:name. If available, displyed in the contents of the Capabilites. Optional';


--
-- TOC entry 4095 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.codespacename IS 'Relation/foreign key to the codespace table. Contains the gml:name codespace. Optional';


--
-- TOC entry 4096 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.description IS 'Description of the offering, gml:description. Optional';


--
-- TOC entry 4097 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.disabled IS 'For later use by the SOS. Indicator if this offering should not be provided by the SOS.';


--
-- TOC entry 223 (class 1259 OID 20649)
-- Name: offeringallowedfeaturetype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offeringallowedfeaturetype (
    offeringid bigint NOT NULL,
    featureofinteresttypeid bigint NOT NULL
);


ALTER TABLE offeringallowedfeaturetype OWNER TO postgres;

--
-- TOC entry 4098 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE offeringallowedfeaturetype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offeringallowedfeaturetype IS 'Table to store relations between offering and allowed featureOfInterestTypes, defined in InsertSensor request. Mapping file: mapping/transactional/TOffering.hbm.xml';


--
-- TOC entry 4099 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN offeringallowedfeaturetype.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedfeaturetype.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 4100 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN offeringallowedfeaturetype.featureofinteresttypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedfeaturetype.featureofinteresttypeid IS 'Foreign Key (FK) to the related featureOfInterestTypeId. Contains "featureOfInterestType".featureOfInterestTypeId';


--
-- TOC entry 224 (class 1259 OID 20654)
-- Name: offeringallowedobservationtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offeringallowedobservationtype (
    offeringid bigint NOT NULL,
    observationtypeid bigint NOT NULL
);


ALTER TABLE offeringallowedobservationtype OWNER TO postgres;

--
-- TOC entry 4101 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE offeringallowedobservationtype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offeringallowedobservationtype IS 'Table to store relations between offering and allowed observationTypes, defined in InsertSensor request. Mapping file: mapping/transactional/TOffering.hbm.xml';


--
-- TOC entry 4102 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN offeringallowedobservationtype.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedobservationtype.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 4103 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN offeringallowedobservationtype.observationtypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedobservationtype.observationtypeid IS 'Foreign Key (FK) to the related observationType. Contains "observationType".observationTypeId';


--
-- TOC entry 225 (class 1259 OID 20659)
-- Name: offeringhasrelatedfeature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offeringhasrelatedfeature (
    relatedfeatureid bigint NOT NULL,
    offeringid bigint NOT NULL
);


ALTER TABLE offeringhasrelatedfeature OWNER TO postgres;

--
-- TOC entry 4104 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE offeringhasrelatedfeature; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offeringhasrelatedfeature IS 'Table to store relations between offering and associated relatedFeatures. Mapping file: mapping/transactional/TOffering.hbm.xml';


--
-- TOC entry 4105 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN offeringhasrelatedfeature.relatedfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringhasrelatedfeature.relatedfeatureid IS 'Foreign Key (FK) to the related relatedFeature. Contains "relatedFeature".relatedFeatureid';


--
-- TOC entry 4106 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN offeringhasrelatedfeature.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringhasrelatedfeature.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 245 (class 1259 OID 21074)
-- Name: offeringid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE offeringid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE offeringid_seq OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 20664)
-- Name: parameter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE parameter (
    parameterid bigint NOT NULL,
    observationid bigint NOT NULL,
    definition character varying(255) NOT NULL,
    title character varying(255),
    value oid NOT NULL
);


ALTER TABLE parameter OWNER TO postgres;

--
-- TOC entry 4107 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE parameter; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE parameter IS 'NOT YET USED! Table to store additional obervation information (om:parameter). Mapping file: mapping/transactional/Parameter.hbm.xml';


--
-- TOC entry 4108 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.parameterid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.parameterid IS 'Table primary key';


--
-- TOC entry 4109 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.observationid IS 'Foreign Key (FK) to the related observation. Contains "observation".observationid';


--
-- TOC entry 4110 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.definition; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.definition IS 'Definition of the additional information';


--
-- TOC entry 4111 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.title IS 'optional title of the additional information. Optional';


--
-- TOC entry 4112 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.value IS 'Value of the additional information';


--
-- TOC entry 246 (class 1259 OID 21076)
-- Name: parameterid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE parameterid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE parameterid_seq OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 21078)
-- Name: procdescformatid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE procdescformatid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procdescformatid_seq OWNER TO postgres;

--
-- TOC entry 205 (class 1259 OID 20523)
-- Name: procedure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE procedure (
    procedureid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    proceduredescriptionformatid bigint NOT NULL,
    identifier character varying(255) NOT NULL,
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    disabled character(1) DEFAULT 'F'::bpchar NOT NULL,
    descriptionfile text,
    referenceflag character(1) DEFAULT 'F'::bpchar,
    CONSTRAINT procedure_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT procedure_disabled_check CHECK ((disabled = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT procedure_referenceflag_check CHECK ((referenceflag = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE procedure OWNER TO postgres;

--
-- TOC entry 4113 (class 0 OID 0)
-- Dependencies: 205
-- Name: TABLE procedure; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE procedure IS 'Table to store the procedure/sensor. Mapping file: mapping/core/Procedure.hbm.xml';


--
-- TOC entry 4114 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.procedureid IS 'Table primary key, used for relations';


--
-- TOC entry 4115 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.proceduredescriptionformatid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.proceduredescriptionformatid IS 'Relation/foreign key to the procedureDescriptionFormat table. Describes the format of the procedure description.';


--
-- TOC entry 4116 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.identifier IS 'The identifier of the procedure, gml:identifier. Used as parameter for queries. Unique';


--
-- TOC entry 4117 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4118 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.name IS 'The name of the procedure, gml:name. Optional';


--
-- TOC entry 4119 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.codespacename IS 'Relation/foreign key to the codespace table. Contains the gml:name codespace. Optional';


--
-- TOC entry 4120 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.description IS 'Description of the procedure, gml:description. Optional';


--
-- TOC entry 4121 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.deleted IS 'Flag to indicate that this procedure is deleted or not (OGC SWES 2.0 - DeleteSensor operation)';


--
-- TOC entry 4122 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.disabled IS 'For later use by the SOS. Indicator if this procedure should not be provided by the SOS.';


--
-- TOC entry 4123 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.descriptionfile; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.descriptionfile IS 'Field for full (XML) encoded procedure description or link to a procedure description file. Optional';


--
-- TOC entry 4124 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.referenceflag; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.referenceflag IS 'Flag to indicate that this procedure is a reference procedure of another procedure. Not used by the SOS but by the Sensor Web REST-API';


--
-- TOC entry 227 (class 1259 OID 20672)
-- Name: proceduredescriptionformat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE proceduredescriptionformat (
    proceduredescriptionformatid bigint NOT NULL,
    proceduredescriptionformat character varying(255) NOT NULL
);


ALTER TABLE proceduredescriptionformat OWNER TO postgres;

--
-- TOC entry 4125 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE proceduredescriptionformat; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE proceduredescriptionformat IS 'Table to store the ProcedureDescriptionFormat information of procedures. Mapping file: mapping/core/ProcedureDescriptionFormat.hbm.xml';


--
-- TOC entry 4126 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN proceduredescriptionformat.proceduredescriptionformatid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN proceduredescriptionformat.proceduredescriptionformatid IS 'Table primary key, used for relations';


--
-- TOC entry 4127 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN proceduredescriptionformat.proceduredescriptionformat; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN proceduredescriptionformat.proceduredescriptionformat IS 'The procedureDescriptionFormat value, e.g. http://www.opengis.net/sensorML/1.0.1 for procedures descriptions as specified in OGC SensorML 1.0.1';


--
-- TOC entry 248 (class 1259 OID 21080)
-- Name: procedureid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE procedureid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procedureid_seq OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 20677)
-- Name: relatedfeature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE relatedfeature (
    relatedfeatureid bigint NOT NULL,
    featureofinterestid bigint NOT NULL
);


ALTER TABLE relatedfeature OWNER TO postgres;

--
-- TOC entry 4128 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE relatedfeature; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE relatedfeature IS 'Table to store related feature information used in the OGC SOS 2.0 Capabilities (See also OGC SWES 2.0). Mapping file: mapping/transactionl/RelatedFeature.hbm.xml';


--
-- TOC entry 4129 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN relatedfeature.relatedfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeature.relatedfeatureid IS 'Table primary key, used for relations';


--
-- TOC entry 4130 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN relatedfeature.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeature.featureofinterestid IS 'Foreign Key (FK) to the related featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 229 (class 1259 OID 20682)
-- Name: relatedfeaturehasrole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE relatedfeaturehasrole (
    relatedfeatureid bigint NOT NULL,
    relatedfeatureroleid bigint NOT NULL
);


ALTER TABLE relatedfeaturehasrole OWNER TO postgres;

--
-- TOC entry 4131 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE relatedfeaturehasrole; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE relatedfeaturehasrole IS 'Relation table to store relatedFeatures and their associated relatedFeatureRoles. Mapping file: mapping/transactionl/RelatedFeature.hbm.xml';


--
-- TOC entry 4132 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN relatedfeaturehasrole.relatedfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturehasrole.relatedfeatureid IS 'Foreign Key (FK) to the related relatedFeature. Contains "relatedFeature".relatedFeatureid';


--
-- TOC entry 4133 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN relatedfeaturehasrole.relatedfeatureroleid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturehasrole.relatedfeatureroleid IS 'Foreign Key (FK) to the related relatedFeatureRole. Contains "relatedFeatureRole".relatedFeatureRoleid';


--
-- TOC entry 249 (class 1259 OID 21082)
-- Name: relatedfeatureid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE relatedfeatureid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE relatedfeatureid_seq OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 20687)
-- Name: relatedfeaturerole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE relatedfeaturerole (
    relatedfeatureroleid bigint NOT NULL,
    relatedfeaturerole character varying(255) NOT NULL
);


ALTER TABLE relatedfeaturerole OWNER TO postgres;

--
-- TOC entry 4134 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE relatedfeaturerole; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE relatedfeaturerole IS 'Table to store related feature role information used in the OGC SOS 2.0 Capabilities (See also OGC SWES 2.0). Mapping file: mapping/transactionl/RelatedFeatureRole.hbm.xml';


--
-- TOC entry 4135 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN relatedfeaturerole.relatedfeatureroleid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturerole.relatedfeatureroleid IS 'Table primary key, used for relations';


--
-- TOC entry 4136 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN relatedfeaturerole.relatedfeaturerole; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturerole.relatedfeaturerole IS 'The related feature role definition. See OGC SWES 2.0 specification';


--
-- TOC entry 250 (class 1259 OID 21084)
-- Name: relatedfeatureroleid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE relatedfeatureroleid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE relatedfeatureroleid_seq OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 20692)
-- Name: resulttemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE resulttemplate (
    resulttemplateid bigint NOT NULL,
    offeringid bigint NOT NULL,
    observablepropertyid bigint NOT NULL,
    procedureid bigint NOT NULL,
    featureofinterestid bigint NOT NULL,
    identifier character varying(255) NOT NULL,
    resultstructure text NOT NULL,
    resultencoding text NOT NULL
);


ALTER TABLE resulttemplate OWNER TO postgres;

--
-- TOC entry 4137 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE resulttemplate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE resulttemplate IS 'Table to store resultTemplates (OGC SOS 2.0 result handling profile). Mapping file: mapping/transactionl/ResultTemplate.hbm.xml';


--
-- TOC entry 4138 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.resulttemplateid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.resulttemplateid IS 'Table primary key';


--
-- TOC entry 4139 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 4140 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.observablepropertyid IS 'Foreign Key (FK) to the related observableProperty. Contains "observableProperty".observablePropertyId';


--
-- TOC entry 4141 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureId';


--
-- TOC entry 4142 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.featureofinterestid IS 'Foreign Key (FK) to the related featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 4143 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.identifier IS 'The resultTemplate identifier, required for InsertResult requests.';


--
-- TOC entry 4144 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.resultstructure; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.resultstructure IS 'The resultStructure as XML string. Describes the types and order of the values in a GetResultResponse/InsertResultRequest';


--
-- TOC entry 4145 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.resultencoding; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.resultencoding IS 'The resultEncoding as XML string. Describes the encoding of the values in a GetResultResponse/InsertResultRequest';


--
-- TOC entry 251 (class 1259 OID 21086)
-- Name: resulttemplateid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE resulttemplateid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE resulttemplateid_seq OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 20700)
-- Name: sensorsystem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE sensorsystem (
    parentsensorid bigint NOT NULL,
    childsensorid bigint NOT NULL
);


ALTER TABLE sensorsystem OWNER TO postgres;

--
-- TOC entry 4146 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE sensorsystem; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE sensorsystem IS 'Relation table to store procedure hierarchies. E.g. define a parent in a query and all childs are also contained in the response. Mapping file: mapping/transactional/TProcedure.hbm.xml';


--
-- TOC entry 4147 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN sensorsystem.parentsensorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN sensorsystem.parentsensorid IS 'Foreign Key (FK) to the related parent procedure. Contains "procedure".procedureid';


--
-- TOC entry 4148 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN sensorsystem.childsensorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN sensorsystem.childsensorid IS 'Foreign Key (FK) to the related child procedure. Contains "procedure".procedureid';


--
-- TOC entry 233 (class 1259 OID 20705)
-- Name: series; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE series (
    seriesid bigint NOT NULL,
    featureofinterestid bigint NOT NULL,
    observablepropertyid bigint NOT NULL,
    procedureid bigint NOT NULL,
    offeringid bigint,
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    published character(1) DEFAULT 'T'::bpchar NOT NULL,
    firsttimestamp timestamp without time zone,
    lasttimestamp timestamp without time zone,
    firstnumericvalue double precision,
    lastnumericvalue double precision,
    unitid bigint,
    CONSTRAINT series_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT series_published_check CHECK ((published = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE series OWNER TO postgres;

--
-- TOC entry 4149 (class 0 OID 0)
-- Dependencies: 233
-- Name: TABLE series; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE series IS 'Table to store a (time-) series which consists of featureOfInterest, observableProperty, and procedure. Mapping file: mapping/series/Series.hbm.xml';


--
-- TOC entry 4150 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.seriesid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.seriesid IS 'Table primary key, used for relations';


--
-- TOC entry 4151 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.featureofinterestid IS 'Foreign Key (FK) to the related featureOfInterest. Contains "featureOfInterest".featureOfInterestId';


--
-- TOC entry 4152 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.observablepropertyid IS 'Foreign Key (FK) to the related observableProperty. Contains "observableproperty".observablepropertyid';


--
-- TOC entry 4153 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureid';


--
-- TOC entry 4154 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.offeringid IS 'Foreign Key (FK) to the related procedure. Contains "offering".offeringid';


--
-- TOC entry 4155 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.deleted IS 'Flag to indicate that this series is deleted or not. Set if the related procedure is deleted via DeleteSensor operation (OGC SWES 2.0 - DeleteSensor operation)';


--
-- TOC entry 4156 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.published; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.published IS 'Flag to indicate that this series is published or not. A not published series is not contained in GetObservation and GetDataAvailability responses';


--
-- TOC entry 4157 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.firsttimestamp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.firsttimestamp IS 'The time stamp of the first (temporal) observation associated to this series';


--
-- TOC entry 4158 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.lasttimestamp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.lasttimestamp IS 'The time stamp of the last (temporal) observation associated to this series';


--
-- TOC entry 4159 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.firstnumericvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.firstnumericvalue IS 'The value of the first (temporal) observation associated to this series';


--
-- TOC entry 4160 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.lastnumericvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.lastnumericvalue IS 'The value of the last (temporal) observation associated to this series';


--
-- TOC entry 4161 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.unitid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.unitid IS 'Foreign Key (FK) to the related unit of the first/last numeric values . Contains "unit".unitid';


--
-- TOC entry 252 (class 1259 OID 21088)
-- Name: seriesid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE seriesid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seriesid_seq OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 20714)
-- Name: swedataarrayvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE swedataarrayvalue (
    observationid bigint NOT NULL,
    value text
);


ALTER TABLE swedataarrayvalue OWNER TO postgres;

--
-- TOC entry 4162 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE swedataarrayvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE swedataarrayvalue IS 'Value table for SweDataArray observation';


--
-- TOC entry 4163 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN swedataarrayvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN swedataarrayvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4164 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN swedataarrayvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN swedataarrayvalue.value IS 'SweDataArray observation value';


--
-- TOC entry 235 (class 1259 OID 20722)
-- Name: textvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE textvalue (
    observationid bigint NOT NULL,
    value text
);


ALTER TABLE textvalue OWNER TO postgres;

--
-- TOC entry 4165 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE textvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE textvalue IS 'Value table for text observation';


--
-- TOC entry 4166 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN textvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN textvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4167 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN textvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN textvalue.value IS 'Text observation value';


--
-- TOC entry 236 (class 1259 OID 20730)
-- Name: unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE unit (
    unitid bigint NOT NULL,
    unit character varying(255) NOT NULL
);


ALTER TABLE unit OWNER TO postgres;

--
-- TOC entry 4168 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE unit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE unit IS 'Table to store the unit of measure information, used in observations. Mapping file: mapping/core/Unit.hbm.xml';


--
-- TOC entry 4169 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN unit.unitid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN unit.unitid IS 'Table primary key, used for relations';


--
-- TOC entry 4170 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN unit.unit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN unit.unit IS 'The unit of measure of observations. See http://unitsofmeasure.org/ucum.html';


--
-- TOC entry 253 (class 1259 OID 21090)
-- Name: unitid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE unitid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE unitid_seq OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 20735)
-- Name: validproceduretime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE validproceduretime (
    validproceduretimeid bigint NOT NULL,
    procedureid bigint NOT NULL,
    proceduredescriptionformatid bigint NOT NULL,
    starttime timestamp without time zone NOT NULL,
    endtime timestamp without time zone,
    descriptionxml text NOT NULL
);


ALTER TABLE validproceduretime OWNER TO postgres;

--
-- TOC entry 4171 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE validproceduretime; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE validproceduretime IS 'Table to store procedure descriptions which were inserted or updated via the transactional Profile. Mapping file: mapping/transactionl/ValidProcedureTime.hbm.xml';


--
-- TOC entry 4172 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.validproceduretimeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.validproceduretimeid IS 'Table primary key';


--
-- TOC entry 4173 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureid';


--
-- TOC entry 4174 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.proceduredescriptionformatid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.proceduredescriptionformatid IS 'Foreign Key (FK) to the related procedureDescriptionFormat. Contains "procedureDescriptionFormat".procedureDescriptionFormatid';


--
-- TOC entry 4175 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.starttime; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.starttime IS 'Timestamp since this procedure description is valid';


--
-- TOC entry 4176 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.endtime; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.endtime IS 'Timestamp since this procedure description is invalid';


--
-- TOC entry 4177 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.descriptionxml; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.descriptionxml IS 'Procedure description as XML string';


--
-- TOC entry 254 (class 1259 OID 21092)
-- Name: validproceduretimeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE validproceduretimeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE validproceduretimeid_seq OWNER TO postgres;

--
-- TOC entry 3963 (class 0 OID 20537)
-- Dependencies: 206
-- Data for Name: blobvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blobvalue (observationid, value) FROM stdin;
\.


--
-- TOC entry 3964 (class 0 OID 20542)
-- Dependencies: 207
-- Data for Name: booleanvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY booleanvalue (observationid, value) FROM stdin;
\.


--
-- TOC entry 3965 (class 0 OID 20549)
-- Dependencies: 208
-- Data for Name: categoryvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY categoryvalue (observationid, value) FROM stdin;
\.


--
-- TOC entry 3966 (class 0 OID 20554)
-- Dependencies: 209
-- Data for Name: codespace; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY codespace (codespaceid, codespace) FROM stdin;
1	http://www.opengis.net/def/nil/OGC/0/unknown
\.


--
-- TOC entry 4178 (class 0 OID 0)
-- Dependencies: 238
-- Name: codespaceid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('codespaceid_seq', 1, true);


--
-- TOC entry 3967 (class 0 OID 20559)
-- Dependencies: 210
-- Data for Name: compositephenomenon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY compositephenomenon (parentobservablepropertyid, childobservablepropertyid) FROM stdin;
\.


--
-- TOC entry 3968 (class 0 OID 20564)
-- Dependencies: 211
-- Data for Name: countvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY countvalue (observationid, value) FROM stdin;
\.


--
-- TOC entry 3969 (class 0 OID 20569)
-- Dependencies: 212
-- Data for Name: featureofinterest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featureofinterest (featureofinterestid, hibernatediscriminator, featureofinteresttypeid, identifier, codespace, name, codespacename, description, geom, descriptionxml, url) FROM stdin;
1	T	2	wxt520	1	wxt520	1	\N	0101000020E6100000FEFFFF3F089C1E40FAFFFFBFA6F74940	\N	\N
\.


--
-- TOC entry 4179 (class 0 OID 0)
-- Dependencies: 239
-- Name: featureofinterestid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featureofinterestid_seq', 1, true);


--
-- TOC entry 3970 (class 0 OID 20577)
-- Dependencies: 213
-- Data for Name: featureofinteresttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featureofinteresttype (featureofinteresttypeid, featureofinteresttype) FROM stdin;
1	http://www.opengis.net/def/samplingFeatureType/OGC-OM/2.0/SF_SamplingPoint
2	http://www.opengis.net/def/nil/OGC/0/unknown
\.


--
-- TOC entry 4180 (class 0 OID 0)
-- Dependencies: 240
-- Name: featureofinteresttypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featureofinteresttypeid_seq', 2, true);


--
-- TOC entry 3971 (class 0 OID 20582)
-- Dependencies: 214
-- Data for Name: featurerelation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featurerelation (parentfeatureid, childfeatureid) FROM stdin;
\.


--
-- TOC entry 3972 (class 0 OID 20587)
-- Dependencies: 215
-- Data for Name: geometryvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY geometryvalue (observationid, value) FROM stdin;
\.


--
-- TOC entry 3973 (class 0 OID 20595)
-- Dependencies: 216
-- Data for Name: numericvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY numericvalue (observationid, value) FROM stdin;
1	12.5
2	12.5
3	15.9000000000000004
4	16.8000000000000007
5	16.6000000000000014
6	13.1999999999999993
7	13.5999999999999996
8	11.5999999999999996
9	12
10	9.80000000000000071
11	10.0999999999999996
12	13.4000000000000004
13	11.4000000000000004
14	10.6999999999999993
15	16.5
16	17.1999999999999993
17	13.6999999999999993
18	13.9000000000000004
19	11.1999999999999993
20	10.3000000000000007
21	10.9000000000000004
22	11.9000000000000004
23	6.79999999999999982
24	11.5
25	11.5
26	14
27	12.6999999999999993
28	9.59999999999999964
29	7.59999999999999964
30	7
31	6.90000000000000036
32	8
33	9.30000000000000071
34	9.40000000000000036
35	11.1999999999999993
36	11.5
37	10.5999999999999996
38	10.8000000000000007
39	10.5
40	10.9000000000000004
41	10.5999999999999996
42	10.8000000000000007
43	11.5
44	14.5999999999999996
45	13.5999999999999996
46	13.8000000000000007
47	12.1999999999999993
48	11.6999999999999993
49	10.3000000000000007
50	8.30000000000000071
51	6.79999999999999982
52	8.69999999999999929
53	13.5999999999999996
54	14
55	12.5999999999999996
56	12.1999999999999993
57	8.09999999999999964
58	9.19999999999999929
59	9.09999999999999964
60	5.79999999999999982
61	4.79999999999999982
62	6.79999999999999982
63	11.6999999999999993
64	13.6999999999999993
65	11.8000000000000007
66	9.09999999999999964
67	9
68	5.5
69	3.89999999999999991
70	5.90000000000000036
71	6.70000000000000018
72	8.30000000000000071
73	8
74	9.69999999999999929
75	10
76	9.90000000000000036
77	9.30000000000000071
78	8.19999999999999929
79	7.70000000000000018
80	7.79999999999999982
81	6.59999999999999964
82	7.5
83	10.4000000000000004
84	12.8000000000000007
85	13.8000000000000007
86	11.5
87	8.80000000000000071
88	13
89	12.1999999999999993
90	13.6999999999999993
91	13.4000000000000004
92	8.5
93	8.30000000000000071
94	5.90000000000000036
95	4.70000000000000018
96	4.20000000000000018
97	8.69999999999999929
98	16.5
99	19.3000000000000007
100	18.1999999999999993
101	12.0999999999999996
102	9.69999999999999929
103	9.90000000000000036
104	8.69999999999999929
105	9.69999999999999929
106	9.40000000000000036
107	13.0999999999999996
108	15.4000000000000004
109	15.0999999999999996
110	13.4000000000000004
111	11.0999999999999996
112	8.59999999999999964
113	9.19999999999999929
114	7.20000000000000018
115	7.90000000000000036
116	6.90000000000000036
117	11.0999999999999996
118	9.40000000000000036
119	10.0999999999999996
120	9.09999999999999964
121	8.19999999999999929
122	8.19999999999999929
123	7.09999999999999964
124	6.70000000000000018
125	6.59999999999999964
126	7.70000000000000018
127	9.19999999999999929
128	8
129	7.70000000000000018
130	8.19999999999999929
131	8.09999999999999964
132	8.69999999999999929
133	8.30000000000000071
134	7.59999999999999964
135	7.5
136	9.40000000000000036
137	9.69999999999999929
138	9
139	8.09999999999999964
140	5.20000000000000018
141	4.70000000000000018
142	2.70000000000000018
143	2.29999999999999982
144	2.29999999999999982
145	5
146	9.5
147	10.6999999999999993
148	6.79999999999999982
149	6.90000000000000036
150	5.70000000000000018
151	5.59999999999999964
152	5.79999999999999982
153	6.5
154	7.09999999999999964
155	9.30000000000000071
156	9
157	9.69999999999999929
158	9.5
159	9.30000000000000071
160	9.40000000000000036
161	9.09999999999999964
162	8.69999999999999929
163	8.5
164	10
165	10.5999999999999996
166	12.9000000000000004
167	12.5999999999999996
168	11.9000000000000004
169	11.3000000000000007
170	11.1999999999999993
171	12
172	12
173	7.70000000000000018
174	8.30000000000000071
175	14.9000000000000004
176	14.0999999999999996
177	15
178	8.80000000000000071
179	7.5
180	8
181	7.79999999999999982
182	6.79999999999999982
183	6.09999999999999964
184	7.70000000000000018
185	13.9000000000000004
186	13.0999999999999996
187	13.3000000000000007
188	11
189	9.40000000000000036
190	9.80000000000000071
191	10.1999999999999993
192	9
193	10.4000000000000004
194	15.5999999999999996
195	16.3999999999999986
196	13.9000000000000004
197	10.6999999999999993
198	7.90000000000000036
199	6.90000000000000036
200	6.79999999999999982
201	12.5
202	12.5999999999999996
203	16.8000000000000007
204	17.6999999999999993
205	17.1000000000000014
206	13.1999999999999993
207	13.5999999999999996
208	11.5999999999999996
209	11.9000000000000004
210	9.80000000000000071
211	10.0999999999999996
212	13.6999999999999993
213	11.5
214	10.9000000000000004
215	18.1000000000000014
216	17.8999999999999986
217	13.8000000000000007
218	13.8000000000000007
219	11.5999999999999996
220	10.4000000000000004
221	11.5
222	12
223	6.79999999999999982
224	12.4000000000000004
225	11.8000000000000007
226	14.8000000000000007
227	13.4000000000000004
228	9.69999999999999929
229	7.70000000000000018
230	7
231	7
232	7.90000000000000036
233	9.5
234	9.80000000000000071
235	11.5
236	11.8000000000000007
237	10.6999999999999993
238	10.9000000000000004
239	10.6999999999999993
240	11
241	10.8000000000000007
242	11
243	11.8000000000000007
244	15.1999999999999993
245	14
246	14.4000000000000004
247	12.5
248	11.9000000000000004
249	10.4000000000000004
250	8.40000000000000036
251	6.79999999999999982
252	10.6999999999999993
253	14.8000000000000007
254	15.4000000000000004
255	12.9000000000000004
256	12.5999999999999996
257	8.09999999999999964
258	9.30000000000000071
259	9.19999999999999929
260	5.79999999999999982
261	4.90000000000000036
262	7.09999999999999964
263	13.9000000000000004
264	15.3000000000000007
265	12.0999999999999996
266	9.19999999999999929
267	9.19999999999999929
268	5.59999999999999964
269	4
270	5.90000000000000036
271	6.79999999999999982
272	8.59999999999999964
273	8.19999999999999929
274	10
275	10.1999999999999993
276	10.0999999999999996
277	9.5
278	8.80000000000000071
279	7.70000000000000018
280	7.90000000000000036
281	6.70000000000000018
282	7.79999999999999982
283	12.3000000000000007
284	13.5
285	14
286	11.6999999999999993
287	8.90000000000000036
288	13.0999999999999996
289	12.4000000000000004
290	13.9000000000000004
291	13.9000000000000004
292	8.59999999999999964
293	8.30000000000000071
294	6
295	4.70000000000000018
296	4.40000000000000036
297	8.59999999999999964
298	17.6000000000000014
299	20.8000000000000007
300	18.1999999999999993
301	12.0999999999999996
302	9.59999999999999964
303	10
304	8.80000000000000071
305	9.80000000000000071
306	9.40000000000000036
307	13.5
308	15.8000000000000007
309	15.4000000000000004
310	13.5999999999999996
311	11.1999999999999993
312	8.69999999999999929
313	9.19999999999999929
314	7.20000000000000018
315	8
316	6.90000000000000036
317	12.3000000000000007
318	9.80000000000000071
319	10.3000000000000007
320	8.80000000000000071
321	8.19999999999999929
322	8.30000000000000071
323	7.20000000000000018
324	7.40000000000000036
325	6.79999999999999982
326	7.59999999999999964
327	9.5
328	8.40000000000000036
329	7.70000000000000018
330	8.19999999999999929
331	8.19999999999999929
332	8.80000000000000071
333	8.19999999999999929
334	7.70000000000000018
335	7.70000000000000018
336	10.0999999999999996
337	10.1999999999999993
338	9.40000000000000036
339	8.30000000000000071
340	5.29999999999999982
341	5
342	2.89999999999999991
343	2.39999999999999991
344	2.5
345	5.5
346	11.1999999999999993
347	11.5999999999999996
348	7
349	7
350	5.79999999999999982
351	5.59999999999999964
352	5.90000000000000036
353	6.59999999999999964
354	7.29999999999999982
355	9.09999999999999964
356	9.69999999999999929
357	9.90000000000000036
358	9.59999999999999964
359	9.59999999999999964
360	9.5
361	9.19999999999999929
362	8.90000000000000036
363	8.69999999999999929
364	10.0999999999999996
365	10.5999999999999996
366	13.1999999999999993
367	12.9000000000000004
368	12.0999999999999996
369	11.4000000000000004
370	11.3000000000000007
371	12.1999999999999993
372	12.0999999999999996
373	7.79999999999999982
374	9.09999999999999964
375	15.3000000000000007
376	15.6999999999999993
377	15.8000000000000007
378	11.3000000000000007
379	8.09999999999999964
380	7.29999999999999982
381	7.90000000000000036
382	6.90000000000000036
383	6.20000000000000018
384	8
385	14.5999999999999996
386	13.5999999999999996
387	11.6999999999999993
388	10.4000000000000004
389	9.5
390	9.90000000000000036
391	10.3000000000000007
392	9.09999999999999964
393	11.0999999999999996
394	16.8999999999999986
395	18.1000000000000014
396	14
397	10.8000000000000007
398	8.09999999999999964
399	7
400	6.79999999999999982
401	85
402	85.2000000000000028
403	79.5999999999999943
404	66.7000000000000028
405	65.5999999999999943
406	83.7999999999999972
407	82.5999999999999943
408	90.5999999999999943
409	87.0999999999999943
410	90.0999999999999943
411	84.7999999999999972
412	68.9000000000000057
413	86.2999999999999972
414	90
415	84.7000000000000028
416	57.7000000000000028
417	82.0999999999999943
418	87.7999999999999972
419	90.2999999999999972
420	91.9000000000000057
421	92.0999999999999943
422	89
423	81.7000000000000028
424	62.7000000000000028
425	58.7000000000000028
426	45.3999999999999986
427	49.2000000000000028
428	60.6000000000000014
429	66.2999999999999972
430	75.2000000000000028
431	76.5999999999999943
432	71.7999999999999972
433	68.0999999999999943
434	74.2999999999999972
435	72.2999999999999972
436	75
437	83.7000000000000028
438	82.2000000000000028
439	85.2000000000000028
440	83.0999999999999943
441	84.5999999999999943
442	83
443	80.9000000000000057
444	65.9000000000000057
445	65.2000000000000028
446	76.2000000000000028
447	78.0999999999999943
448	83.5999999999999943
449	87.2000000000000028
450	81.7999999999999972
451	89.5999999999999943
452	83
453	57.2999999999999972
454	46.1000000000000014
455	49.6000000000000014
456	62.1000000000000014
457	78.7999999999999972
458	77.2000000000000028
459	78.5
460	88.5999999999999943
461	91.0999999999999943
462	86.4000000000000057
463	51.5
464	48.7999999999999972
465	57.8999999999999986
466	75.0999999999999943
467	77
468	88.5
469	86.7999999999999972
470	89.7999999999999972
471	84.4000000000000057
472	77.2000000000000028
473	80.9000000000000057
474	72.9000000000000057
475	74.9000000000000057
476	70.5
477	71.7999999999999972
478	79.4000000000000057
479	81
480	80.2999999999999972
481	83.5999999999999943
482	78.2999999999999972
483	61.2999999999999972
484	57.8999999999999986
485	59
486	68
487	88.2999999999999972
488	82.0999999999999943
489	89.7000000000000028
490	82.2000000000000028
491	88.9000000000000057
492	92.0999999999999943
493	91.2999999999999972
494	91.7000000000000028
495	90.9000000000000057
496	92.2999999999999972
497	89.5999999999999943
498	60.2999999999999972
499	48.7000000000000028
500	54.7000000000000028
501	79.0999999999999943
502	85.2000000000000028
503	83.5
504	88.5
505	87.7999999999999972
506	92.2000000000000028
507	88.2999999999999972
508	59.1000000000000014
509	57
510	66
511	88.7000000000000028
512	91.5999999999999943
513	86.5999999999999943
514	83.7000000000000028
515	89.2000000000000028
516	91
517	69.0999999999999943
518	80.5999999999999943
519	73.0999999999999943
520	86.7999999999999972
521	89.2999999999999972
522	89.5
523	89.4000000000000057
524	84.7999999999999972
525	87.4000000000000057
526	83.4000000000000057
527	76
528	87.2999999999999972
529	90.5
530	90.5
531	91.7999999999999972
532	90.7000000000000028
533	90.5999999999999943
534	89.5999999999999943
535	88.4000000000000057
536	76.0999999999999943
537	73.7000000000000028
538	79.9000000000000057
539	80
540	89.4000000000000057
541	91.5
542	93
543	93.4000000000000057
544	93.5999999999999943
545	92.5
546	73.9000000000000057
547	70.7000000000000028
548	85.2999999999999972
549	81.9000000000000057
550	87.2000000000000028
551	88.5999999999999943
552	89.2999999999999972
553	88.2999999999999972
554	86.5999999999999943
555	90.2000000000000028
556	85.2999999999999972
557	87.0999999999999943
558	85.0999999999999943
559	88.7000000000000028
560	89.5
561	89.7999999999999972
562	89.7999999999999972
563	87.9000000000000057
564	90
565	89.2999999999999972
566	82.2999999999999972
567	81.0999999999999943
568	80.5999999999999943
569	82.5
570	86.9000000000000057
571	85.5999999999999943
572	83.2000000000000028
573	85.7000000000000028
574	92.5999999999999943
575	61.2999999999999972
576	54.7999999999999972
577	54.7999999999999972
578	83.2999999999999972
579	87
580	88.7999999999999972
581	89
582	91
583	91.5
584	89.4000000000000057
585	69.0999999999999943
586	68.9000000000000057
587	82.5
588	87.2000000000000028
589	88.7000000000000028
590	85.7999999999999972
591	83.4000000000000057
592	87.4000000000000057
593	78.5999999999999943
594	57.8999999999999986
595	55.1000000000000014
596	60.2000000000000028
597	85.5
598	90.5
599	89.2000000000000028
600	90
601	1003.20000000000005
602	1002.79999999999995
603	1002.60000000000002
604	1000.70000000000005
605	1000.20000000000005
606	1001
607	1002
608	1001.60000000000002
609	1002.10000000000002
610	1001.79999999999995
611	1002.29999999999995
612	1002.79999999999995
613	1003.5
614	1014.89999999999998
615	1016.89999999999998
616	1018.20000000000005
617	1018.70000000000005
618	1019.70000000000005
619	1022.60000000000002
620	1023.20000000000005
621	1024.20000000000005
622	1025
623	1025.59999999999991
624	1028.40000000000009
625	1028.09999999999991
626	1025.79999999999995
627	1024.40000000000009
628	1023.29999999999995
629	1023.20000000000005
630	1021.79999999999995
631	1019.79999999999995
632	1018.70000000000005
633	1018.5
634	1017.70000000000005
635	1016.20000000000005
636	1016.10000000000002
637	1016.10000000000002
638	1016.10000000000002
639	1015.5
640	1015
641	1014.20000000000005
642	1014.10000000000002
643	1014.79999999999995
644	1014.60000000000002
645	1013.60000000000002
646	1013.79999999999995
647	1014.70000000000005
648	1014.79999999999995
649	1015.39999999999998
650	1015.20000000000005
651	1015.89999999999998
652	1016.70000000000005
653	1017.29999999999995
654	1017
655	1017.20000000000005
656	1018.10000000000002
657	1018.70000000000005
658	1018.60000000000002
659	1018.20000000000005
660	1018.10000000000002
661	1018.5
662	1017.70000000000005
663	1017.5
664	1015.79999999999995
665	1015.5
666	1016
667	1015.89999999999998
668	1015.5
669	1015.10000000000002
670	1014.5
671	1013.60000000000002
672	1014.60000000000002
673	1012.60000000000002
674	1011.89999999999998
675	1010.89999999999998
676	1009.10000000000002
677	1008.89999999999998
678	1008.10000000000002
679	1007.29999999999995
680	1006.79999999999995
681	1004.5
682	1004
683	1003.10000000000002
684	1002.20000000000005
685	1000.89999999999998
686	1000.10000000000002
687	999.5
688	1002.39999999999998
689	1004.70000000000005
690	1007.20000000000005
691	1008.60000000000002
692	1010.70000000000005
693	1011.29999999999995
694	1012.29999999999995
695	1012.89999999999998
696	1012.89999999999998
697	1013.89999999999998
698	1014
699	1013.20000000000005
700	1012.79999999999995
701	1013.10000000000002
702	1013.5
703	1013.20000000000005
704	1012.39999999999998
705	1012.20000000000005
706	1013.79999999999995
707	1013.5
708	1013
709	1009.79999999999995
710	1008.79999999999995
711	1009.29999999999995
712	1009.5
713	1007.5
714	1006.79999999999995
715	1005.79999999999995
716	1005.60000000000002
717	1005.89999999999998
718	1005.5
719	1006
720	1006.5
721	1006.79999999999995
722	1007.5
723	1007.70000000000005
724	1007.5
725	1008.10000000000002
726	1008.20000000000005
727	1007.10000000000002
728	1006.70000000000005
729	1006
730	1005.89999999999998
731	1005.39999999999998
732	1005.20000000000005
733	1005
734	1005.5
735	1006.60000000000002
736	1007
737	1007.10000000000002
738	1007.29999999999995
739	1007.89999999999998
740	1008.10000000000002
741	1007.79999999999995
742	1007.79999999999995
743	1007.10000000000002
744	1007
745	1007.60000000000002
746	1006.89999999999998
747	1005.60000000000002
748	1006.20000000000005
749	1005.70000000000005
750	1006.29999999999995
751	1006.10000000000002
752	1006.10000000000002
753	1006.79999999999995
754	1012.70000000000005
755	1014.5
756	1015.89999999999998
757	1016.60000000000002
758	1017.79999999999995
759	1019.60000000000002
760	1020.10000000000002
761	1019.89999999999998
762	1020.5
763	1020.39999999999998
764	1023.39999999999998
765	1024.70000000000005
766	1024.90000000000009
767	1025.09999999999991
768	1024.29999999999995
769	1024.70000000000005
770	1023.70000000000005
771	1024.20000000000005
772	1022.5
773	1022.29999999999995
774	1027.5
775	1027.70000000000005
776	1026.09999999999991
777	1025.70000000000005
778	1025.79999999999995
779	1025.29999999999995
780	1025.70000000000005
781	1024.79999999999995
782	1024.20000000000005
783	1023.39999999999998
784	1025
785	1024.09999999999991
786	1023.29999999999995
787	1023.10000000000002
788	1023.79999999999995
789	1023.79999999999995
790	1023.29999999999995
791	1022.20000000000005
792	1021.89999999999998
793	1022.5
794	1022
795	1020.89999999999998
796	1020.29999999999995
797	1019.70000000000005
798	1019.60000000000002
799	1018.70000000000005
800	1017.5
\.


--
-- TOC entry 3974 (class 0 OID 20600)
-- Dependencies: 217
-- Data for Name: observableproperty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY observableproperty (observablepropertyid, hibernatediscriminator, identifier, codespace, name, codespacename, description, disabled) FROM stdin;
1	F	AirTemperature	1	\N	1	\N	F
2	F	AthmosphericPressure	1	\N	1	\N	F
3	F	Humidity	1	\N	1	\N	F
4	F	InSystemTemperature	1	\N	1	\N	F
\.


--
-- TOC entry 4181 (class 0 OID 0)
-- Dependencies: 241
-- Name: observablepropertyid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observablepropertyid_seq', 4, true);


--
-- TOC entry 3975 (class 0 OID 20610)
-- Dependencies: 218
-- Data for Name: observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY observation (observationid, seriesid, phenomenontimestart, phenomenontimeend, resulttime, deleted, validtimestart, validtimeend, samplinggeometry, identifier, codespace, name, codespacename, description, unitid) FROM stdin;
1	1	2016-10-01 06:31:54	2016-10-01 06:31:54	2016-10-01 06:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
2	1	2016-10-01 07:16:54	2016-10-01 07:16:54	2016-10-01 07:16:54	F	\N	\N	\N	\N	1	\N	1	\N	1
3	1	2016-10-01 11:16:54	2016-10-01 11:16:54	2016-10-01 11:16:54	F	\N	\N	\N	\N	1	\N	1	\N	1
4	1	2016-10-01 13:46:53	2016-10-01 13:46:53	2016-10-01 13:46:53	F	\N	\N	\N	\N	1	\N	1	\N	1
5	1	2016-10-01 16:01:53	2016-10-01 16:01:53	2016-10-01 16:01:53	F	\N	\N	\N	\N	1	\N	1	\N	1
6	1	2016-10-01 18:46:53	2016-10-01 18:46:53	2016-10-01 18:46:53	F	\N	\N	\N	\N	1	\N	1	\N	1
7	1	2016-10-01 20:31:52	2016-10-01 20:31:52	2016-10-01 20:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
8	1	2016-10-01 22:01:52	2016-10-01 22:01:52	2016-10-01 22:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
9	1	2016-10-02 00:16:52	2016-10-02 00:16:52	2016-10-02 00:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
10	1	2016-10-02 05:01:52	2016-10-02 05:01:52	2016-10-02 05:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
11	1	2016-10-02 06:31:48	2016-10-02 06:31:48	2016-10-02 06:31:48	F	\N	\N	\N	\N	1	\N	1	\N	1
12	1	2016-10-02 09:01:48	2016-10-02 09:01:48	2016-10-02 09:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
13	1	2016-10-02 11:01:48	2016-10-02 11:01:48	2016-10-02 11:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
14	1	2016-10-03 06:46:52	2016-10-03 06:46:52	2016-10-03 06:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
15	1	2016-10-03 11:31:52	2016-10-03 11:31:52	2016-10-03 11:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
16	1	2016-10-03 13:31:52	2016-10-03 13:31:52	2016-10-03 13:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
17	1	2016-10-03 15:46:51	2016-10-03 15:46:51	2016-10-03 15:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
18	1	2016-10-03 16:46:51	2016-10-03 16:46:51	2016-10-03 16:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
19	1	2016-10-03 20:31:51	2016-10-03 20:31:51	2016-10-03 20:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
20	1	2016-10-03 22:46:51	2016-10-03 22:46:51	2016-10-03 22:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
21	1	2016-10-04 00:31:50	2016-10-04 00:31:50	2016-10-04 00:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
22	1	2016-10-04 05:01:50	2016-10-04 05:01:50	2016-10-04 05:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
23	1	2016-10-05 06:31:53	2016-10-05 06:31:53	2016-10-05 06:31:53	F	\N	\N	\N	\N	1	\N	1	\N	1
24	1	2016-10-05 10:01:53	2016-10-05 10:01:53	2016-10-05 10:01:53	F	\N	\N	\N	\N	1	\N	1	\N	1
25	1	2016-10-05 11:46:53	2016-10-05 11:46:53	2016-10-05 11:46:53	F	\N	\N	\N	\N	1	\N	1	\N	1
26	1	2016-10-05 13:31:53	2016-10-05 13:31:53	2016-10-05 13:31:53	F	\N	\N	\N	\N	1	\N	1	\N	1
27	1	2016-10-05 16:16:52	2016-10-05 16:16:52	2016-10-05 16:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
28	1	2016-10-05 19:16:52	2016-10-05 19:16:52	2016-10-05 19:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
29	1	2016-10-05 22:16:52	2016-10-05 22:16:52	2016-10-05 22:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
30	1	2016-10-05 23:16:52	2016-10-05 23:16:52	2016-10-05 23:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
31	1	2016-10-06 03:31:51	2016-10-06 03:31:51	2016-10-06 03:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
32	1	2016-10-06 05:16:51	2016-10-06 05:16:51	2016-10-06 05:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
33	1	2016-10-06 09:01:50	2016-10-06 09:01:50	2016-10-06 09:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
34	1	2016-10-06 10:46:49	2016-10-06 10:46:49	2016-10-06 10:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
35	1	2016-10-06 13:16:49	2016-10-06 13:16:49	2016-10-06 13:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
36	1	2016-10-06 15:32:01	2016-10-06 15:32:01	2016-10-06 15:32:01	F	\N	\N	\N	\N	1	\N	1	\N	1
37	1	2016-10-06 17:17:01	2016-10-06 17:17:01	2016-10-06 17:17:01	F	\N	\N	\N	\N	1	\N	1	\N	1
38	1	2016-10-06 19:17:00	2016-10-06 19:17:00	2016-10-06 19:17:00	F	\N	\N	\N	\N	1	\N	1	\N	1
39	1	2016-10-06 23:32:00	2016-10-06 23:32:00	2016-10-06 23:32:00	F	\N	\N	\N	\N	1	\N	1	\N	1
40	1	2016-10-07 00:47:00	2016-10-07 00:47:00	2016-10-07 00:47:00	F	\N	\N	\N	\N	1	\N	1	\N	1
41	1	2016-10-07 02:47:00	2016-10-07 02:47:00	2016-10-07 02:47:00	F	\N	\N	\N	\N	1	\N	1	\N	1
42	1	2016-10-07 07:46:47	2016-10-07 07:46:47	2016-10-07 07:46:47	F	\N	\N	\N	\N	1	\N	1	\N	1
43	1	2016-10-07 10:01:47	2016-10-07 10:01:47	2016-10-07 10:01:47	F	\N	\N	\N	\N	1	\N	1	\N	1
44	1	2016-10-07 12:16:46	2016-10-07 12:16:46	2016-10-07 12:16:46	F	\N	\N	\N	\N	1	\N	1	\N	1
45	1	2016-10-07 14:01:46	2016-10-07 14:01:46	2016-10-07 14:01:46	F	\N	\N	\N	\N	1	\N	1	\N	1
46	1	2016-10-07 16:16:46	2016-10-07 16:16:46	2016-10-07 16:16:46	F	\N	\N	\N	\N	1	\N	1	\N	1
47	1	2016-10-07 18:46:46	2016-10-07 18:46:46	2016-10-07 18:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
48	1	2016-10-07 22:31:45	2016-10-07 22:31:45	2016-10-07 22:31:45	F	\N	\N	\N	\N	1	\N	1	\N	1
49	1	2016-10-08 01:31:45	2016-10-08 01:31:45	2016-10-08 01:31:45	F	\N	\N	\N	\N	1	\N	1	\N	1
50	1	2016-10-08 04:01:45	2016-10-08 04:01:45	2016-10-08 04:01:45	F	\N	\N	\N	\N	1	\N	1	\N	1
51	1	2016-10-08 06:16:50	2016-10-08 06:16:50	2016-10-08 06:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
52	1	2016-10-08 07:46:50	2016-10-08 07:46:50	2016-10-08 07:46:50	F	\N	\N	\N	\N	1	\N	1	\N	1
53	1	2016-10-08 10:31:50	2016-10-08 10:31:50	2016-10-08 10:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
54	1	2016-10-08 14:16:49	2016-10-08 14:16:49	2016-10-08 14:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
55	1	2016-10-08 15:01:49	2016-10-08 15:01:49	2016-10-08 15:01:49	F	\N	\N	\N	\N	1	\N	1	\N	1
56	1	2016-10-08 17:16:49	2016-10-08 17:16:49	2016-10-08 17:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
57	1	2016-10-08 21:16:48	2016-10-08 21:16:48	2016-10-08 21:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
58	1	2016-10-08 22:31:48	2016-10-08 22:31:48	2016-10-08 22:31:48	F	\N	\N	\N	\N	1	\N	1	\N	1
59	1	2016-10-09 00:46:48	2016-10-09 00:46:48	2016-10-09 00:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
60	1	2016-10-09 05:16:48	2016-10-09 05:16:48	2016-10-09 05:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
61	1	2016-10-09 06:31:51	2016-10-09 06:31:51	2016-10-09 06:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
62	1	2016-10-10 07:46:52	2016-10-10 07:46:52	2016-10-10 07:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
63	1	2016-10-10 11:01:51	2016-10-10 11:01:51	2016-10-10 11:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
64	1	2016-10-10 13:31:51	2016-10-10 13:31:51	2016-10-10 13:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
65	1	2016-10-10 14:46:51	2016-10-10 14:46:51	2016-10-10 14:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
66	1	2016-10-10 18:31:51	2016-10-10 18:31:51	2016-10-10 18:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
67	1	2016-10-10 21:16:50	2016-10-10 21:16:50	2016-10-10 21:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
68	1	2016-10-11 00:16:50	2016-10-11 00:16:50	2016-10-11 00:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
69	1	2016-10-11 03:16:50	2016-10-11 03:16:50	2016-10-11 03:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
70	1	2016-10-11 05:46:50	2016-10-11 05:46:50	2016-10-11 05:46:50	F	\N	\N	\N	\N	1	\N	1	\N	1
71	1	2016-10-11 06:46:49	2016-10-11 06:46:49	2016-10-11 06:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
72	1	2016-10-12 09:01:54	2016-10-12 09:01:54	2016-10-12 09:01:54	F	\N	\N	\N	\N	1	\N	1	\N	1
73	1	2016-10-13 07:16:51	2016-10-13 07:16:51	2016-10-13 07:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
74	1	2016-10-13 10:46:51	2016-10-13 10:46:51	2016-10-13 10:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
75	1	2016-10-13 13:32:03	2016-10-13 13:32:03	2016-10-13 13:32:03	F	\N	\N	\N	\N	1	\N	1	\N	1
76	1	2016-10-13 16:02:03	2016-10-13 16:02:03	2016-10-13 16:02:03	F	\N	\N	\N	\N	1	\N	1	\N	1
77	1	2016-10-13 17:32:03	2016-10-13 17:32:03	2016-10-13 17:32:03	F	\N	\N	\N	\N	1	\N	1	\N	1
78	1	2016-10-13 21:17:03	2016-10-13 21:17:03	2016-10-13 21:17:03	F	\N	\N	\N	\N	1	\N	1	\N	1
79	1	2016-10-13 23:02:03	2016-10-13 23:02:03	2016-10-13 23:02:03	F	\N	\N	\N	\N	1	\N	1	\N	1
80	1	2016-10-14 00:47:03	2016-10-14 00:47:03	2016-10-14 00:47:03	F	\N	\N	\N	\N	1	\N	1	\N	1
81	1	2016-10-14 04:02:02	2016-10-14 04:02:02	2016-10-14 04:02:02	F	\N	\N	\N	\N	1	\N	1	\N	1
82	1	2016-10-14 07:31:49	2016-10-14 07:31:49	2016-10-14 07:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
83	1	2016-10-14 09:31:49	2016-10-14 09:31:49	2016-10-14 09:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
84	1	2016-10-14 11:16:49	2016-10-14 11:16:49	2016-10-14 11:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
85	1	2016-10-14 15:16:48	2016-10-14 15:16:48	2016-10-14 15:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
86	1	2016-10-14 18:01:48	2016-10-14 18:01:48	2016-10-14 18:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
87	1	2016-10-15 06:31:52	2016-10-15 06:31:52	2016-10-15 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
88	1	2016-10-15 10:31:52	2016-10-15 10:31:52	2016-10-15 10:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
89	1	2016-10-15 13:01:52	2016-10-15 13:01:52	2016-10-15 13:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
90	1	2016-10-15 16:01:51	2016-10-15 16:01:51	2016-10-15 16:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
91	1	2016-10-15 16:46:51	2016-10-15 16:46:51	2016-10-15 16:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
92	1	2016-10-15 19:46:51	2016-10-15 19:46:51	2016-10-15 19:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
93	1	2016-10-15 21:01:51	2016-10-15 21:01:51	2016-10-15 21:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
94	1	2016-10-15 23:46:51	2016-10-15 23:46:51	2016-10-15 23:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
95	1	2016-10-16 03:01:51	2016-10-16 03:01:51	2016-10-16 03:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
96	1	2016-10-16 06:46:48	2016-10-16 06:46:48	2016-10-16 06:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
97	1	2016-10-16 08:46:48	2016-10-16 08:46:48	2016-10-16 08:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
98	1	2016-10-16 11:01:48	2016-10-16 11:01:48	2016-10-16 11:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
99	1	2016-10-16 14:01:47	2016-10-16 14:01:47	2016-10-16 14:01:47	F	\N	\N	\N	\N	1	\N	1	\N	1
100	1	2016-10-16 15:46:47	2016-10-16 15:46:47	2016-10-16 15:46:47	F	\N	\N	\N	\N	1	\N	1	\N	1
101	1	2016-10-16 18:31:47	2016-10-16 18:31:47	2016-10-16 18:31:47	F	\N	\N	\N	\N	1	\N	1	\N	1
102	1	2016-10-16 21:16:47	2016-10-16 21:16:47	2016-10-16 21:16:47	F	\N	\N	\N	\N	1	\N	1	\N	1
103	1	2016-10-17 01:01:46	2016-10-17 01:01:46	2016-10-17 01:01:46	F	\N	\N	\N	\N	1	\N	1	\N	1
104	1	2016-10-17 01:46:46	2016-10-17 01:46:46	2016-10-17 01:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
105	1	2016-10-17 06:16:46	2016-10-17 06:16:46	2016-10-17 06:16:46	F	\N	\N	\N	\N	1	\N	1	\N	1
106	1	2016-10-18 06:31:55	2016-10-18 06:31:55	2016-10-18 06:31:55	F	\N	\N	\N	\N	1	\N	1	\N	1
107	1	2016-10-18 09:31:55	2016-10-18 09:31:55	2016-10-18 09:31:55	F	\N	\N	\N	\N	1	\N	1	\N	1
108	1	2016-10-18 12:16:55	2016-10-18 12:16:55	2016-10-18 12:16:55	F	\N	\N	\N	\N	1	\N	1	\N	1
109	1	2016-10-18 13:16:55	2016-10-18 13:16:55	2016-10-18 13:16:55	F	\N	\N	\N	\N	1	\N	1	\N	1
110	1	2016-10-18 16:31:54	2016-10-18 16:31:54	2016-10-18 16:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
111	1	2016-10-18 18:01:54	2016-10-18 18:01:54	2016-10-18 18:01:54	F	\N	\N	\N	\N	1	\N	1	\N	1
112	1	2016-10-18 22:01:54	2016-10-18 22:01:54	2016-10-18 22:01:54	F	\N	\N	\N	\N	1	\N	1	\N	1
113	1	2016-10-19 01:16:54	2016-10-19 01:16:54	2016-10-19 01:16:54	F	\N	\N	\N	\N	1	\N	1	\N	1
114	1	2016-10-19 02:31:54	2016-10-19 02:31:54	2016-10-19 02:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
115	1	2016-10-19 06:46:48	2016-10-19 06:46:48	2016-10-19 06:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
116	1	2016-10-20 06:46:52	2016-10-20 06:46:52	2016-10-20 06:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
117	1	2016-10-20 11:16:52	2016-10-20 11:16:52	2016-10-20 11:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
118	1	2016-10-20 12:31:52	2016-10-20 12:31:52	2016-10-20 12:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
119	1	2016-10-20 14:32:00	2016-10-20 14:32:00	2016-10-20 14:32:00	F	\N	\N	\N	\N	1	\N	1	\N	1
120	1	2016-10-20 16:32:00	2016-10-20 16:32:00	2016-10-20 16:32:00	F	\N	\N	\N	\N	1	\N	1	\N	1
121	1	2016-10-20 20:17:00	2016-10-20 20:17:00	2016-10-20 20:17:00	F	\N	\N	\N	\N	1	\N	1	\N	1
122	1	2016-10-20 22:02:00	2016-10-20 22:02:00	2016-10-20 22:02:00	F	\N	\N	\N	\N	1	\N	1	\N	1
123	1	2016-10-21 02:16:59	2016-10-21 02:16:59	2016-10-21 02:16:59	F	\N	\N	\N	\N	1	\N	1	\N	1
124	1	2016-10-21 05:01:59	2016-10-21 05:01:59	2016-10-21 05:01:59	F	\N	\N	\N	\N	1	\N	1	\N	1
125	1	2016-10-21 06:31:50	2016-10-21 06:31:50	2016-10-21 06:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
126	1	2016-10-21 09:01:50	2016-10-21 09:01:50	2016-10-21 09:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
127	1	2016-10-21 12:31:50	2016-10-21 12:31:50	2016-10-21 12:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
128	1	2016-10-21 15:01:50	2016-10-21 15:01:50	2016-10-21 15:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
129	1	2016-10-21 16:46:50	2016-10-21 16:46:50	2016-10-21 16:46:50	F	\N	\N	\N	\N	1	\N	1	\N	1
130	1	2016-10-21 19:31:49	2016-10-21 19:31:49	2016-10-21 19:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
131	1	2016-10-21 20:31:49	2016-10-21 20:31:49	2016-10-21 20:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
132	1	2016-10-21 23:46:49	2016-10-21 23:46:49	2016-10-21 23:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
133	1	2016-10-22 02:31:49	2016-10-22 02:31:49	2016-10-22 02:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
134	1	2016-10-22 05:46:49	2016-10-22 05:46:49	2016-10-22 05:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
135	1	2016-10-22 08:46:49	2016-10-22 08:46:49	2016-10-22 08:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
136	1	2016-10-22 11:01:49	2016-10-22 11:01:49	2016-10-22 11:01:49	F	\N	\N	\N	\N	1	\N	1	\N	1
137	1	2016-10-22 13:31:49	2016-10-22 13:31:49	2016-10-22 13:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
138	1	2016-10-22 14:16:49	2016-10-22 14:16:49	2016-10-22 14:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
139	1	2016-10-22 18:31:48	2016-10-22 18:31:48	2016-10-22 18:31:48	F	\N	\N	\N	\N	1	\N	1	\N	1
140	1	2016-10-22 21:01:48	2016-10-22 21:01:48	2016-10-22 21:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
141	1	2016-10-22 23:31:48	2016-10-22 23:31:48	2016-10-22 23:31:48	F	\N	\N	\N	\N	1	\N	1	\N	1
142	1	2016-10-23 01:16:48	2016-10-23 01:16:48	2016-10-23 01:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
143	1	2016-10-23 03:46:48	2016-10-23 03:46:48	2016-10-23 03:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
144	1	2016-10-23 07:16:47	2016-10-23 07:16:47	2016-10-23 07:16:47	F	\N	\N	\N	\N	1	\N	1	\N	1
145	1	2016-10-23 10:16:47	2016-10-23 10:16:47	2016-10-23 10:16:47	F	\N	\N	\N	\N	1	\N	1	\N	1
146	1	2016-10-23 12:31:47	2016-10-23 12:31:47	2016-10-23 12:31:47	F	\N	\N	\N	\N	1	\N	1	\N	1
147	1	2016-10-23 14:31:47	2016-10-23 14:31:47	2016-10-23 14:31:47	F	\N	\N	\N	\N	1	\N	1	\N	1
148	1	2016-10-23 17:46:46	2016-10-23 17:46:46	2016-10-23 17:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
149	1	2016-10-23 19:16:46	2016-10-23 19:16:46	2016-10-23 19:16:46	F	\N	\N	\N	\N	1	\N	1	\N	1
150	1	2016-10-23 22:46:46	2016-10-23 22:46:46	2016-10-23 22:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
151	1	2016-10-23 23:46:46	2016-10-23 23:46:46	2016-10-23 23:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
152	1	2016-10-24 04:01:46	2016-10-24 04:01:46	2016-10-24 04:01:46	F	\N	\N	\N	\N	1	\N	1	\N	1
153	1	2016-10-24 06:46:48	2016-10-24 06:46:48	2016-10-24 06:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
154	1	2016-10-24 08:16:48	2016-10-24 08:16:48	2016-10-24 08:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
155	1	2016-10-25 09:31:55	2016-10-25 09:31:55	2016-10-25 09:31:55	F	\N	\N	\N	\N	1	\N	1	\N	1
156	1	2016-10-25 10:46:55	2016-10-25 10:46:55	2016-10-25 10:46:55	F	\N	\N	\N	\N	1	\N	1	\N	1
157	1	2016-10-25 14:46:55	2016-10-25 14:46:55	2016-10-25 14:46:55	F	\N	\N	\N	\N	1	\N	1	\N	1
158	1	2016-10-25 15:16:55	2016-10-25 15:16:55	2016-10-25 15:16:55	F	\N	\N	\N	\N	1	\N	1	\N	1
159	1	2016-10-25 18:31:54	2016-10-25 18:31:54	2016-10-25 18:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
160	1	2016-10-25 21:01:54	2016-10-25 21:01:54	2016-10-25 21:01:54	F	\N	\N	\N	\N	1	\N	1	\N	1
161	1	2016-10-26 00:31:54	2016-10-26 00:31:54	2016-10-26 00:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
162	1	2016-10-26 01:46:54	2016-10-26 01:46:54	2016-10-26 01:46:54	F	\N	\N	\N	\N	1	\N	1	\N	1
163	1	2016-10-26 05:31:53	2016-10-26 05:31:53	2016-10-26 05:31:53	F	\N	\N	\N	\N	1	\N	1	\N	1
164	1	2016-10-27 06:46:56	2016-10-27 06:46:56	2016-10-27 06:46:56	F	\N	\N	\N	\N	1	\N	1	\N	1
165	1	2016-10-27 08:31:56	2016-10-27 08:31:56	2016-10-27 08:31:56	F	\N	\N	\N	\N	1	\N	1	\N	1
166	1	2016-10-27 12:16:56	2016-10-27 12:16:56	2016-10-27 12:16:56	F	\N	\N	\N	\N	1	\N	1	\N	1
167	1	2016-10-27 12:46:56	2016-10-27 12:46:56	2016-10-27 12:46:56	F	\N	\N	\N	\N	1	\N	1	\N	1
168	1	2016-10-27 16:17:05	2016-10-27 16:17:05	2016-10-27 16:17:05	F	\N	\N	\N	\N	1	\N	1	\N	1
169	1	2016-10-27 20:02:04	2016-10-27 20:02:04	2016-10-27 20:02:04	F	\N	\N	\N	\N	1	\N	1	\N	1
170	1	2016-10-27 21:32:04	2016-10-27 21:32:04	2016-10-27 21:32:04	F	\N	\N	\N	\N	1	\N	1	\N	1
171	1	2016-10-27 22:47:04	2016-10-27 22:47:04	2016-10-27 22:47:04	F	\N	\N	\N	\N	1	\N	1	\N	1
172	1	2016-10-28 03:47:04	2016-10-28 03:47:04	2016-10-28 03:47:04	F	\N	\N	\N	\N	1	\N	1	\N	1
173	1	2016-10-29 06:31:57	2016-10-29 06:31:57	2016-10-29 06:31:57	F	\N	\N	\N	\N	1	\N	1	\N	1
174	1	2016-10-29 08:16:57	2016-10-29 08:16:57	2016-10-29 08:16:57	F	\N	\N	\N	\N	1	\N	1	\N	1
175	1	2016-10-29 11:31:57	2016-10-29 11:31:57	2016-10-29 11:31:57	F	\N	\N	\N	\N	1	\N	1	\N	1
176	1	2016-10-29 11:46:57	2016-10-29 11:46:57	2016-10-29 11:46:57	F	\N	\N	\N	\N	1	\N	1	\N	1
177	1	2016-10-29 14:31:57	2016-10-29 14:31:57	2016-10-29 14:31:57	F	\N	\N	\N	\N	1	\N	1	\N	1
178	1	2016-10-29 19:01:56	2016-10-29 19:01:56	2016-10-29 19:01:56	F	\N	\N	\N	\N	1	\N	1	\N	1
179	1	2016-10-29 20:46:56	2016-10-29 20:46:56	2016-10-29 20:46:56	F	\N	\N	\N	\N	1	\N	1	\N	1
180	1	2016-10-29 23:16:56	2016-10-29 23:16:56	2016-10-29 23:16:56	F	\N	\N	\N	\N	1	\N	1	\N	1
181	1	2016-10-30 01:31:56	2016-10-30 01:31:56	2016-10-30 01:31:56	F	\N	\N	\N	\N	1	\N	1	\N	1
182	1	2016-10-30 03:31:56	2016-10-30 03:31:56	2016-10-30 03:31:56	F	\N	\N	\N	\N	1	\N	1	\N	1
183	1	2016-10-30 07:01:51	2016-10-30 07:01:51	2016-10-30 07:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
184	1	2016-10-30 08:46:51	2016-10-30 08:46:51	2016-10-30 08:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
185	1	2016-10-30 12:46:51	2016-10-30 12:46:51	2016-10-30 12:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
186	1	2016-10-30 13:01:51	2016-10-30 13:01:51	2016-10-30 13:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
187	1	2016-10-30 15:31:51	2016-10-30 15:31:51	2016-10-30 15:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
188	1	2016-10-30 18:01:50	2016-10-30 18:01:50	2016-10-30 18:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
189	1	2016-10-30 21:31:50	2016-10-30 21:31:50	2016-10-30 21:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
190	1	2016-10-30 23:01:50	2016-10-30 23:01:50	2016-10-30 23:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
191	1	2016-10-31 02:16:50	2016-10-31 02:16:50	2016-10-31 02:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
192	1	2016-10-31 06:31:52	2016-10-31 06:31:52	2016-10-31 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
193	1	2016-10-31 08:46:52	2016-10-31 08:46:52	2016-10-31 08:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
194	1	2016-10-31 11:46:52	2016-10-31 11:46:52	2016-10-31 11:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
195	1	2016-10-31 13:01:52	2016-10-31 13:01:52	2016-10-31 13:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
196	1	2016-10-31 16:01:51	2016-10-31 16:01:51	2016-10-31 16:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
197	1	2016-10-31 17:31:51	2016-10-31 17:31:51	2016-10-31 17:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
198	1	2016-10-31 20:31:51	2016-10-31 20:31:51	2016-10-31 20:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
199	1	2016-10-31 23:16:51	2016-10-31 23:16:51	2016-10-31 23:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
200	1	2016-11-01 00:46:51	2016-11-01 00:46:51	2016-11-01 00:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
201	2	2016-10-01 06:31:54	2016-10-01 06:31:54	2016-10-01 06:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
202	2	2016-10-01 07:16:54	2016-10-01 07:16:54	2016-10-01 07:16:54	F	\N	\N	\N	\N	1	\N	1	\N	1
203	2	2016-10-01 11:16:54	2016-10-01 11:16:54	2016-10-01 11:16:54	F	\N	\N	\N	\N	1	\N	1	\N	1
204	2	2016-10-01 12:01:53	2016-10-01 12:01:53	2016-10-01 12:01:53	F	\N	\N	\N	\N	1	\N	1	\N	1
205	2	2016-10-01 16:01:53	2016-10-01 16:01:53	2016-10-01 16:01:53	F	\N	\N	\N	\N	1	\N	1	\N	1
206	2	2016-10-01 18:46:53	2016-10-01 18:46:53	2016-10-01 18:46:53	F	\N	\N	\N	\N	1	\N	1	\N	1
207	2	2016-10-01 20:31:52	2016-10-01 20:31:52	2016-10-01 20:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
208	2	2016-10-01 22:16:52	2016-10-01 22:16:52	2016-10-01 22:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
209	2	2016-10-02 01:01:52	2016-10-02 01:01:52	2016-10-02 01:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
210	2	2016-10-02 05:01:52	2016-10-02 05:01:52	2016-10-02 05:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
211	2	2016-10-02 06:31:48	2016-10-02 06:31:48	2016-10-02 06:31:48	F	\N	\N	\N	\N	1	\N	1	\N	1
212	2	2016-10-02 09:01:48	2016-10-02 09:01:48	2016-10-02 09:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
213	2	2016-10-02 11:01:48	2016-10-02 11:01:48	2016-10-02 11:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
214	2	2016-10-03 06:46:52	2016-10-03 06:46:52	2016-10-03 06:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
215	2	2016-10-03 11:31:52	2016-10-03 11:31:52	2016-10-03 11:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
216	2	2016-10-03 13:31:52	2016-10-03 13:31:52	2016-10-03 13:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
217	2	2016-10-03 15:46:51	2016-10-03 15:46:51	2016-10-03 15:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
218	2	2016-10-03 17:01:51	2016-10-03 17:01:51	2016-10-03 17:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
219	2	2016-10-03 19:46:51	2016-10-03 19:46:51	2016-10-03 19:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
220	2	2016-10-03 22:46:51	2016-10-03 22:46:51	2016-10-03 22:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
221	2	2016-10-04 02:16:50	2016-10-04 02:16:50	2016-10-04 02:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
222	2	2016-10-04 05:01:50	2016-10-04 05:01:50	2016-10-04 05:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
223	2	2016-10-05 06:31:53	2016-10-05 06:31:53	2016-10-05 06:31:53	F	\N	\N	\N	\N	1	\N	1	\N	1
224	2	2016-10-05 10:01:53	2016-10-05 10:01:53	2016-10-05 10:01:53	F	\N	\N	\N	\N	1	\N	1	\N	1
225	2	2016-10-05 11:46:53	2016-10-05 11:46:53	2016-10-05 11:46:53	F	\N	\N	\N	\N	1	\N	1	\N	1
226	2	2016-10-05 13:31:53	2016-10-05 13:31:53	2016-10-05 13:31:53	F	\N	\N	\N	\N	1	\N	1	\N	1
227	2	2016-10-05 16:01:52	2016-10-05 16:01:52	2016-10-05 16:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
228	2	2016-10-05 19:16:52	2016-10-05 19:16:52	2016-10-05 19:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
229	2	2016-10-05 22:16:52	2016-10-05 22:16:52	2016-10-05 22:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
230	2	2016-10-05 23:31:52	2016-10-05 23:31:52	2016-10-05 23:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
231	2	2016-10-06 03:31:51	2016-10-06 03:31:51	2016-10-06 03:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
232	2	2016-10-06 04:46:51	2016-10-06 04:46:51	2016-10-06 04:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
233	2	2016-10-06 09:01:50	2016-10-06 09:01:50	2016-10-06 09:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
234	2	2016-10-06 11:16:49	2016-10-06 11:16:49	2016-10-06 11:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
235	2	2016-10-06 13:16:49	2016-10-06 13:16:49	2016-10-06 13:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
236	2	2016-10-06 15:17:01	2016-10-06 15:17:01	2016-10-06 15:17:01	F	\N	\N	\N	\N	1	\N	1	\N	1
237	2	2016-10-06 17:32:01	2016-10-06 17:32:01	2016-10-06 17:32:01	F	\N	\N	\N	\N	1	\N	1	\N	1
238	2	2016-10-06 19:17:00	2016-10-06 19:17:00	2016-10-06 19:17:00	F	\N	\N	\N	\N	1	\N	1	\N	1
239	2	2016-10-06 22:47:00	2016-10-06 22:47:00	2016-10-06 22:47:00	F	\N	\N	\N	\N	1	\N	1	\N	1
240	2	2016-10-07 00:32:00	2016-10-07 00:32:00	2016-10-07 00:32:00	F	\N	\N	\N	\N	1	\N	1	\N	1
241	2	2016-10-07 02:47:00	2016-10-07 02:47:00	2016-10-07 02:47:00	F	\N	\N	\N	\N	1	\N	1	\N	1
242	2	2016-10-07 07:46:47	2016-10-07 07:46:47	2016-10-07 07:46:47	F	\N	\N	\N	\N	1	\N	1	\N	1
243	2	2016-10-07 10:01:47	2016-10-07 10:01:47	2016-10-07 10:01:47	F	\N	\N	\N	\N	1	\N	1	\N	1
244	2	2016-10-07 12:01:46	2016-10-07 12:01:46	2016-10-07 12:01:46	F	\N	\N	\N	\N	1	\N	1	\N	1
245	2	2016-10-07 14:01:46	2016-10-07 14:01:46	2016-10-07 14:01:46	F	\N	\N	\N	\N	1	\N	1	\N	1
246	2	2016-10-07 15:31:46	2016-10-07 15:31:46	2016-10-07 15:31:46	F	\N	\N	\N	\N	1	\N	1	\N	1
247	2	2016-10-07 18:16:46	2016-10-07 18:16:46	2016-10-07 18:16:46	F	\N	\N	\N	\N	1	\N	1	\N	1
248	2	2016-10-07 22:16:45	2016-10-07 22:16:45	2016-10-07 22:16:45	F	\N	\N	\N	\N	1	\N	1	\N	1
249	2	2016-10-08 01:31:45	2016-10-08 01:31:45	2016-10-08 01:31:45	F	\N	\N	\N	\N	1	\N	1	\N	1
250	2	2016-10-08 04:01:45	2016-10-08 04:01:45	2016-10-08 04:01:45	F	\N	\N	\N	\N	1	\N	1	\N	1
251	2	2016-10-08 06:16:50	2016-10-08 06:16:50	2016-10-08 06:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
252	2	2016-10-08 09:01:50	2016-10-08 09:01:50	2016-10-08 09:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
253	2	2016-10-08 10:31:50	2016-10-08 10:31:50	2016-10-08 10:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
254	2	2016-10-08 14:16:49	2016-10-08 14:16:49	2016-10-08 14:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
255	2	2016-10-08 15:01:49	2016-10-08 15:01:49	2016-10-08 15:01:49	F	\N	\N	\N	\N	1	\N	1	\N	1
256	2	2016-10-08 17:01:49	2016-10-08 17:01:49	2016-10-08 17:01:49	F	\N	\N	\N	\N	1	\N	1	\N	1
257	2	2016-10-08 21:31:48	2016-10-08 21:31:48	2016-10-08 21:31:48	F	\N	\N	\N	\N	1	\N	1	\N	1
258	2	2016-10-08 22:46:48	2016-10-08 22:46:48	2016-10-08 22:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
259	2	2016-10-09 00:46:48	2016-10-09 00:46:48	2016-10-09 00:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
260	2	2016-10-09 05:16:48	2016-10-09 05:16:48	2016-10-09 05:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
261	2	2016-10-09 06:31:51	2016-10-09 06:31:51	2016-10-09 06:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
262	2	2016-10-10 07:31:52	2016-10-10 07:31:52	2016-10-10 07:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
263	2	2016-10-10 11:16:51	2016-10-10 11:16:51	2016-10-10 11:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
264	2	2016-10-10 13:31:51	2016-10-10 13:31:51	2016-10-10 13:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
265	2	2016-10-10 15:01:51	2016-10-10 15:01:51	2016-10-10 15:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
266	2	2016-10-10 18:31:51	2016-10-10 18:31:51	2016-10-10 18:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
267	2	2016-10-10 21:16:50	2016-10-10 21:16:50	2016-10-10 21:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
268	2	2016-10-11 00:16:50	2016-10-11 00:16:50	2016-10-11 00:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
269	2	2016-10-11 03:16:50	2016-10-11 03:16:50	2016-10-11 03:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
270	2	2016-10-11 05:46:50	2016-10-11 05:46:50	2016-10-11 05:46:50	F	\N	\N	\N	\N	1	\N	1	\N	1
271	2	2016-10-11 06:46:49	2016-10-11 06:46:49	2016-10-11 06:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
272	2	2016-10-12 09:31:54	2016-10-12 09:31:54	2016-10-12 09:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
273	2	2016-10-13 07:16:51	2016-10-13 07:16:51	2016-10-13 07:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
274	2	2016-10-13 11:01:51	2016-10-13 11:01:51	2016-10-13 11:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
275	2	2016-10-13 11:46:51	2016-10-13 11:46:51	2016-10-13 11:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
276	2	2016-10-13 15:47:03	2016-10-13 15:47:03	2016-10-13 15:47:03	F	\N	\N	\N	\N	1	\N	1	\N	1
277	2	2016-10-13 17:17:03	2016-10-13 17:17:03	2016-10-13 17:17:03	F	\N	\N	\N	\N	1	\N	1	\N	1
278	2	2016-10-13 20:17:03	2016-10-13 20:17:03	2016-10-13 20:17:03	F	\N	\N	\N	\N	1	\N	1	\N	1
279	2	2016-10-13 23:17:03	2016-10-13 23:17:03	2016-10-13 23:17:03	F	\N	\N	\N	\N	1	\N	1	\N	1
280	2	2016-10-14 00:47:03	2016-10-14 00:47:03	2016-10-14 00:47:03	F	\N	\N	\N	\N	1	\N	1	\N	1
281	2	2016-10-14 03:47:02	2016-10-14 03:47:02	2016-10-14 03:47:02	F	\N	\N	\N	\N	1	\N	1	\N	1
282	2	2016-10-14 07:46:49	2016-10-14 07:46:49	2016-10-14 07:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
283	2	2016-10-14 10:31:49	2016-10-14 10:31:49	2016-10-14 10:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
284	2	2016-10-14 11:16:49	2016-10-14 11:16:49	2016-10-14 11:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
285	2	2016-10-14 15:16:48	2016-10-14 15:16:48	2016-10-14 15:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
286	2	2016-10-14 18:01:48	2016-10-14 18:01:48	2016-10-14 18:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
287	2	2016-10-15 06:31:52	2016-10-15 06:31:52	2016-10-15 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
288	2	2016-10-15 10:31:52	2016-10-15 10:31:52	2016-10-15 10:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
289	2	2016-10-15 13:16:52	2016-10-15 13:16:52	2016-10-15 13:16:52	F	\N	\N	\N	\N	1	\N	1	\N	1
290	2	2016-10-15 16:01:51	2016-10-15 16:01:51	2016-10-15 16:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
291	2	2016-10-15 16:31:51	2016-10-15 16:31:51	2016-10-15 16:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
292	2	2016-10-15 19:46:51	2016-10-15 19:46:51	2016-10-15 19:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
293	2	2016-10-15 21:01:51	2016-10-15 21:01:51	2016-10-15 21:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
294	2	2016-10-15 23:46:51	2016-10-15 23:46:51	2016-10-15 23:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
295	2	2016-10-16 03:01:51	2016-10-16 03:01:51	2016-10-16 03:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
296	2	2016-10-16 07:01:48	2016-10-16 07:01:48	2016-10-16 07:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
297	2	2016-10-16 08:46:48	2016-10-16 08:46:48	2016-10-16 08:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
298	2	2016-10-16 10:46:48	2016-10-16 10:46:48	2016-10-16 10:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
299	2	2016-10-16 14:01:47	2016-10-16 14:01:47	2016-10-16 14:01:47	F	\N	\N	\N	\N	1	\N	1	\N	1
300	2	2016-10-16 16:01:47	2016-10-16 16:01:47	2016-10-16 16:01:47	F	\N	\N	\N	\N	1	\N	1	\N	1
301	2	2016-10-16 18:31:47	2016-10-16 18:31:47	2016-10-16 18:31:47	F	\N	\N	\N	\N	1	\N	1	\N	1
302	2	2016-10-16 21:31:47	2016-10-16 21:31:47	2016-10-16 21:31:47	F	\N	\N	\N	\N	1	\N	1	\N	1
303	2	2016-10-17 00:31:46	2016-10-17 00:31:46	2016-10-17 00:31:46	F	\N	\N	\N	\N	1	\N	1	\N	1
304	2	2016-10-17 02:01:46	2016-10-17 02:01:46	2016-10-17 02:01:46	F	\N	\N	\N	\N	1	\N	1	\N	1
305	2	2016-10-17 06:16:46	2016-10-17 06:16:46	2016-10-17 06:16:46	F	\N	\N	\N	\N	1	\N	1	\N	1
306	2	2016-10-18 06:31:55	2016-10-18 06:31:55	2016-10-18 06:31:55	F	\N	\N	\N	\N	1	\N	1	\N	1
307	2	2016-10-18 09:31:55	2016-10-18 09:31:55	2016-10-18 09:31:55	F	\N	\N	\N	\N	1	\N	1	\N	1
308	2	2016-10-18 12:16:55	2016-10-18 12:16:55	2016-10-18 12:16:55	F	\N	\N	\N	\N	1	\N	1	\N	1
309	2	2016-10-18 13:16:55	2016-10-18 13:16:55	2016-10-18 13:16:55	F	\N	\N	\N	\N	1	\N	1	\N	1
310	2	2016-10-18 16:31:54	2016-10-18 16:31:54	2016-10-18 16:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
311	2	2016-10-18 18:01:54	2016-10-18 18:01:54	2016-10-18 18:01:54	F	\N	\N	\N	\N	1	\N	1	\N	1
312	2	2016-10-18 21:46:54	2016-10-18 21:46:54	2016-10-18 21:46:54	F	\N	\N	\N	\N	1	\N	1	\N	1
313	2	2016-10-19 01:16:54	2016-10-19 01:16:54	2016-10-19 01:16:54	F	\N	\N	\N	\N	1	\N	1	\N	1
314	2	2016-10-19 02:31:54	2016-10-19 02:31:54	2016-10-19 02:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
315	2	2016-10-19 06:16:49	2016-10-19 06:16:49	2016-10-19 06:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
316	2	2016-10-20 06:31:52	2016-10-20 06:31:52	2016-10-20 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
317	2	2016-10-20 11:01:52	2016-10-20 11:01:52	2016-10-20 11:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
318	2	2016-10-20 12:31:52	2016-10-20 12:31:52	2016-10-20 12:31:52	F	\N	\N	\N	\N	1	\N	1	\N	1
319	2	2016-10-20 14:32:00	2016-10-20 14:32:00	2016-10-20 14:32:00	F	\N	\N	\N	\N	1	\N	1	\N	1
320	2	2016-10-20 17:47:00	2016-10-20 17:47:00	2016-10-20 17:47:00	F	\N	\N	\N	\N	1	\N	1	\N	1
321	2	2016-10-20 20:32:00	2016-10-20 20:32:00	2016-10-20 20:32:00	F	\N	\N	\N	\N	1	\N	1	\N	1
322	2	2016-10-20 21:32:00	2016-10-20 21:32:00	2016-10-20 21:32:00	F	\N	\N	\N	\N	1	\N	1	\N	1
323	2	2016-10-21 02:02:00	2016-10-21 02:02:00	2016-10-21 02:02:00	F	\N	\N	\N	\N	1	\N	1	\N	1
324	2	2016-10-21 02:46:59	2016-10-21 02:46:59	2016-10-21 02:46:59	F	\N	\N	\N	\N	1	\N	1	\N	1
325	2	2016-10-21 06:31:50	2016-10-21 06:31:50	2016-10-21 06:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
326	2	2016-10-21 08:01:50	2016-10-21 08:01:50	2016-10-21 08:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
327	2	2016-10-21 12:31:50	2016-10-21 12:31:50	2016-10-21 12:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
328	2	2016-10-21 14:16:50	2016-10-21 14:16:50	2016-10-21 14:16:50	F	\N	\N	\N	\N	1	\N	1	\N	1
329	2	2016-10-21 16:46:50	2016-10-21 16:46:50	2016-10-21 16:46:50	F	\N	\N	\N	\N	1	\N	1	\N	1
330	2	2016-10-21 19:01:49	2016-10-21 19:01:49	2016-10-21 19:01:49	F	\N	\N	\N	\N	1	\N	1	\N	1
331	2	2016-10-21 20:31:49	2016-10-21 20:31:49	2016-10-21 20:31:49	F	\N	\N	\N	\N	1	\N	1	\N	1
332	2	2016-10-21 23:46:49	2016-10-21 23:46:49	2016-10-21 23:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
333	2	2016-10-22 03:01:49	2016-10-22 03:01:49	2016-10-22 03:01:49	F	\N	\N	\N	\N	1	\N	1	\N	1
334	2	2016-10-22 05:46:49	2016-10-22 05:46:49	2016-10-22 05:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
335	2	2016-10-22 08:46:49	2016-10-22 08:46:49	2016-10-22 08:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
336	2	2016-10-22 11:01:49	2016-10-22 11:01:49	2016-10-22 11:01:49	F	\N	\N	\N	\N	1	\N	1	\N	1
337	2	2016-10-22 13:46:49	2016-10-22 13:46:49	2016-10-22 13:46:49	F	\N	\N	\N	\N	1	\N	1	\N	1
338	2	2016-10-22 14:16:49	2016-10-22 14:16:49	2016-10-22 14:16:49	F	\N	\N	\N	\N	1	\N	1	\N	1
339	2	2016-10-22 18:16:48	2016-10-22 18:16:48	2016-10-22 18:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
340	2	2016-10-22 21:01:48	2016-10-22 21:01:48	2016-10-22 21:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
341	2	2016-10-22 23:01:48	2016-10-22 23:01:48	2016-10-22 23:01:48	F	\N	\N	\N	\N	1	\N	1	\N	1
342	2	2016-10-23 01:16:48	2016-10-23 01:16:48	2016-10-23 01:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
343	2	2016-10-23 04:46:48	2016-10-23 04:46:48	2016-10-23 04:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
344	2	2016-10-23 07:16:47	2016-10-23 07:16:47	2016-10-23 07:16:47	F	\N	\N	\N	\N	1	\N	1	\N	1
345	2	2016-10-23 10:16:47	2016-10-23 10:16:47	2016-10-23 10:16:47	F	\N	\N	\N	\N	1	\N	1	\N	1
346	2	2016-10-23 12:46:47	2016-10-23 12:46:47	2016-10-23 12:46:47	F	\N	\N	\N	\N	1	\N	1	\N	1
347	2	2016-10-23 14:16:47	2016-10-23 14:16:47	2016-10-23 14:16:47	F	\N	\N	\N	\N	1	\N	1	\N	1
348	2	2016-10-23 17:46:46	2016-10-23 17:46:46	2016-10-23 17:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
349	2	2016-10-23 19:16:46	2016-10-23 19:16:46	2016-10-23 19:16:46	F	\N	\N	\N	\N	1	\N	1	\N	1
350	2	2016-10-23 22:46:46	2016-10-23 22:46:46	2016-10-23 22:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
351	2	2016-10-23 23:46:46	2016-10-23 23:46:46	2016-10-23 23:46:46	F	\N	\N	\N	\N	1	\N	1	\N	1
352	2	2016-10-24 04:01:46	2016-10-24 04:01:46	2016-10-24 04:01:46	F	\N	\N	\N	\N	1	\N	1	\N	1
353	2	2016-10-24 06:46:48	2016-10-24 06:46:48	2016-10-24 06:46:48	F	\N	\N	\N	\N	1	\N	1	\N	1
354	2	2016-10-24 08:16:48	2016-10-24 08:16:48	2016-10-24 08:16:48	F	\N	\N	\N	\N	1	\N	1	\N	1
355	2	2016-10-25 09:01:55	2016-10-25 09:01:55	2016-10-25 09:01:55	F	\N	\N	\N	\N	1	\N	1	\N	1
356	2	2016-10-25 11:16:55	2016-10-25 11:16:55	2016-10-25 11:16:55	F	\N	\N	\N	\N	1	\N	1	\N	1
357	2	2016-10-25 14:46:55	2016-10-25 14:46:55	2016-10-25 14:46:55	F	\N	\N	\N	\N	1	\N	1	\N	1
358	2	2016-10-25 15:31:54	2016-10-25 15:31:54	2016-10-25 15:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
359	2	2016-10-25 19:31:54	2016-10-25 19:31:54	2016-10-25 19:31:54	F	\N	\N	\N	\N	1	\N	1	\N	1
360	2	2016-10-25 20:01:54	2016-10-25 20:01:54	2016-10-25 20:01:54	F	\N	\N	\N	\N	1	\N	1	\N	1
361	2	2016-10-26 01:01:54	2016-10-26 01:01:54	2016-10-26 01:01:54	F	\N	\N	\N	\N	1	\N	1	\N	1
362	2	2016-10-26 01:46:54	2016-10-26 01:46:54	2016-10-26 01:46:54	F	\N	\N	\N	\N	1	\N	1	\N	1
363	2	2016-10-26 05:46:53	2016-10-26 05:46:53	2016-10-26 05:46:53	F	\N	\N	\N	\N	1	\N	1	\N	1
364	2	2016-10-27 06:31:56	2016-10-27 06:31:56	2016-10-27 06:31:56	F	\N	\N	\N	\N	1	\N	1	\N	1
365	2	2016-10-27 08:16:56	2016-10-27 08:16:56	2016-10-27 08:16:56	F	\N	\N	\N	\N	1	\N	1	\N	1
366	2	2016-10-27 12:16:56	2016-10-27 12:16:56	2016-10-27 12:16:56	F	\N	\N	\N	\N	1	\N	1	\N	1
367	2	2016-10-27 12:46:56	2016-10-27 12:46:56	2016-10-27 12:46:56	F	\N	\N	\N	\N	1	\N	1	\N	1
368	2	2016-10-27 16:02:05	2016-10-27 16:02:05	2016-10-27 16:02:05	F	\N	\N	\N	\N	1	\N	1	\N	1
369	2	2016-10-27 20:02:04	2016-10-27 20:02:04	2016-10-27 20:02:04	F	\N	\N	\N	\N	1	\N	1	\N	1
370	2	2016-10-27 21:32:04	2016-10-27 21:32:04	2016-10-27 21:32:04	F	\N	\N	\N	\N	1	\N	1	\N	1
371	2	2016-10-27 22:47:04	2016-10-27 22:47:04	2016-10-27 22:47:04	F	\N	\N	\N	\N	1	\N	1	\N	1
372	2	2016-10-28 03:47:04	2016-10-28 03:47:04	2016-10-28 03:47:04	F	\N	\N	\N	\N	1	\N	1	\N	1
373	2	2016-10-29 06:31:57	2016-10-29 06:31:57	2016-10-29 06:31:57	F	\N	\N	\N	\N	1	\N	1	\N	1
374	2	2016-10-29 08:46:57	2016-10-29 08:46:57	2016-10-29 08:46:57	F	\N	\N	\N	\N	1	\N	1	\N	1
375	2	2016-10-29 11:01:57	2016-10-29 11:01:57	2016-10-29 11:01:57	F	\N	\N	\N	\N	1	\N	1	\N	1
376	2	2016-10-29 13:31:57	2016-10-29 13:31:57	2016-10-29 13:31:57	F	\N	\N	\N	\N	1	\N	1	\N	1
377	2	2016-10-29 14:31:57	2016-10-29 14:31:57	2016-10-29 14:31:57	F	\N	\N	\N	\N	1	\N	1	\N	1
378	2	2016-10-29 17:16:56	2016-10-29 17:16:56	2016-10-29 17:16:56	F	\N	\N	\N	\N	1	\N	1	\N	1
379	2	2016-10-29 20:01:56	2016-10-29 20:01:56	2016-10-29 20:01:56	F	\N	\N	\N	\N	1	\N	1	\N	1
380	2	2016-10-29 21:46:56	2016-10-29 21:46:56	2016-10-29 21:46:56	F	\N	\N	\N	\N	1	\N	1	\N	1
381	2	2016-10-30 01:31:56	2016-10-30 01:31:56	2016-10-30 01:31:56	F	\N	\N	\N	\N	1	\N	1	\N	1
382	2	2016-10-30 03:31:56	2016-10-30 03:31:56	2016-10-30 03:31:56	F	\N	\N	\N	\N	1	\N	1	\N	1
383	2	2016-10-30 07:01:51	2016-10-30 07:01:51	2016-10-30 07:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
384	2	2016-10-30 08:46:51	2016-10-30 08:46:51	2016-10-30 08:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
385	2	2016-10-30 12:16:51	2016-10-30 12:16:51	2016-10-30 12:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
386	2	2016-10-30 15:16:51	2016-10-30 15:16:51	2016-10-30 15:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
387	2	2016-10-30 16:46:50	2016-10-30 16:46:50	2016-10-30 16:46:50	F	\N	\N	\N	\N	1	\N	1	\N	1
388	2	2016-10-30 19:31:50	2016-10-30 19:31:50	2016-10-30 19:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
389	2	2016-10-30 21:31:50	2016-10-30 21:31:50	2016-10-30 21:31:50	F	\N	\N	\N	\N	1	\N	1	\N	1
390	2	2016-10-30 23:01:50	2016-10-30 23:01:50	2016-10-30 23:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
391	2	2016-10-31 03:01:50	2016-10-31 03:01:50	2016-10-31 03:01:50	F	\N	\N	\N	\N	1	\N	1	\N	1
392	2	2016-10-31 06:46:52	2016-10-31 06:46:52	2016-10-31 06:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
393	2	2016-10-31 09:01:52	2016-10-31 09:01:52	2016-10-31 09:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
394	2	2016-10-31 11:46:52	2016-10-31 11:46:52	2016-10-31 11:46:52	F	\N	\N	\N	\N	1	\N	1	\N	1
395	2	2016-10-31 13:01:52	2016-10-31 13:01:52	2016-10-31 13:01:52	F	\N	\N	\N	\N	1	\N	1	\N	1
396	2	2016-10-31 16:01:51	2016-10-31 16:01:51	2016-10-31 16:01:51	F	\N	\N	\N	\N	1	\N	1	\N	1
397	2	2016-10-31 17:31:51	2016-10-31 17:31:51	2016-10-31 17:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
398	2	2016-10-31 20:31:51	2016-10-31 20:31:51	2016-10-31 20:31:51	F	\N	\N	\N	\N	1	\N	1	\N	1
399	2	2016-10-31 23:16:51	2016-10-31 23:16:51	2016-10-31 23:16:51	F	\N	\N	\N	\N	1	\N	1	\N	1
400	2	2016-11-01 00:46:51	2016-11-01 00:46:51	2016-11-01 00:46:51	F	\N	\N	\N	\N	1	\N	1	\N	1
401	3	2016-10-01 06:31:54	2016-10-01 06:31:54	2016-10-01 06:31:54	F	\N	\N	\N	\N	1	\N	1	\N	2
402	3	2016-10-01 07:16:54	2016-10-01 07:16:54	2016-10-01 07:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
403	3	2016-10-01 10:16:54	2016-10-01 10:16:54	2016-10-01 10:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
404	3	2016-10-01 12:01:53	2016-10-01 12:01:53	2016-10-01 12:01:53	F	\N	\N	\N	\N	1	\N	1	\N	2
405	3	2016-10-01 16:01:53	2016-10-01 16:01:53	2016-10-01 16:01:53	F	\N	\N	\N	\N	1	\N	1	\N	2
406	3	2016-10-01 18:46:53	2016-10-01 18:46:53	2016-10-01 18:46:53	F	\N	\N	\N	\N	1	\N	1	\N	2
407	3	2016-10-01 20:16:52	2016-10-01 20:16:52	2016-10-01 20:16:52	F	\N	\N	\N	\N	1	\N	1	\N	2
408	3	2016-10-01 22:31:52	2016-10-01 22:31:52	2016-10-01 22:31:52	F	\N	\N	\N	\N	1	\N	1	\N	2
409	3	2016-10-02 02:01:52	2016-10-02 02:01:52	2016-10-02 02:01:52	F	\N	\N	\N	\N	1	\N	1	\N	2
410	3	2016-10-02 05:01:52	2016-10-02 05:01:52	2016-10-02 05:01:52	F	\N	\N	\N	\N	1	\N	1	\N	2
411	3	2016-10-02 07:16:48	2016-10-02 07:16:48	2016-10-02 07:16:48	F	\N	\N	\N	\N	1	\N	1	\N	2
412	3	2016-10-02 09:01:48	2016-10-02 09:01:48	2016-10-02 09:01:48	F	\N	\N	\N	\N	1	\N	1	\N	2
413	3	2016-10-02 11:01:48	2016-10-02 11:01:48	2016-10-02 11:01:48	F	\N	\N	\N	\N	1	\N	1	\N	2
414	3	2016-10-03 06:46:52	2016-10-03 06:46:52	2016-10-03 06:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
415	3	2016-10-03 09:16:52	2016-10-03 09:16:52	2016-10-03 09:16:52	F	\N	\N	\N	\N	1	\N	1	\N	2
416	3	2016-10-03 13:31:52	2016-10-03 13:31:52	2016-10-03 13:31:52	F	\N	\N	\N	\N	1	\N	1	\N	2
417	3	2016-10-03 15:31:51	2016-10-03 15:31:51	2016-10-03 15:31:51	F	\N	\N	\N	\N	1	\N	1	\N	2
418	3	2016-10-03 17:16:51	2016-10-03 17:16:51	2016-10-03 17:16:51	F	\N	\N	\N	\N	1	\N	1	\N	2
419	3	2016-10-03 19:46:51	2016-10-03 19:46:51	2016-10-03 19:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
420	3	2016-10-03 23:16:51	2016-10-03 23:16:51	2016-10-03 23:16:51	F	\N	\N	\N	\N	1	\N	1	\N	2
421	3	2016-10-04 02:01:50	2016-10-04 02:01:50	2016-10-04 02:01:50	F	\N	\N	\N	\N	1	\N	1	\N	2
422	3	2016-10-04 05:01:50	2016-10-04 05:01:50	2016-10-04 05:01:50	F	\N	\N	\N	\N	1	\N	1	\N	2
423	3	2016-10-05 06:31:53	2016-10-05 06:31:53	2016-10-05 06:31:53	F	\N	\N	\N	\N	1	\N	1	\N	2
424	3	2016-10-05 09:31:53	2016-10-05 09:31:53	2016-10-05 09:31:53	F	\N	\N	\N	\N	1	\N	1	\N	2
425	3	2016-10-05 11:46:53	2016-10-05 11:46:53	2016-10-05 11:46:53	F	\N	\N	\N	\N	1	\N	1	\N	2
426	3	2016-10-05 13:16:53	2016-10-05 13:16:53	2016-10-05 13:16:53	F	\N	\N	\N	\N	1	\N	1	\N	2
427	3	2016-10-05 15:46:52	2016-10-05 15:46:52	2016-10-05 15:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
428	3	2016-10-05 17:46:52	2016-10-05 17:46:52	2016-10-05 17:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
429	3	2016-10-05 20:46:52	2016-10-05 20:46:52	2016-10-05 20:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
430	3	2016-10-05 23:31:52	2016-10-05 23:31:52	2016-10-05 23:31:52	F	\N	\N	\N	\N	1	\N	1	\N	2
431	3	2016-10-06 03:46:51	2016-10-06 03:46:51	2016-10-06 03:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
432	3	2016-10-06 05:01:51	2016-10-06 05:01:51	2016-10-06 05:01:51	F	\N	\N	\N	\N	1	\N	1	\N	2
433	3	2016-10-06 07:31:50	2016-10-06 07:31:50	2016-10-06 07:31:50	F	\N	\N	\N	\N	1	\N	1	\N	2
434	3	2016-10-06 11:01:49	2016-10-06 11:01:49	2016-10-06 11:01:49	F	\N	\N	\N	\N	1	\N	1	\N	2
435	3	2016-10-06 13:32:01	2016-10-06 13:32:01	2016-10-06 13:32:01	F	\N	\N	\N	\N	1	\N	1	\N	2
436	3	2016-10-06 15:32:01	2016-10-06 15:32:01	2016-10-06 15:32:01	F	\N	\N	\N	\N	1	\N	1	\N	2
437	3	2016-10-06 17:17:01	2016-10-06 17:17:01	2016-10-06 17:17:01	F	\N	\N	\N	\N	1	\N	1	\N	2
438	3	2016-10-06 20:02:00	2016-10-06 20:02:00	2016-10-06 20:02:00	F	\N	\N	\N	\N	1	\N	1	\N	2
439	3	2016-10-06 23:17:00	2016-10-06 23:17:00	2016-10-06 23:17:00	F	\N	\N	\N	\N	1	\N	1	\N	2
440	3	2016-10-07 00:47:00	2016-10-07 00:47:00	2016-10-07 00:47:00	F	\N	\N	\N	\N	1	\N	1	\N	2
441	3	2016-10-07 02:47:00	2016-10-07 02:47:00	2016-10-07 02:47:00	F	\N	\N	\N	\N	1	\N	1	\N	2
442	3	2016-10-07 07:31:47	2016-10-07 07:31:47	2016-10-07 07:31:47	F	\N	\N	\N	\N	1	\N	1	\N	2
443	3	2016-10-07 10:01:47	2016-10-07 10:01:47	2016-10-07 10:01:47	F	\N	\N	\N	\N	1	\N	1	\N	2
444	3	2016-10-07 12:01:46	2016-10-07 12:01:46	2016-10-07 12:01:46	F	\N	\N	\N	\N	1	\N	1	\N	2
445	3	2016-10-07 14:46:46	2016-10-07 14:46:46	2016-10-07 14:46:46	F	\N	\N	\N	\N	1	\N	1	\N	2
446	3	2016-10-07 17:46:46	2016-10-07 17:46:46	2016-10-07 17:46:46	F	\N	\N	\N	\N	1	\N	1	\N	2
447	3	2016-10-07 19:31:46	2016-10-07 19:31:46	2016-10-07 19:31:46	F	\N	\N	\N	\N	1	\N	1	\N	2
448	3	2016-10-07 22:46:45	2016-10-07 22:46:45	2016-10-07 22:46:45	F	\N	\N	\N	\N	1	\N	1	\N	2
449	3	2016-10-07 23:46:45	2016-10-07 23:46:45	2016-10-07 23:46:45	F	\N	\N	\N	\N	1	\N	1	\N	2
450	3	2016-10-08 01:46:45	2016-10-08 01:46:45	2016-10-08 01:46:45	F	\N	\N	\N	\N	1	\N	1	\N	2
451	3	2016-10-08 06:16:50	2016-10-08 06:16:50	2016-10-08 06:16:50	F	\N	\N	\N	\N	1	\N	1	\N	2
452	3	2016-10-08 08:01:50	2016-10-08 08:01:50	2016-10-08 08:01:50	F	\N	\N	\N	\N	1	\N	1	\N	2
453	3	2016-10-08 10:16:50	2016-10-08 10:16:50	2016-10-08 10:16:50	F	\N	\N	\N	\N	1	\N	1	\N	2
454	3	2016-10-08 12:16:49	2016-10-08 12:16:49	2016-10-08 12:16:49	F	\N	\N	\N	\N	1	\N	1	\N	2
455	3	2016-10-08 15:46:49	2016-10-08 15:46:49	2016-10-08 15:46:49	F	\N	\N	\N	\N	1	\N	1	\N	2
456	3	2016-10-08 18:31:49	2016-10-08 18:31:49	2016-10-08 18:31:49	F	\N	\N	\N	\N	1	\N	1	\N	2
457	3	2016-10-08 21:16:48	2016-10-08 21:16:48	2016-10-08 21:16:48	F	\N	\N	\N	\N	1	\N	1	\N	2
458	3	2016-10-08 22:46:48	2016-10-08 22:46:48	2016-10-08 22:46:48	F	\N	\N	\N	\N	1	\N	1	\N	2
459	3	2016-10-09 00:46:48	2016-10-09 00:46:48	2016-10-09 00:46:48	F	\N	\N	\N	\N	1	\N	1	\N	2
460	3	2016-10-09 05:16:48	2016-10-09 05:16:48	2016-10-09 05:16:48	F	\N	\N	\N	\N	1	\N	1	\N	2
461	3	2016-10-10 06:31:52	2016-10-10 06:31:52	2016-10-10 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	2
462	3	2016-10-10 09:31:52	2016-10-10 09:31:52	2016-10-10 09:31:52	F	\N	\N	\N	\N	1	\N	1	\N	2
463	3	2016-10-10 12:01:51	2016-10-10 12:01:51	2016-10-10 12:01:51	F	\N	\N	\N	\N	1	\N	1	\N	2
464	3	2016-10-10 13:31:51	2016-10-10 13:31:51	2016-10-10 13:31:51	F	\N	\N	\N	\N	1	\N	1	\N	2
465	3	2016-10-10 15:46:51	2016-10-10 15:46:51	2016-10-10 15:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
466	3	2016-10-10 18:31:51	2016-10-10 18:31:51	2016-10-10 18:31:51	F	\N	\N	\N	\N	1	\N	1	\N	2
467	3	2016-10-10 21:16:50	2016-10-10 21:16:50	2016-10-10 21:16:50	F	\N	\N	\N	\N	1	\N	1	\N	2
468	3	2016-10-11 00:16:50	2016-10-11 00:16:50	2016-10-11 00:16:50	F	\N	\N	\N	\N	1	\N	1	\N	2
469	3	2016-10-11 01:31:50	2016-10-11 01:31:50	2016-10-11 01:31:50	F	\N	\N	\N	\N	1	\N	1	\N	2
470	3	2016-10-11 03:46:50	2016-10-11 03:46:50	2016-10-11 03:46:50	F	\N	\N	\N	\N	1	\N	1	\N	2
471	3	2016-10-12 07:31:54	2016-10-12 07:31:54	2016-10-12 07:31:54	F	\N	\N	\N	\N	1	\N	1	\N	2
472	3	2016-10-12 09:31:54	2016-10-12 09:31:54	2016-10-12 09:31:54	F	\N	\N	\N	\N	1	\N	1	\N	2
473	3	2016-10-13 07:16:51	2016-10-13 07:16:51	2016-10-13 07:16:51	F	\N	\N	\N	\N	1	\N	1	\N	2
474	3	2016-10-13 11:01:51	2016-10-13 11:01:51	2016-10-13 11:01:51	F	\N	\N	\N	\N	1	\N	1	\N	2
475	3	2016-10-13 13:47:03	2016-10-13 13:47:03	2016-10-13 13:47:03	F	\N	\N	\N	\N	1	\N	1	\N	2
476	3	2016-10-13 15:47:03	2016-10-13 15:47:03	2016-10-13 15:47:03	F	\N	\N	\N	\N	1	\N	1	\N	2
477	3	2016-10-13 16:47:03	2016-10-13 16:47:03	2016-10-13 16:47:03	F	\N	\N	\N	\N	1	\N	1	\N	2
478	3	2016-10-13 21:02:03	2016-10-13 21:02:03	2016-10-13 21:02:03	F	\N	\N	\N	\N	1	\N	1	\N	2
479	3	2016-10-13 23:02:03	2016-10-13 23:02:03	2016-10-13 23:02:03	F	\N	\N	\N	\N	1	\N	1	\N	2
480	3	2016-10-14 01:47:02	2016-10-14 01:47:02	2016-10-14 01:47:02	F	\N	\N	\N	\N	1	\N	1	\N	2
481	3	2016-10-14 04:17:02	2016-10-14 04:17:02	2016-10-14 04:17:02	F	\N	\N	\N	\N	1	\N	1	\N	2
482	3	2016-10-14 07:46:49	2016-10-14 07:46:49	2016-10-14 07:46:49	F	\N	\N	\N	\N	1	\N	1	\N	2
483	3	2016-10-14 10:31:49	2016-10-14 10:31:49	2016-10-14 10:31:49	F	\N	\N	\N	\N	1	\N	1	\N	2
484	3	2016-10-14 11:16:49	2016-10-14 11:16:49	2016-10-14 11:16:49	F	\N	\N	\N	\N	1	\N	1	\N	2
485	3	2016-10-14 14:31:48	2016-10-14 14:31:48	2016-10-14 14:31:48	F	\N	\N	\N	\N	1	\N	1	\N	2
486	3	2016-10-14 18:01:48	2016-10-14 18:01:48	2016-10-14 18:01:48	F	\N	\N	\N	\N	1	\N	1	\N	2
487	3	2016-10-15 08:16:52	2016-10-15 08:16:52	2016-10-15 08:16:52	F	\N	\N	\N	\N	1	\N	1	\N	2
488	3	2016-10-15 10:46:52	2016-10-15 10:46:52	2016-10-15 10:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
489	3	2016-10-15 13:01:52	2016-10-15 13:01:52	2016-10-15 13:01:52	F	\N	\N	\N	\N	1	\N	1	\N	2
490	3	2016-10-15 15:31:51	2016-10-15 15:31:51	2016-10-15 15:31:51	F	\N	\N	\N	\N	1	\N	1	\N	2
491	3	2016-10-15 17:46:51	2016-10-15 17:46:51	2016-10-15 17:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
492	3	2016-10-15 20:31:51	2016-10-15 20:31:51	2016-10-15 20:31:51	F	\N	\N	\N	\N	1	\N	1	\N	2
493	3	2016-10-15 21:16:51	2016-10-15 21:16:51	2016-10-15 21:16:51	F	\N	\N	\N	\N	1	\N	1	\N	2
494	3	2016-10-16 00:16:51	2016-10-16 00:16:51	2016-10-16 00:16:51	F	\N	\N	\N	\N	1	\N	1	\N	2
495	3	2016-10-16 02:46:51	2016-10-16 02:46:51	2016-10-16 02:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
496	3	2016-10-16 07:16:48	2016-10-16 07:16:48	2016-10-16 07:16:48	F	\N	\N	\N	\N	1	\N	1	\N	2
497	3	2016-10-16 08:46:48	2016-10-16 08:46:48	2016-10-16 08:46:48	F	\N	\N	\N	\N	1	\N	1	\N	2
498	3	2016-10-16 11:01:48	2016-10-16 11:01:48	2016-10-16 11:01:48	F	\N	\N	\N	\N	1	\N	1	\N	2
499	3	2016-10-16 14:01:47	2016-10-16 14:01:47	2016-10-16 14:01:47	F	\N	\N	\N	\N	1	\N	1	\N	2
500	3	2016-10-16 15:46:47	2016-10-16 15:46:47	2016-10-16 15:46:47	F	\N	\N	\N	\N	1	\N	1	\N	2
501	3	2016-10-16 18:16:47	2016-10-16 18:16:47	2016-10-16 18:16:47	F	\N	\N	\N	\N	1	\N	1	\N	2
502	3	2016-10-16 20:01:47	2016-10-16 20:01:47	2016-10-16 20:01:47	F	\N	\N	\N	\N	1	\N	1	\N	2
503	3	2016-10-17 00:16:47	2016-10-17 00:16:47	2016-10-17 00:16:47	F	\N	\N	\N	\N	1	\N	1	\N	2
504	3	2016-10-17 02:31:46	2016-10-17 02:31:46	2016-10-17 02:31:46	F	\N	\N	\N	\N	1	\N	1	\N	2
505	3	2016-10-17 06:16:46	2016-10-17 06:16:46	2016-10-17 06:16:46	F	\N	\N	\N	\N	1	\N	1	\N	2
506	3	2016-10-18 06:31:55	2016-10-18 06:31:55	2016-10-18 06:31:55	F	\N	\N	\N	\N	1	\N	1	\N	2
507	3	2016-10-18 08:16:55	2016-10-18 08:16:55	2016-10-18 08:16:55	F	\N	\N	\N	\N	1	\N	1	\N	2
508	3	2016-10-18 12:16:55	2016-10-18 12:16:55	2016-10-18 12:16:55	F	\N	\N	\N	\N	1	\N	1	\N	2
509	3	2016-10-18 13:31:55	2016-10-18 13:31:55	2016-10-18 13:31:55	F	\N	\N	\N	\N	1	\N	1	\N	2
510	3	2016-10-18 16:31:54	2016-10-18 16:31:54	2016-10-18 16:31:54	F	\N	\N	\N	\N	1	\N	1	\N	2
511	3	2016-10-18 18:31:54	2016-10-18 18:31:54	2016-10-18 18:31:54	F	\N	\N	\N	\N	1	\N	1	\N	2
512	3	2016-10-18 22:16:54	2016-10-18 22:16:54	2016-10-18 22:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
513	3	2016-10-19 01:31:54	2016-10-19 01:31:54	2016-10-19 01:31:54	F	\N	\N	\N	\N	1	\N	1	\N	2
514	3	2016-10-19 02:16:54	2016-10-19 02:16:54	2016-10-19 02:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
515	3	2016-10-19 04:16:54	2016-10-19 04:16:54	2016-10-19 04:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
516	3	2016-10-20 06:31:52	2016-10-20 06:31:52	2016-10-20 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	2
517	3	2016-10-20 11:01:52	2016-10-20 11:01:52	2016-10-20 11:01:52	F	\N	\N	\N	\N	1	\N	1	\N	2
518	3	2016-10-20 12:46:52	2016-10-20 12:46:52	2016-10-20 12:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
519	3	2016-10-20 14:32:00	2016-10-20 14:32:00	2016-10-20 14:32:00	F	\N	\N	\N	\N	1	\N	1	\N	2
520	3	2016-10-20 18:47:00	2016-10-20 18:47:00	2016-10-20 18:47:00	F	\N	\N	\N	\N	1	\N	1	\N	2
521	3	2016-10-20 20:17:00	2016-10-20 20:17:00	2016-10-20 20:17:00	F	\N	\N	\N	\N	1	\N	1	\N	2
522	3	2016-10-20 21:47:00	2016-10-20 21:47:00	2016-10-20 21:47:00	F	\N	\N	\N	\N	1	\N	1	\N	2
523	3	2016-10-21 02:02:00	2016-10-21 02:02:00	2016-10-21 02:02:00	F	\N	\N	\N	\N	1	\N	1	\N	2
524	3	2016-10-21 03:31:59	2016-10-21 03:31:59	2016-10-21 03:31:59	F	\N	\N	\N	\N	1	\N	1	\N	2
525	3	2016-10-21 06:31:50	2016-10-21 06:31:50	2016-10-21 06:31:50	F	\N	\N	\N	\N	1	\N	1	\N	2
526	3	2016-10-21 10:01:50	2016-10-21 10:01:50	2016-10-21 10:01:50	F	\N	\N	\N	\N	1	\N	1	\N	2
527	3	2016-10-21 12:31:50	2016-10-21 12:31:50	2016-10-21 12:31:50	F	\N	\N	\N	\N	1	\N	1	\N	2
528	3	2016-10-21 14:46:50	2016-10-21 14:46:50	2016-10-21 14:46:50	F	\N	\N	\N	\N	1	\N	1	\N	2
529	3	2016-10-21 16:01:50	2016-10-21 16:01:50	2016-10-21 16:01:50	F	\N	\N	\N	\N	1	\N	1	\N	2
530	3	2016-10-21 18:31:49	2016-10-21 18:31:49	2016-10-21 18:31:49	F	\N	\N	\N	\N	1	\N	1	\N	2
531	3	2016-10-21 22:01:49	2016-10-21 22:01:49	2016-10-21 22:01:49	F	\N	\N	\N	\N	1	\N	1	\N	2
532	3	2016-10-22 00:31:49	2016-10-22 00:31:49	2016-10-22 00:31:49	F	\N	\N	\N	\N	1	\N	1	\N	2
533	3	2016-10-22 02:16:49	2016-10-22 02:16:49	2016-10-22 02:16:49	F	\N	\N	\N	\N	1	\N	1	\N	2
534	3	2016-10-22 04:01:49	2016-10-22 04:01:49	2016-10-22 04:01:49	F	\N	\N	\N	\N	1	\N	1	\N	2
535	3	2016-10-22 09:01:49	2016-10-22 09:01:49	2016-10-22 09:01:49	F	\N	\N	\N	\N	1	\N	1	\N	2
536	3	2016-10-22 11:01:49	2016-10-22 11:01:49	2016-10-22 11:01:49	F	\N	\N	\N	\N	1	\N	1	\N	2
537	3	2016-10-22 13:46:49	2016-10-22 13:46:49	2016-10-22 13:46:49	F	\N	\N	\N	\N	1	\N	1	\N	2
538	3	2016-10-22 15:31:49	2016-10-22 15:31:49	2016-10-22 15:31:49	F	\N	\N	\N	\N	1	\N	1	\N	2
539	3	2016-10-22 17:16:48	2016-10-22 17:16:48	2016-10-22 17:16:48	F	\N	\N	\N	\N	1	\N	1	\N	2
540	3	2016-10-22 20:01:48	2016-10-22 20:01:48	2016-10-22 20:01:48	F	\N	\N	\N	\N	1	\N	1	\N	2
541	3	2016-10-22 21:46:48	2016-10-22 21:46:48	2016-10-22 21:46:48	F	\N	\N	\N	\N	1	\N	1	\N	2
542	3	2016-10-23 01:31:48	2016-10-23 01:31:48	2016-10-23 01:31:48	F	\N	\N	\N	\N	1	\N	1	\N	2
543	3	2016-10-23 03:16:48	2016-10-23 03:16:48	2016-10-23 03:16:48	F	\N	\N	\N	\N	1	\N	1	\N	2
544	3	2016-10-23 07:46:47	2016-10-23 07:46:47	2016-10-23 07:46:47	F	\N	\N	\N	\N	1	\N	1	\N	2
545	3	2016-10-23 10:31:47	2016-10-23 10:31:47	2016-10-23 10:31:47	F	\N	\N	\N	\N	1	\N	1	\N	2
546	3	2016-10-23 12:46:47	2016-10-23 12:46:47	2016-10-23 12:46:47	F	\N	\N	\N	\N	1	\N	1	\N	2
547	3	2016-10-23 15:01:47	2016-10-23 15:01:47	2016-10-23 15:01:47	F	\N	\N	\N	\N	1	\N	1	\N	2
548	3	2016-10-23 17:31:46	2016-10-23 17:31:46	2016-10-23 17:31:46	F	\N	\N	\N	\N	1	\N	1	\N	2
549	3	2016-10-23 19:16:46	2016-10-23 19:16:46	2016-10-23 19:16:46	F	\N	\N	\N	\N	1	\N	1	\N	2
550	3	2016-10-23 22:46:46	2016-10-23 22:46:46	2016-10-23 22:46:46	F	\N	\N	\N	\N	1	\N	1	\N	2
551	3	2016-10-24 01:01:46	2016-10-24 01:01:46	2016-10-24 01:01:46	F	\N	\N	\N	\N	1	\N	1	\N	2
552	3	2016-10-24 03:16:46	2016-10-24 03:16:46	2016-10-24 03:16:46	F	\N	\N	\N	\N	1	\N	1	\N	2
553	3	2016-10-24 06:46:48	2016-10-24 06:46:48	2016-10-24 06:46:48	F	\N	\N	\N	\N	1	\N	1	\N	2
554	3	2016-10-24 08:16:48	2016-10-24 08:16:48	2016-10-24 08:16:48	F	\N	\N	\N	\N	1	\N	1	\N	2
555	3	2016-10-25 07:46:55	2016-10-25 07:46:55	2016-10-25 07:46:55	F	\N	\N	\N	\N	1	\N	1	\N	2
556	3	2016-10-25 11:31:55	2016-10-25 11:31:55	2016-10-25 11:31:55	F	\N	\N	\N	\N	1	\N	1	\N	2
557	3	2016-10-25 14:01:55	2016-10-25 14:01:55	2016-10-25 14:01:55	F	\N	\N	\N	\N	1	\N	1	\N	2
558	3	2016-10-25 15:01:55	2016-10-25 15:01:55	2016-10-25 15:01:55	F	\N	\N	\N	\N	1	\N	1	\N	2
559	3	2016-10-25 18:16:54	2016-10-25 18:16:54	2016-10-25 18:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
560	3	2016-10-25 22:16:54	2016-10-25 22:16:54	2016-10-25 22:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
561	3	2016-10-25 23:16:54	2016-10-25 23:16:54	2016-10-25 23:16:54	F	\N	\N	\N	\N	1	\N	1	\N	2
562	3	2016-10-26 02:46:54	2016-10-26 02:46:54	2016-10-26 02:46:54	F	\N	\N	\N	\N	1	\N	1	\N	2
563	3	2016-10-26 06:16:50	2016-10-26 06:16:50	2016-10-26 06:16:50	F	\N	\N	\N	\N	1	\N	1	\N	2
564	3	2016-10-27 07:16:56	2016-10-27 07:16:56	2016-10-27 07:16:56	F	\N	\N	\N	\N	1	\N	1	\N	2
565	3	2016-10-27 08:46:56	2016-10-27 08:46:56	2016-10-27 08:46:56	F	\N	\N	\N	\N	1	\N	1	\N	2
566	3	2016-10-27 12:16:56	2016-10-27 12:16:56	2016-10-27 12:16:56	F	\N	\N	\N	\N	1	\N	1	\N	2
567	3	2016-10-27 13:47:05	2016-10-27 13:47:05	2016-10-27 13:47:05	F	\N	\N	\N	\N	1	\N	1	\N	2
568	3	2016-10-27 16:32:05	2016-10-27 16:32:05	2016-10-27 16:32:05	F	\N	\N	\N	\N	1	\N	1	\N	2
569	3	2016-10-27 19:02:05	2016-10-27 19:02:05	2016-10-27 19:02:05	F	\N	\N	\N	\N	1	\N	1	\N	2
570	3	2016-10-27 21:47:04	2016-10-27 21:47:04	2016-10-27 21:47:04	F	\N	\N	\N	\N	1	\N	1	\N	2
571	3	2016-10-27 22:47:04	2016-10-27 22:47:04	2016-10-27 22:47:04	F	\N	\N	\N	\N	1	\N	1	\N	2
572	3	2016-10-28 03:02:04	2016-10-28 03:02:04	2016-10-28 03:02:04	F	\N	\N	\N	\N	1	\N	1	\N	2
573	3	2016-10-28 05:47:04	2016-10-28 05:47:04	2016-10-28 05:47:04	F	\N	\N	\N	\N	1	\N	1	\N	2
574	3	2016-10-29 07:46:57	2016-10-29 07:46:57	2016-10-29 07:46:57	F	\N	\N	\N	\N	1	\N	1	\N	2
575	3	2016-10-29 11:01:57	2016-10-29 11:01:57	2016-10-29 11:01:57	F	\N	\N	\N	\N	1	\N	1	\N	2
576	3	2016-10-29 13:31:57	2016-10-29 13:31:57	2016-10-29 13:31:57	F	\N	\N	\N	\N	1	\N	1	\N	2
577	3	2016-10-29 14:31:57	2016-10-29 14:31:57	2016-10-29 14:31:57	F	\N	\N	\N	\N	1	\N	1	\N	2
578	3	2016-10-29 19:01:56	2016-10-29 19:01:56	2016-10-29 19:01:56	F	\N	\N	\N	\N	1	\N	1	\N	2
579	3	2016-10-29 20:01:56	2016-10-29 20:01:56	2016-10-29 20:01:56	F	\N	\N	\N	\N	1	\N	1	\N	2
580	3	2016-10-29 21:46:56	2016-10-29 21:46:56	2016-10-29 21:46:56	F	\N	\N	\N	\N	1	\N	1	\N	2
581	3	2016-10-30 01:46:56	2016-10-30 01:46:56	2016-10-30 01:46:56	F	\N	\N	\N	\N	1	\N	1	\N	2
582	3	2016-10-30 03:16:56	2016-10-30 03:16:56	2016-10-30 03:16:56	F	\N	\N	\N	\N	1	\N	1	\N	2
583	3	2016-10-30 07:46:51	2016-10-30 07:46:51	2016-10-30 07:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
584	3	2016-10-30 09:01:51	2016-10-30 09:01:51	2016-10-30 09:01:51	F	\N	\N	\N	\N	1	\N	1	\N	2
585	3	2016-10-30 12:16:51	2016-10-30 12:16:51	2016-10-30 12:16:51	F	\N	\N	\N	\N	1	\N	1	\N	2
586	3	2016-10-30 14:16:51	2016-10-30 14:16:51	2016-10-30 14:16:51	F	\N	\N	\N	\N	1	\N	1	\N	2
587	3	2016-10-30 17:16:50	2016-10-30 17:16:50	2016-10-30 17:16:50	F	\N	\N	\N	\N	1	\N	1	\N	2
588	3	2016-10-30 19:31:50	2016-10-30 19:31:50	2016-10-30 19:31:50	F	\N	\N	\N	\N	1	\N	1	\N	2
589	3	2016-10-30 21:31:50	2016-10-30 21:31:50	2016-10-30 21:31:50	F	\N	\N	\N	\N	1	\N	1	\N	2
590	3	2016-10-30 23:31:50	2016-10-30 23:31:50	2016-10-30 23:31:50	F	\N	\N	\N	\N	1	\N	1	\N	2
591	3	2016-10-31 03:46:49	2016-10-31 03:46:49	2016-10-31 03:46:49	F	\N	\N	\N	\N	1	\N	1	\N	2
592	3	2016-10-31 06:46:52	2016-10-31 06:46:52	2016-10-31 06:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
593	3	2016-10-31 09:16:52	2016-10-31 09:16:52	2016-10-31 09:16:52	F	\N	\N	\N	\N	1	\N	1	\N	2
594	3	2016-10-31 11:46:52	2016-10-31 11:46:52	2016-10-31 11:46:52	F	\N	\N	\N	\N	1	\N	1	\N	2
595	3	2016-10-31 13:01:52	2016-10-31 13:01:52	2016-10-31 13:01:52	F	\N	\N	\N	\N	1	\N	1	\N	2
596	3	2016-10-31 14:31:52	2016-10-31 14:31:52	2016-10-31 14:31:52	F	\N	\N	\N	\N	1	\N	1	\N	2
597	3	2016-10-31 17:31:51	2016-10-31 17:31:51	2016-10-31 17:31:51	F	\N	\N	\N	\N	1	\N	1	\N	2
598	3	2016-10-31 20:46:51	2016-10-31 20:46:51	2016-10-31 20:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
599	3	2016-10-31 22:01:51	2016-10-31 22:01:51	2016-10-31 22:01:51	F	\N	\N	\N	\N	1	\N	1	\N	2
600	3	2016-11-01 00:46:51	2016-11-01 00:46:51	2016-11-01 00:46:51	F	\N	\N	\N	\N	1	\N	1	\N	2
601	4	2016-10-01 06:31:54	2016-10-01 06:31:54	2016-10-01 06:31:54	F	\N	\N	\N	\N	1	\N	1	\N	3
602	4	2016-10-01 07:01:54	2016-10-01 07:01:54	2016-10-01 07:01:54	F	\N	\N	\N	\N	1	\N	1	\N	3
603	4	2016-10-01 09:31:54	2016-10-01 09:31:54	2016-10-01 09:31:54	F	\N	\N	\N	\N	1	\N	1	\N	3
604	4	2016-10-01 13:16:53	2016-10-01 13:16:53	2016-10-01 13:16:53	F	\N	\N	\N	\N	1	\N	1	\N	3
605	4	2016-10-01 16:01:53	2016-10-01 16:01:53	2016-10-01 16:01:53	F	\N	\N	\N	\N	1	\N	1	\N	3
606	4	2016-10-01 17:31:53	2016-10-01 17:31:53	2016-10-01 17:31:53	F	\N	\N	\N	\N	1	\N	1	\N	3
607	4	2016-10-01 21:01:52	2016-10-01 21:01:52	2016-10-01 21:01:52	F	\N	\N	\N	\N	1	\N	1	\N	3
608	4	2016-10-01 23:16:52	2016-10-01 23:16:52	2016-10-01 23:16:52	F	\N	\N	\N	\N	1	\N	1	\N	3
609	4	2016-10-02 01:31:52	2016-10-02 01:31:52	2016-10-02 01:31:52	F	\N	\N	\N	\N	1	\N	1	\N	3
610	4	2016-10-02 03:16:52	2016-10-02 03:16:52	2016-10-02 03:16:52	F	\N	\N	\N	\N	1	\N	1	\N	3
611	4	2016-10-02 07:46:48	2016-10-02 07:46:48	2016-10-02 07:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
612	4	2016-10-02 09:46:48	2016-10-02 09:46:48	2016-10-02 09:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
613	4	2016-10-02 12:31:48	2016-10-02 12:31:48	2016-10-02 12:31:48	F	\N	\N	\N	\N	1	\N	1	\N	3
614	4	2016-10-03 07:01:52	2016-10-03 07:01:52	2016-10-03 07:01:52	F	\N	\N	\N	\N	1	\N	1	\N	3
615	4	2016-10-03 09:31:52	2016-10-03 09:31:52	2016-10-03 09:31:52	F	\N	\N	\N	\N	1	\N	1	\N	3
616	4	2016-10-03 12:31:52	2016-10-03 12:31:52	2016-10-03 12:31:52	F	\N	\N	\N	\N	1	\N	1	\N	3
617	4	2016-10-03 16:01:51	2016-10-03 16:01:51	2016-10-03 16:01:51	F	\N	\N	\N	\N	1	\N	1	\N	3
618	4	2016-10-03 17:46:51	2016-10-03 17:46:51	2016-10-03 17:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
619	4	2016-10-03 21:31:51	2016-10-03 21:31:51	2016-10-03 21:31:51	F	\N	\N	\N	\N	1	\N	1	\N	3
620	4	2016-10-03 23:46:50	2016-10-03 23:46:50	2016-10-03 23:46:50	F	\N	\N	\N	\N	1	\N	1	\N	3
621	4	2016-10-04 01:16:50	2016-10-04 01:16:50	2016-10-04 01:16:50	F	\N	\N	\N	\N	1	\N	1	\N	3
622	4	2016-10-04 04:46:50	2016-10-04 04:46:50	2016-10-04 04:46:50	F	\N	\N	\N	\N	1	\N	1	\N	3
623	4	2016-10-04 06:31:46	2016-10-04 06:31:46	2016-10-04 06:31:46	F	\N	\N	\N	\N	1	\N	1	\N	3
624	4	2016-10-05 09:16:53	2016-10-05 09:16:53	2016-10-05 09:16:53	F	\N	\N	\N	\N	1	\N	1	\N	3
625	4	2016-10-05 10:16:53	2016-10-05 10:16:53	2016-10-05 10:16:53	F	\N	\N	\N	\N	1	\N	1	\N	3
626	4	2016-10-05 13:01:53	2016-10-05 13:01:53	2016-10-05 13:01:53	F	\N	\N	\N	\N	1	\N	1	\N	3
627	4	2016-10-05 15:46:52	2016-10-05 15:46:52	2016-10-05 15:46:52	F	\N	\N	\N	\N	1	\N	1	\N	3
628	4	2016-10-05 19:16:52	2016-10-05 19:16:52	2016-10-05 19:16:52	F	\N	\N	\N	\N	1	\N	1	\N	3
629	4	2016-10-05 21:16:52	2016-10-05 21:16:52	2016-10-05 21:16:52	F	\N	\N	\N	\N	1	\N	1	\N	3
630	4	2016-10-06 01:01:51	2016-10-06 01:01:51	2016-10-06 01:01:51	F	\N	\N	\N	\N	1	\N	1	\N	3
631	4	2016-10-06 03:16:51	2016-10-06 03:16:51	2016-10-06 03:16:51	F	\N	\N	\N	\N	1	\N	1	\N	3
632	4	2016-10-06 05:31:51	2016-10-06 05:31:51	2016-10-06 05:31:51	F	\N	\N	\N	\N	1	\N	1	\N	3
633	4	2016-10-06 08:16:50	2016-10-06 08:16:50	2016-10-06 08:16:50	F	\N	\N	\N	\N	1	\N	1	\N	3
634	4	2016-10-06 11:31:49	2016-10-06 11:31:49	2016-10-06 11:31:49	F	\N	\N	\N	\N	1	\N	1	\N	3
635	4	2016-10-06 14:02:01	2016-10-06 14:02:01	2016-10-06 14:02:01	F	\N	\N	\N	\N	1	\N	1	\N	3
636	4	2016-10-06 14:47:01	2016-10-06 14:47:01	2016-10-06 14:47:01	F	\N	\N	\N	\N	1	\N	1	\N	3
637	4	2016-10-06 18:32:00	2016-10-06 18:32:00	2016-10-06 18:32:00	F	\N	\N	\N	\N	1	\N	1	\N	3
638	4	2016-10-06 19:32:00	2016-10-06 19:32:00	2016-10-06 19:32:00	F	\N	\N	\N	\N	1	\N	1	\N	3
639	4	2016-10-06 21:47:00	2016-10-06 21:47:00	2016-10-06 21:47:00	F	\N	\N	\N	\N	1	\N	1	\N	3
640	4	2016-10-07 01:32:00	2016-10-07 01:32:00	2016-10-07 01:32:00	F	\N	\N	\N	\N	1	\N	1	\N	3
641	4	2016-10-07 03:17:00	2016-10-07 03:17:00	2016-10-07 03:17:00	F	\N	\N	\N	\N	1	\N	1	\N	3
642	4	2016-10-07 06:16:47	2016-10-07 06:16:47	2016-10-07 06:16:47	F	\N	\N	\N	\N	1	\N	1	\N	3
643	4	2016-10-07 10:01:47	2016-10-07 10:01:47	2016-10-07 10:01:47	F	\N	\N	\N	\N	1	\N	1	\N	3
644	4	2016-10-07 11:46:46	2016-10-07 11:46:46	2016-10-07 11:46:46	F	\N	\N	\N	\N	1	\N	1	\N	3
645	4	2016-10-07 15:16:46	2016-10-07 15:16:46	2016-10-07 15:16:46	F	\N	\N	\N	\N	1	\N	1	\N	3
646	4	2016-10-07 16:31:46	2016-10-07 16:31:46	2016-10-07 16:31:46	F	\N	\N	\N	\N	1	\N	1	\N	3
647	4	2016-10-07 19:16:46	2016-10-07 19:16:46	2016-10-07 19:16:46	F	\N	\N	\N	\N	1	\N	1	\N	3
648	4	2016-10-07 22:46:45	2016-10-07 22:46:45	2016-10-07 22:46:45	F	\N	\N	\N	\N	1	\N	1	\N	3
649	4	2016-10-08 01:31:45	2016-10-08 01:31:45	2016-10-08 01:31:45	F	\N	\N	\N	\N	1	\N	1	\N	3
650	4	2016-10-08 03:31:45	2016-10-08 03:31:45	2016-10-08 03:31:45	F	\N	\N	\N	\N	1	\N	1	\N	3
651	4	2016-10-08 05:16:45	2016-10-08 05:16:45	2016-10-08 05:16:45	F	\N	\N	\N	\N	1	\N	1	\N	3
652	4	2016-10-08 08:01:50	2016-10-08 08:01:50	2016-10-08 08:01:50	F	\N	\N	\N	\N	1	\N	1	\N	3
653	4	2016-10-08 11:16:50	2016-10-08 11:16:50	2016-10-08 11:16:50	F	\N	\N	\N	\N	1	\N	1	\N	3
654	4	2016-10-08 14:16:49	2016-10-08 14:16:49	2016-10-08 14:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
655	4	2016-10-08 16:16:49	2016-10-08 16:16:49	2016-10-08 16:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
656	4	2016-10-08 18:31:49	2016-10-08 18:31:49	2016-10-08 18:31:49	F	\N	\N	\N	\N	1	\N	1	\N	3
657	4	2016-10-08 21:01:48	2016-10-08 21:01:48	2016-10-08 21:01:48	F	\N	\N	\N	\N	1	\N	1	\N	3
658	4	2016-10-09 00:16:48	2016-10-09 00:16:48	2016-10-09 00:16:48	F	\N	\N	\N	\N	1	\N	1	\N	3
659	4	2016-10-09 02:46:48	2016-10-09 02:46:48	2016-10-09 02:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
660	4	2016-10-09 03:16:48	2016-10-09 03:16:48	2016-10-09 03:16:48	F	\N	\N	\N	\N	1	\N	1	\N	3
661	4	2016-10-09 07:16:51	2016-10-09 07:16:51	2016-10-09 07:16:51	F	\N	\N	\N	\N	1	\N	1	\N	3
662	4	2016-10-10 09:31:52	2016-10-10 09:31:52	2016-10-10 09:31:52	F	\N	\N	\N	\N	1	\N	1	\N	3
663	4	2016-10-10 10:46:52	2016-10-10 10:46:52	2016-10-10 10:46:52	F	\N	\N	\N	\N	1	\N	1	\N	3
664	4	2016-10-10 13:31:51	2016-10-10 13:31:51	2016-10-10 13:31:51	F	\N	\N	\N	\N	1	\N	1	\N	3
665	4	2016-10-10 16:16:51	2016-10-10 16:16:51	2016-10-10 16:16:51	F	\N	\N	\N	\N	1	\N	1	\N	3
666	4	2016-10-10 18:46:51	2016-10-10 18:46:51	2016-10-10 18:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
667	4	2016-10-10 21:31:50	2016-10-10 21:31:50	2016-10-10 21:31:50	F	\N	\N	\N	\N	1	\N	1	\N	3
668	4	2016-10-11 00:31:50	2016-10-11 00:31:50	2016-10-11 00:31:50	F	\N	\N	\N	\N	1	\N	1	\N	3
669	4	2016-10-11 01:46:50	2016-10-11 01:46:50	2016-10-11 01:46:50	F	\N	\N	\N	\N	1	\N	1	\N	3
670	4	2016-10-11 04:46:50	2016-10-11 04:46:50	2016-10-11 04:46:50	F	\N	\N	\N	\N	1	\N	1	\N	3
671	4	2016-10-12 06:31:54	2016-10-12 06:31:54	2016-10-12 06:31:54	F	\N	\N	\N	\N	1	\N	1	\N	3
672	4	2016-10-12 10:01:54	2016-10-12 10:01:54	2016-10-12 10:01:54	F	\N	\N	\N	\N	1	\N	1	\N	3
673	4	2016-10-13 08:16:51	2016-10-13 08:16:51	2016-10-13 08:16:51	F	\N	\N	\N	\N	1	\N	1	\N	3
674	4	2016-10-13 10:16:51	2016-10-13 10:16:51	2016-10-13 10:16:51	F	\N	\N	\N	\N	1	\N	1	\N	3
675	4	2016-10-13 11:46:51	2016-10-13 11:46:51	2016-10-13 11:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
676	4	2016-10-13 15:47:03	2016-10-13 15:47:03	2016-10-13 15:47:03	F	\N	\N	\N	\N	1	\N	1	\N	3
677	4	2016-10-13 18:02:03	2016-10-13 18:02:03	2016-10-13 18:02:03	F	\N	\N	\N	\N	1	\N	1	\N	3
678	4	2016-10-13 19:47:03	2016-10-13 19:47:03	2016-10-13 19:47:03	F	\N	\N	\N	\N	1	\N	1	\N	3
679	4	2016-10-13 23:32:03	2016-10-13 23:32:03	2016-10-13 23:32:03	F	\N	\N	\N	\N	1	\N	1	\N	3
680	4	2016-10-14 01:02:02	2016-10-14 01:02:02	2016-10-14 01:02:02	F	\N	\N	\N	\N	1	\N	1	\N	3
681	4	2016-10-14 04:17:02	2016-10-14 04:17:02	2016-10-14 04:17:02	F	\N	\N	\N	\N	1	\N	1	\N	3
682	4	2016-10-14 07:01:49	2016-10-14 07:01:49	2016-10-14 07:01:49	F	\N	\N	\N	\N	1	\N	1	\N	3
683	4	2016-10-14 08:46:49	2016-10-14 08:46:49	2016-10-14 08:46:49	F	\N	\N	\N	\N	1	\N	1	\N	3
684	4	2016-10-14 11:46:49	2016-10-14 11:46:49	2016-10-14 11:46:49	F	\N	\N	\N	\N	1	\N	1	\N	3
685	4	2016-10-14 13:31:49	2016-10-14 13:31:49	2016-10-14 13:31:49	F	\N	\N	\N	\N	1	\N	1	\N	3
686	4	2016-10-14 17:31:48	2016-10-14 17:31:48	2016-10-14 17:31:48	F	\N	\N	\N	\N	1	\N	1	\N	3
687	4	2016-10-15 06:31:52	2016-10-15 06:31:52	2016-10-15 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	3
688	4	2016-10-15 09:16:52	2016-10-15 09:16:52	2016-10-15 09:16:52	F	\N	\N	\N	\N	1	\N	1	\N	3
689	4	2016-10-15 11:46:52	2016-10-15 11:46:52	2016-10-15 11:46:52	F	\N	\N	\N	\N	1	\N	1	\N	3
690	4	2016-10-15 15:01:51	2016-10-15 15:01:51	2016-10-15 15:01:51	F	\N	\N	\N	\N	1	\N	1	\N	3
691	4	2016-10-15 17:46:51	2016-10-15 17:46:51	2016-10-15 17:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
692	4	2016-10-15 20:46:51	2016-10-15 20:46:51	2016-10-15 20:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
693	4	2016-10-15 22:01:51	2016-10-15 22:01:51	2016-10-15 22:01:51	F	\N	\N	\N	\N	1	\N	1	\N	3
694	4	2016-10-16 00:46:51	2016-10-16 00:46:51	2016-10-16 00:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
695	4	2016-10-16 03:16:51	2016-10-16 03:16:51	2016-10-16 03:16:51	F	\N	\N	\N	\N	1	\N	1	\N	3
696	4	2016-10-16 05:01:51	2016-10-16 05:01:51	2016-10-16 05:01:51	F	\N	\N	\N	\N	1	\N	1	\N	3
697	4	2016-10-16 08:46:48	2016-10-16 08:46:48	2016-10-16 08:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
698	4	2016-10-16 10:31:48	2016-10-16 10:31:48	2016-10-16 10:31:48	F	\N	\N	\N	\N	1	\N	1	\N	3
699	4	2016-10-16 12:46:48	2016-10-16 12:46:48	2016-10-16 12:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
700	4	2016-10-16 15:01:47	2016-10-16 15:01:47	2016-10-16 15:01:47	F	\N	\N	\N	\N	1	\N	1	\N	3
701	4	2016-10-16 19:46:47	2016-10-16 19:46:47	2016-10-16 19:46:47	F	\N	\N	\N	\N	1	\N	1	\N	3
702	4	2016-10-16 21:31:47	2016-10-16 21:31:47	2016-10-16 21:31:47	F	\N	\N	\N	\N	1	\N	1	\N	3
703	4	2016-10-17 00:16:47	2016-10-17 00:16:47	2016-10-17 00:16:47	F	\N	\N	\N	\N	1	\N	1	\N	3
704	4	2016-10-17 03:01:46	2016-10-17 03:01:46	2016-10-17 03:01:46	F	\N	\N	\N	\N	1	\N	1	\N	3
705	4	2016-10-17 05:31:46	2016-10-17 05:31:46	2016-10-17 05:31:46	F	\N	\N	\N	\N	1	\N	1	\N	3
706	4	2016-10-18 06:46:55	2016-10-18 06:46:55	2016-10-18 06:46:55	F	\N	\N	\N	\N	1	\N	1	\N	3
707	4	2016-10-18 09:31:55	2016-10-18 09:31:55	2016-10-18 09:31:55	F	\N	\N	\N	\N	1	\N	1	\N	3
708	4	2016-10-18 10:46:55	2016-10-18 10:46:55	2016-10-18 10:46:55	F	\N	\N	\N	\N	1	\N	1	\N	3
709	4	2016-10-18 15:31:55	2016-10-18 15:31:55	2016-10-18 15:31:55	F	\N	\N	\N	\N	1	\N	1	\N	3
710	4	2016-10-18 17:46:54	2016-10-18 17:46:54	2016-10-18 17:46:54	F	\N	\N	\N	\N	1	\N	1	\N	3
711	4	2016-10-18 19:31:54	2016-10-18 19:31:54	2016-10-18 19:31:54	F	\N	\N	\N	\N	1	\N	1	\N	3
712	4	2016-10-18 21:46:54	2016-10-18 21:46:54	2016-10-18 21:46:54	F	\N	\N	\N	\N	1	\N	1	\N	3
713	4	2016-10-19 00:46:54	2016-10-19 00:46:54	2016-10-19 00:46:54	F	\N	\N	\N	\N	1	\N	1	\N	3
714	4	2016-10-19 03:46:54	2016-10-19 03:46:54	2016-10-19 03:46:54	F	\N	\N	\N	\N	1	\N	1	\N	3
715	4	2016-10-19 06:46:48	2016-10-19 06:46:48	2016-10-19 06:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
716	4	2016-10-20 07:16:52	2016-10-20 07:16:52	2016-10-20 07:16:52	F	\N	\N	\N	\N	1	\N	1	\N	3
717	4	2016-10-20 10:01:52	2016-10-20 10:01:52	2016-10-20 10:01:52	F	\N	\N	\N	\N	1	\N	1	\N	3
718	4	2016-10-20 13:32:00	2016-10-20 13:32:00	2016-10-20 13:32:00	F	\N	\N	\N	\N	1	\N	1	\N	3
719	4	2016-10-20 16:02:00	2016-10-20 16:02:00	2016-10-20 16:02:00	F	\N	\N	\N	\N	1	\N	1	\N	3
720	4	2016-10-20 17:32:00	2016-10-20 17:32:00	2016-10-20 17:32:00	F	\N	\N	\N	\N	1	\N	1	\N	3
721	4	2016-10-20 20:02:00	2016-10-20 20:02:00	2016-10-20 20:02:00	F	\N	\N	\N	\N	1	\N	1	\N	3
722	4	2016-10-20 21:47:00	2016-10-20 21:47:00	2016-10-20 21:47:00	F	\N	\N	\N	\N	1	\N	1	\N	3
723	4	2016-10-21 00:32:00	2016-10-21 00:32:00	2016-10-21 00:32:00	F	\N	\N	\N	\N	1	\N	1	\N	3
724	4	2016-10-21 05:01:59	2016-10-21 05:01:59	2016-10-21 05:01:59	F	\N	\N	\N	\N	1	\N	1	\N	3
725	4	2016-10-21 07:01:50	2016-10-21 07:01:50	2016-10-21 07:01:50	F	\N	\N	\N	\N	1	\N	1	\N	3
726	4	2016-10-21 10:16:50	2016-10-21 10:16:50	2016-10-21 10:16:50	F	\N	\N	\N	\N	1	\N	1	\N	3
727	4	2016-10-21 12:31:50	2016-10-21 12:31:50	2016-10-21 12:31:50	F	\N	\N	\N	\N	1	\N	1	\N	3
728	4	2016-10-21 15:01:50	2016-10-21 15:01:50	2016-10-21 15:01:50	F	\N	\N	\N	\N	1	\N	1	\N	3
729	4	2016-10-21 16:46:50	2016-10-21 16:46:50	2016-10-21 16:46:50	F	\N	\N	\N	\N	1	\N	1	\N	3
730	4	2016-10-21 19:16:49	2016-10-21 19:16:49	2016-10-21 19:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
731	4	2016-10-21 22:31:49	2016-10-21 22:31:49	2016-10-21 22:31:49	F	\N	\N	\N	\N	1	\N	1	\N	3
732	4	2016-10-22 00:16:49	2016-10-22 00:16:49	2016-10-22 00:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
733	4	2016-10-22 03:16:49	2016-10-22 03:16:49	2016-10-22 03:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
734	4	2016-10-22 05:31:49	2016-10-22 05:31:49	2016-10-22 05:31:49	F	\N	\N	\N	\N	1	\N	1	\N	3
735	4	2016-10-22 08:16:49	2016-10-22 08:16:49	2016-10-22 08:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
736	4	2016-10-22 10:16:49	2016-10-22 10:16:49	2016-10-22 10:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
737	4	2016-10-22 14:01:49	2016-10-22 14:01:49	2016-10-22 14:01:49	F	\N	\N	\N	\N	1	\N	1	\N	3
738	4	2016-10-22 14:31:49	2016-10-22 14:31:49	2016-10-22 14:31:49	F	\N	\N	\N	\N	1	\N	1	\N	3
739	4	2016-10-22 17:31:48	2016-10-22 17:31:48	2016-10-22 17:31:48	F	\N	\N	\N	\N	1	\N	1	\N	3
740	4	2016-10-22 20:16:48	2016-10-22 20:16:48	2016-10-22 20:16:48	F	\N	\N	\N	\N	1	\N	1	\N	3
741	4	2016-10-22 21:46:48	2016-10-22 21:46:48	2016-10-22 21:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
742	4	2016-10-23 00:31:48	2016-10-23 00:31:48	2016-10-23 00:31:48	F	\N	\N	\N	\N	1	\N	1	\N	3
743	4	2016-10-23 03:01:48	2016-10-23 03:01:48	2016-10-23 03:01:48	F	\N	\N	\N	\N	1	\N	1	\N	3
744	4	2016-10-23 05:46:48	2016-10-23 05:46:48	2016-10-23 05:46:48	F	\N	\N	\N	\N	1	\N	1	\N	3
745	4	2016-10-23 08:46:47	2016-10-23 08:46:47	2016-10-23 08:46:47	F	\N	\N	\N	\N	1	\N	1	\N	3
746	4	2016-10-23 11:31:47	2016-10-23 11:31:47	2016-10-23 11:31:47	F	\N	\N	\N	\N	1	\N	1	\N	3
747	4	2016-10-23 15:16:47	2016-10-23 15:16:47	2016-10-23 15:16:47	F	\N	\N	\N	\N	1	\N	1	\N	3
748	4	2016-10-23 17:01:46	2016-10-23 17:01:46	2016-10-23 17:01:46	F	\N	\N	\N	\N	1	\N	1	\N	3
749	4	2016-10-23 19:01:46	2016-10-23 19:01:46	2016-10-23 19:01:46	F	\N	\N	\N	\N	1	\N	1	\N	3
750	4	2016-10-23 20:31:46	2016-10-23 20:31:46	2016-10-23 20:31:46	F	\N	\N	\N	\N	1	\N	1	\N	3
751	4	2016-10-23 23:16:46	2016-10-23 23:16:46	2016-10-23 23:16:46	F	\N	\N	\N	\N	1	\N	1	\N	3
752	4	2016-10-24 04:01:46	2016-10-24 04:01:46	2016-10-24 04:01:46	F	\N	\N	\N	\N	1	\N	1	\N	3
753	4	2016-10-24 05:31:46	2016-10-24 05:31:46	2016-10-24 05:31:46	F	\N	\N	\N	\N	1	\N	1	\N	3
754	4	2016-10-25 06:31:55	2016-10-25 06:31:55	2016-10-25 06:31:55	F	\N	\N	\N	\N	1	\N	1	\N	3
755	4	2016-10-25 08:31:55	2016-10-25 08:31:55	2016-10-25 08:31:55	F	\N	\N	\N	\N	1	\N	1	\N	3
756	4	2016-10-25 11:16:55	2016-10-25 11:16:55	2016-10-25 11:16:55	F	\N	\N	\N	\N	1	\N	1	\N	3
757	4	2016-10-25 13:46:55	2016-10-25 13:46:55	2016-10-25 13:46:55	F	\N	\N	\N	\N	1	\N	1	\N	3
758	4	2016-10-25 15:16:55	2016-10-25 15:16:55	2016-10-25 15:16:55	F	\N	\N	\N	\N	1	\N	1	\N	3
759	4	2016-10-25 19:31:54	2016-10-25 19:31:54	2016-10-25 19:31:54	F	\N	\N	\N	\N	1	\N	1	\N	3
760	4	2016-10-25 21:01:54	2016-10-25 21:01:54	2016-10-25 21:01:54	F	\N	\N	\N	\N	1	\N	1	\N	3
761	4	2016-10-25 23:01:54	2016-10-25 23:01:54	2016-10-25 23:01:54	F	\N	\N	\N	\N	1	\N	1	\N	3
762	4	2016-10-26 01:16:54	2016-10-26 01:16:54	2016-10-26 01:16:54	F	\N	\N	\N	\N	1	\N	1	\N	3
763	4	2016-10-26 04:16:53	2016-10-26 04:16:53	2016-10-26 04:16:53	F	\N	\N	\N	\N	1	\N	1	\N	3
764	4	2016-10-27 06:31:56	2016-10-27 06:31:56	2016-10-27 06:31:56	F	\N	\N	\N	\N	1	\N	1	\N	3
765	4	2016-10-27 09:16:56	2016-10-27 09:16:56	2016-10-27 09:16:56	F	\N	\N	\N	\N	1	\N	1	\N	3
766	4	2016-10-27 10:46:56	2016-10-27 10:46:56	2016-10-27 10:46:56	F	\N	\N	\N	\N	1	\N	1	\N	3
767	4	2016-10-27 14:47:05	2016-10-27 14:47:05	2016-10-27 14:47:05	F	\N	\N	\N	\N	1	\N	1	\N	3
768	4	2016-10-27 16:47:05	2016-10-27 16:47:05	2016-10-27 16:47:05	F	\N	\N	\N	\N	1	\N	1	\N	3
769	4	2016-10-27 18:02:05	2016-10-27 18:02:05	2016-10-27 18:02:05	F	\N	\N	\N	\N	1	\N	1	\N	3
770	4	2016-10-27 21:02:04	2016-10-27 21:02:04	2016-10-27 21:02:04	F	\N	\N	\N	\N	1	\N	1	\N	3
771	4	2016-10-27 22:47:04	2016-10-27 22:47:04	2016-10-27 22:47:04	F	\N	\N	\N	\N	1	\N	1	\N	3
772	4	2016-10-28 03:17:04	2016-10-28 03:17:04	2016-10-28 03:17:04	F	\N	\N	\N	\N	1	\N	1	\N	3
773	4	2016-10-28 06:16:49	2016-10-28 06:16:49	2016-10-28 06:16:49	F	\N	\N	\N	\N	1	\N	1	\N	3
774	4	2016-10-29 08:46:57	2016-10-29 08:46:57	2016-10-29 08:46:57	F	\N	\N	\N	\N	1	\N	1	\N	3
775	4	2016-10-29 10:31:57	2016-10-29 10:31:57	2016-10-29 10:31:57	F	\N	\N	\N	\N	1	\N	1	\N	3
776	4	2016-10-29 12:46:57	2016-10-29 12:46:57	2016-10-29 12:46:57	F	\N	\N	\N	\N	1	\N	1	\N	3
777	4	2016-10-29 14:31:57	2016-10-29 14:31:57	2016-10-29 14:31:57	F	\N	\N	\N	\N	1	\N	1	\N	3
778	4	2016-10-29 16:46:56	2016-10-29 16:46:56	2016-10-29 16:46:56	F	\N	\N	\N	\N	1	\N	1	\N	3
779	4	2016-10-29 19:46:56	2016-10-29 19:46:56	2016-10-29 19:46:56	F	\N	\N	\N	\N	1	\N	1	\N	3
780	4	2016-10-29 22:16:56	2016-10-29 22:16:56	2016-10-29 22:16:56	F	\N	\N	\N	\N	1	\N	1	\N	3
781	4	2016-10-30 01:01:56	2016-10-30 01:01:56	2016-10-30 01:01:56	F	\N	\N	\N	\N	1	\N	1	\N	3
782	4	2016-10-30 03:01:56	2016-10-30 03:01:56	2016-10-30 03:01:56	F	\N	\N	\N	\N	1	\N	1	\N	3
783	4	2016-10-30 05:46:55	2016-10-30 05:46:55	2016-10-30 05:46:55	F	\N	\N	\N	\N	1	\N	1	\N	3
784	4	2016-10-30 09:46:51	2016-10-30 09:46:51	2016-10-30 09:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
785	4	2016-10-30 11:46:51	2016-10-30 11:46:51	2016-10-30 11:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
786	4	2016-10-30 13:46:51	2016-10-30 13:46:51	2016-10-30 13:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
787	4	2016-10-30 16:01:51	2016-10-30 16:01:51	2016-10-30 16:01:51	F	\N	\N	\N	\N	1	\N	1	\N	3
788	4	2016-10-30 18:46:50	2016-10-30 18:46:50	2016-10-30 18:46:50	F	\N	\N	\N	\N	1	\N	1	\N	3
789	4	2016-10-30 22:01:50	2016-10-30 22:01:50	2016-10-30 22:01:50	F	\N	\N	\N	\N	1	\N	1	\N	3
790	4	2016-10-31 00:16:50	2016-10-31 00:16:50	2016-10-31 00:16:50	F	\N	\N	\N	\N	1	\N	1	\N	3
791	4	2016-10-31 03:31:50	2016-10-31 03:31:50	2016-10-31 03:31:50	F	\N	\N	\N	\N	1	\N	1	\N	3
792	4	2016-10-31 06:31:52	2016-10-31 06:31:52	2016-10-31 06:31:52	F	\N	\N	\N	\N	1	\N	1	\N	3
793	4	2016-10-31 07:31:52	2016-10-31 07:31:52	2016-10-31 07:31:52	F	\N	\N	\N	\N	1	\N	1	\N	3
794	4	2016-10-31 11:01:52	2016-10-31 11:01:52	2016-10-31 11:01:52	F	\N	\N	\N	\N	1	\N	1	\N	3
795	4	2016-10-31 13:01:52	2016-10-31 13:01:52	2016-10-31 13:01:52	F	\N	\N	\N	\N	1	\N	1	\N	3
796	4	2016-10-31 16:46:51	2016-10-31 16:46:51	2016-10-31 16:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
797	4	2016-10-31 18:46:51	2016-10-31 18:46:51	2016-10-31 18:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
798	4	2016-10-31 20:31:51	2016-10-31 20:31:51	2016-10-31 20:31:51	F	\N	\N	\N	\N	1	\N	1	\N	3
799	4	2016-10-31 22:46:51	2016-10-31 22:46:51	2016-10-31 22:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
800	4	2016-11-01 00:46:51	2016-11-01 00:46:51	2016-11-01 00:46:51	F	\N	\N	\N	\N	1	\N	1	\N	3
\.


--
-- TOC entry 3976 (class 0 OID 20620)
-- Dependencies: 219
-- Data for Name: observationconstellation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY observationconstellation (observationconstellationid, observablepropertyid, procedureid, observationtypeid, offeringid, deleted, hiddenchild) FROM stdin;
1	1	1	1	1	F	F
4	4	1	1	1	F	F
3	3	1	1	1	F	F
2	2	1	1	1	F	F
\.


--
-- TOC entry 4182 (class 0 OID 0)
-- Dependencies: 242
-- Name: observationconstellationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observationconstellationid_seq', 4, true);


--
-- TOC entry 3977 (class 0 OID 20629)
-- Dependencies: 220
-- Data for Name: observationhasoffering; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY observationhasoffering (observationid, offeringid) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
8	1
9	1
10	1
11	1
12	1
13	1
14	1
15	1
16	1
17	1
18	1
19	1
20	1
21	1
22	1
23	1
24	1
25	1
26	1
27	1
28	1
29	1
30	1
31	1
32	1
33	1
34	1
35	1
36	1
37	1
38	1
39	1
40	1
41	1
42	1
43	1
44	1
45	1
46	1
47	1
48	1
49	1
50	1
51	1
52	1
53	1
54	1
55	1
56	1
57	1
58	1
59	1
60	1
61	1
62	1
63	1
64	1
65	1
66	1
67	1
68	1
69	1
70	1
71	1
72	1
73	1
74	1
75	1
76	1
77	1
78	1
79	1
80	1
81	1
82	1
83	1
84	1
85	1
86	1
87	1
88	1
89	1
90	1
91	1
92	1
93	1
94	1
95	1
96	1
97	1
98	1
99	1
100	1
101	1
102	1
103	1
104	1
105	1
106	1
107	1
108	1
109	1
110	1
111	1
112	1
113	1
114	1
115	1
116	1
117	1
118	1
119	1
120	1
121	1
122	1
123	1
124	1
125	1
126	1
127	1
128	1
129	1
130	1
131	1
132	1
133	1
134	1
135	1
136	1
137	1
138	1
139	1
140	1
141	1
142	1
143	1
144	1
145	1
146	1
147	1
148	1
149	1
150	1
151	1
152	1
153	1
154	1
155	1
156	1
157	1
158	1
159	1
160	1
161	1
162	1
163	1
164	1
165	1
166	1
167	1
168	1
169	1
170	1
171	1
172	1
173	1
174	1
175	1
176	1
177	1
178	1
179	1
180	1
181	1
182	1
183	1
184	1
185	1
186	1
187	1
188	1
189	1
190	1
191	1
192	1
193	1
194	1
195	1
196	1
197	1
198	1
199	1
200	1
201	1
202	1
203	1
204	1
205	1
206	1
207	1
208	1
209	1
210	1
211	1
212	1
213	1
214	1
215	1
216	1
217	1
218	1
219	1
220	1
221	1
222	1
223	1
224	1
225	1
226	1
227	1
228	1
229	1
230	1
231	1
232	1
233	1
234	1
235	1
236	1
237	1
238	1
239	1
240	1
241	1
242	1
243	1
244	1
245	1
246	1
247	1
248	1
249	1
250	1
251	1
252	1
253	1
254	1
255	1
256	1
257	1
258	1
259	1
260	1
261	1
262	1
263	1
264	1
265	1
266	1
267	1
268	1
269	1
270	1
271	1
272	1
273	1
274	1
275	1
276	1
277	1
278	1
279	1
280	1
281	1
282	1
283	1
284	1
285	1
286	1
287	1
288	1
289	1
290	1
291	1
292	1
293	1
294	1
295	1
296	1
297	1
298	1
299	1
300	1
301	1
302	1
303	1
304	1
305	1
306	1
307	1
308	1
309	1
310	1
311	1
312	1
313	1
314	1
315	1
316	1
317	1
318	1
319	1
320	1
321	1
322	1
323	1
324	1
325	1
326	1
327	1
328	1
329	1
330	1
331	1
332	1
333	1
334	1
335	1
336	1
337	1
338	1
339	1
340	1
341	1
342	1
343	1
344	1
345	1
346	1
347	1
348	1
349	1
350	1
351	1
352	1
353	1
354	1
355	1
356	1
357	1
358	1
359	1
360	1
361	1
362	1
363	1
364	1
365	1
366	1
367	1
368	1
369	1
370	1
371	1
372	1
373	1
374	1
375	1
376	1
377	1
378	1
379	1
380	1
381	1
382	1
383	1
384	1
385	1
386	1
387	1
388	1
389	1
390	1
391	1
392	1
393	1
394	1
395	1
396	1
397	1
398	1
399	1
400	1
401	1
402	1
403	1
404	1
405	1
406	1
407	1
408	1
409	1
410	1
411	1
412	1
413	1
414	1
415	1
416	1
417	1
418	1
419	1
420	1
421	1
422	1
423	1
424	1
425	1
426	1
427	1
428	1
429	1
430	1
431	1
432	1
433	1
434	1
435	1
436	1
437	1
438	1
439	1
440	1
441	1
442	1
443	1
444	1
445	1
446	1
447	1
448	1
449	1
450	1
451	1
452	1
453	1
454	1
455	1
456	1
457	1
458	1
459	1
460	1
461	1
462	1
463	1
464	1
465	1
466	1
467	1
468	1
469	1
470	1
471	1
472	1
473	1
474	1
475	1
476	1
477	1
478	1
479	1
480	1
481	1
482	1
483	1
484	1
485	1
486	1
487	1
488	1
489	1
490	1
491	1
492	1
493	1
494	1
495	1
496	1
497	1
498	1
499	1
500	1
501	1
502	1
503	1
504	1
505	1
506	1
507	1
508	1
509	1
510	1
511	1
512	1
513	1
514	1
515	1
516	1
517	1
518	1
519	1
520	1
521	1
522	1
523	1
524	1
525	1
526	1
527	1
528	1
529	1
530	1
531	1
532	1
533	1
534	1
535	1
536	1
537	1
538	1
539	1
540	1
541	1
542	1
543	1
544	1
545	1
546	1
547	1
548	1
549	1
550	1
551	1
552	1
553	1
554	1
555	1
556	1
557	1
558	1
559	1
560	1
561	1
562	1
563	1
564	1
565	1
566	1
567	1
568	1
569	1
570	1
571	1
572	1
573	1
574	1
575	1
576	1
577	1
578	1
579	1
580	1
581	1
582	1
583	1
584	1
585	1
586	1
587	1
588	1
589	1
590	1
591	1
592	1
593	1
594	1
595	1
596	1
597	1
598	1
599	1
600	1
601	1
602	1
603	1
604	1
605	1
606	1
607	1
608	1
609	1
610	1
611	1
612	1
613	1
614	1
615	1
616	1
617	1
618	1
619	1
620	1
621	1
622	1
623	1
624	1
625	1
626	1
627	1
628	1
629	1
630	1
631	1
632	1
633	1
634	1
635	1
636	1
637	1
638	1
639	1
640	1
641	1
642	1
643	1
644	1
645	1
646	1
647	1
648	1
649	1
650	1
651	1
652	1
653	1
654	1
655	1
656	1
657	1
658	1
659	1
660	1
661	1
662	1
663	1
664	1
665	1
666	1
667	1
668	1
669	1
670	1
671	1
672	1
673	1
674	1
675	1
676	1
677	1
678	1
679	1
680	1
681	1
682	1
683	1
684	1
685	1
686	1
687	1
688	1
689	1
690	1
691	1
692	1
693	1
694	1
695	1
696	1
697	1
698	1
699	1
700	1
701	1
702	1
703	1
704	1
705	1
706	1
707	1
708	1
709	1
710	1
711	1
712	1
713	1
714	1
715	1
716	1
717	1
718	1
719	1
720	1
721	1
722	1
723	1
724	1
725	1
726	1
727	1
728	1
729	1
730	1
731	1
732	1
733	1
734	1
735	1
736	1
737	1
738	1
739	1
740	1
741	1
742	1
743	1
744	1
745	1
746	1
747	1
748	1
749	1
750	1
751	1
752	1
753	1
754	1
755	1
756	1
757	1
758	1
759	1
760	1
761	1
762	1
763	1
764	1
765	1
766	1
767	1
768	1
769	1
770	1
771	1
772	1
773	1
774	1
775	1
776	1
777	1
778	1
779	1
780	1
781	1
782	1
783	1
784	1
785	1
786	1
787	1
788	1
789	1
790	1
791	1
792	1
793	1
794	1
795	1
796	1
797	1
798	1
799	1
800	1
\.


--
-- TOC entry 4183 (class 0 OID 0)
-- Dependencies: 243
-- Name: observationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observationid_seq', 800, true);


--
-- TOC entry 3978 (class 0 OID 20634)
-- Dependencies: 221
-- Data for Name: observationtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY observationtype (observationtypeid, observationtype) FROM stdin;
1	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement
\.


--
-- TOC entry 4184 (class 0 OID 0)
-- Dependencies: 244
-- Name: observationtypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observationtypeid_seq', 1, true);


--
-- TOC entry 3979 (class 0 OID 20639)
-- Dependencies: 222
-- Data for Name: offering; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY offering (offeringid, hibernatediscriminator, identifier, codespace, name, codespacename, description, disabled) FROM stdin;
1	T	wxt520	\N	field_0	\N	\N	F
\.


--
-- TOC entry 3980 (class 0 OID 20649)
-- Dependencies: 223
-- Data for Name: offeringallowedfeaturetype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY offeringallowedfeaturetype (offeringid, featureofinteresttypeid) FROM stdin;
1	1
\.


--
-- TOC entry 3981 (class 0 OID 20654)
-- Dependencies: 224
-- Data for Name: offeringallowedobservationtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY offeringallowedobservationtype (offeringid, observationtypeid) FROM stdin;
1	1
\.


--
-- TOC entry 3982 (class 0 OID 20659)
-- Dependencies: 225
-- Data for Name: offeringhasrelatedfeature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY offeringhasrelatedfeature (relatedfeatureid, offeringid) FROM stdin;
\.


--
-- TOC entry 4185 (class 0 OID 0)
-- Dependencies: 245
-- Name: offeringid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('offeringid_seq', 1, true);


--
-- TOC entry 3983 (class 0 OID 20664)
-- Dependencies: 226
-- Data for Name: parameter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY parameter (parameterid, observationid, definition, title, value) FROM stdin;
\.


--
-- TOC entry 4186 (class 0 OID 0)
-- Dependencies: 246
-- Name: parameterid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('parameterid_seq', 1, false);


--
-- TOC entry 4187 (class 0 OID 0)
-- Dependencies: 247
-- Name: procdescformatid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('procdescformatid_seq', 1, true);


--
-- TOC entry 3962 (class 0 OID 20523)
-- Dependencies: 205
-- Data for Name: procedure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY procedure (procedureid, hibernatediscriminator, proceduredescriptionformatid, identifier, codespace, name, codespacename, description, deleted, disabled, descriptionfile, referenceflag) FROM stdin;
1	T	1	wxt520	\N	\N	\N	\N	F	F	\N	F
\.


--
-- TOC entry 3984 (class 0 OID 20672)
-- Dependencies: 227
-- Data for Name: proceduredescriptionformat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY proceduredescriptionformat (proceduredescriptionformatid, proceduredescriptionformat) FROM stdin;
1	http://www.opengis.net/sensorML/1.0.1
\.


--
-- TOC entry 4188 (class 0 OID 0)
-- Dependencies: 248
-- Name: procedureid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('procedureid_seq', 1, true);


--
-- TOC entry 3985 (class 0 OID 20677)
-- Dependencies: 228
-- Data for Name: relatedfeature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY relatedfeature (relatedfeatureid, featureofinterestid) FROM stdin;
\.


--
-- TOC entry 3986 (class 0 OID 20682)
-- Dependencies: 229
-- Data for Name: relatedfeaturehasrole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY relatedfeaturehasrole (relatedfeatureid, relatedfeatureroleid) FROM stdin;
\.


--
-- TOC entry 4189 (class 0 OID 0)
-- Dependencies: 249
-- Name: relatedfeatureid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('relatedfeatureid_seq', 1, false);


--
-- TOC entry 3987 (class 0 OID 20687)
-- Dependencies: 230
-- Data for Name: relatedfeaturerole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY relatedfeaturerole (relatedfeatureroleid, relatedfeaturerole) FROM stdin;
\.


--
-- TOC entry 4190 (class 0 OID 0)
-- Dependencies: 250
-- Name: relatedfeatureroleid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('relatedfeatureroleid_seq', 1, false);


--
-- TOC entry 3988 (class 0 OID 20692)
-- Dependencies: 231
-- Data for Name: resulttemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY resulttemplate (resulttemplateid, offeringid, observablepropertyid, procedureid, featureofinterestid, identifier, resultstructure, resultencoding) FROM stdin;
\.


--
-- TOC entry 4191 (class 0 OID 0)
-- Dependencies: 251
-- Name: resulttemplateid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('resulttemplateid_seq', 1, false);


--
-- TOC entry 3989 (class 0 OID 20700)
-- Dependencies: 232
-- Data for Name: sensorsystem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sensorsystem (parentsensorid, childsensorid) FROM stdin;
\.


--
-- TOC entry 3990 (class 0 OID 20705)
-- Dependencies: 233
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY series (seriesid, featureofinterestid, observablepropertyid, procedureid, offeringid, deleted, published, firsttimestamp, lasttimestamp, firstnumericvalue, lastnumericvalue, unitid) FROM stdin;
1	1	1	1	1	F	T	2016-10-01 06:31:54	2016-11-01 00:46:51	12.5	6.79999999999999982	1
4	1	2	1	1	F	T	2016-10-01 06:31:54	2016-11-01 00:46:51	1003.20000000000005	1017.5	3
2	1	4	1	1	F	T	2016-10-01 06:31:54	2016-11-01 00:46:51	12.5	6.79999999999999982	1
3	1	3	1	1	F	T	2016-10-01 06:31:54	2016-11-01 00:46:51	85	90	2
\.


--
-- TOC entry 4192 (class 0 OID 0)
-- Dependencies: 252
-- Name: seriesid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seriesid_seq', 4, true);


--
-- TOC entry 3649 (class 0 OID 18738)
-- Dependencies: 185
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY spatial_ref_sys  FROM stdin;
\.


--
-- TOC entry 3991 (class 0 OID 20714)
-- Dependencies: 234
-- Data for Name: swedataarrayvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY swedataarrayvalue (observationid, value) FROM stdin;
\.


--
-- TOC entry 3992 (class 0 OID 20722)
-- Dependencies: 235
-- Data for Name: textvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY textvalue (observationid, value) FROM stdin;
\.


--
-- TOC entry 3993 (class 0 OID 20730)
-- Dependencies: 236
-- Data for Name: unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY unit (unitid, unit) FROM stdin;
1	degC
2	%
3	hPa
\.


--
-- TOC entry 4193 (class 0 OID 0)
-- Dependencies: 253
-- Name: unitid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('unitid_seq', 3, true);


--
-- TOC entry 3994 (class 0 OID 20735)
-- Dependencies: 237
-- Data for Name: validproceduretime; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY validproceduretime (validproceduretimeid, procedureid, proceduredescriptionformatid, starttime, endtime, descriptionxml) FROM stdin;
1	1	1	2016-11-17 13:54:47.426	\N	<sml:SensorML xmlns:sml="http://www.opengis.net/sensorML/1.0.1" xmlns:gml="http://www.opengis.net/gml" xmlns:swe="http://www.opengis.net/swe/1.0.1" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.0.1">\n  <sml:member>\n    <sml:System>\n      <sml:keywords>\n        <sml:KeywordList>\n          <sml:keyword>AirTemperature</sml:keyword>\n          <sml:keyword>WindSpeedAverage</sml:keyword>\n          <sml:keyword>WindDirectionMaximum</sml:keyword>\n          <sml:keyword>HailAccumulated</sml:keyword>\n          <sml:keyword>Vaisala-WXT520</sml:keyword>\n          <sml:keyword>RainfallPeakIntensity</sml:keyword>\n          <sml:keyword>Humidity</sml:keyword>\n          <sml:keyword>HailPeakIntensity</sml:keyword>\n          <sml:keyword>WindSpeedMinimum</sml:keyword>\n          <sml:keyword>RainfallDuration</sml:keyword>\n          <sml:keyword>wxt520</sml:keyword>\n          <sml:keyword>RainfallAccumulated</sml:keyword>\n          <sml:keyword>WindSpeedMaximum</sml:keyword>\n          <sml:keyword>InSystemTemperature</sml:keyword>\n          <sml:keyword>HailDuration</sml:keyword>\n          <sml:keyword>WindDirectionMinimum</sml:keyword>\n          <sml:keyword>Vaisala_WXT520</sml:keyword>\n          <sml:keyword>HailIntensity</sml:keyword>\n          <sml:keyword>RainfallIntensity</sml:keyword>\n          <sml:keyword>52n-wxt520</sml:keyword>\n          <sml:keyword>AthmosphericPressure</sml:keyword>\n          <sml:keyword>WindDirectionAverage</sml:keyword>\n        </sml:KeywordList>\n      </sml:keywords>\n      <sml:identification>\n        <sml:IdentifierList>\n          <sml:identifier name="uniqueID">\n            <sml:Term definition="urn:ogc:def:identifier:OGC:1.0:uniqueID">\n              <sml:value>wxt520</sml:value>\n            </sml:Term>\n          </sml:identifier>\n          <sml:identifier name="longName">\n            <sml:Term definition="urn:ogc:def:identifier:OGC:1.0:longName">\n              <sml:value>52n-wxt520</sml:value>\n            </sml:Term>\n          </sml:identifier>\n          <sml:identifier name="shortName">\n            <sml:Term definition="urn:ogc:def:identifier:OGC:1.0:shortName">\n              <sml:value>52n-wxt520</sml:value>\n            </sml:Term>\n          </sml:identifier>\n        </sml:IdentifierList>\n      </sml:identification>\n      <sml:classification>\n        <sml:ClassifierList>\n          <sml:classifier name="intendedApplication">\n            <sml:Term definition="urn:ogc:def:classifier:OGC:1.0:application">\n              <sml:value>HailAccumulated, WindSpeedMinimum, AirTemperature, WindSpeedAverage, HailIntensity, RainfallAccumulated, RainfallPeakIntensity, WindSpeedMaximum, WindDirectionMaximum, Humidity, RainfallIntensity, WindDirectionMinimum, HailDuration, RainfallDuration, InSystemTemperature, AthmosphericPressure, HailPeakIntensity, WindDirectionAverage</sml:value>\n            </sml:Term>\n          </sml:classifier>\n        </sml:ClassifierList>\n      </sml:classification>\n      <sml:validTime>\n        <gml:TimePeriod>\n          <gml:beginPosition>2015-05-18T13:42:21.149Z</gml:beginPosition>\n          <gml:endPosition indeterminatePosition="unknown"/>\n        </gml:TimePeriod>\n      </sml:validTime>\n      <sml:capabilities name="featuresOfInterest">\n        <swe:DataRecord>\n          <swe:field name="featureOfInterestID">\n            <swe:Text definition="http://www.opengis.net/def/featureOfInterest/identifier">\n              <swe:value>Vaisala-WXT520</swe:value>\n            </swe:Text>\n          </swe:field>\n        </swe:DataRecord>\n      </sml:capabilities>\n      <sml:capabilities name="collectingStatus">\n        <swe:DataRecord>\n          <swe:field name="status">\n            <swe:Boolean definition="urn:ogc:def:classifier:OGC:1.0:collectingStatus">\n              <swe:value>true</swe:value>\n            </swe:Boolean>\n          </swe:field>\n        </swe:DataRecord>\n      </sml:capabilities>\n      <sml:capabilities name="observedBBOX">\n        <swe:DataRecord>\n          <swe:field name="observedBBOX">\n            <swe:Envelope definition="urn:ogc:def:property:OGC:1.0:observedBBOX" referenceFrame="4326">\n              <swe:lowerCorner>\n                <swe:Vector>\n                  <swe:coordinate name="easting">\n                    <swe:Quantity axisID="x">\n                      <swe:uom code="degree"/>\n                      <swe:value>7.65237522125244</swe:value>\n                    </swe:Quantity>\n                  </swe:coordinate>\n                  <swe:coordinate name="northing">\n                    <swe:Quantity axisID="y">\n                      <swe:uom code="degree"/>\n                      <swe:value>51.9347763061523</swe:value>\n                    </swe:Quantity>\n                  </swe:coordinate>\n                </swe:Vector>\n              </swe:lowerCorner>\n              <swe:upperCorner>\n                <swe:Vector>\n                  <swe:coordinate name="easting">\n                    <swe:Quantity axisID="x">\n                      <swe:uom code="degree"/>\n                      <swe:value>7.652375221252441</swe:value>\n                    </swe:Quantity>\n                  </swe:coordinate>\n                  <swe:coordinate name="northing">\n                    <swe:Quantity axisID="y">\n                      <swe:uom code="degree"/>\n                      <swe:value>51.934776306152344</swe:value>\n                    </swe:Quantity>\n                  </swe:coordinate>\n                </swe:Vector>\n              </swe:upperCorner>\n            </swe:Envelope>\n          </swe:field>\n        </swe:DataRecord>\n      </sml:capabilities>\n      <sml:contact>\n        <sml:ContactList>\n          <sml:member xlink:role="Point of Contact">\n            <sml:ResponsibleParty>\n              <sml:individualName>Jürrens, Eike Hinderk</sml:individualName>\n              <sml:organizationName>52North</sml:organizationName>\n              <sml:positionName>Service Maintainer</sml:positionName>\n              <sml:contactInfo>\n                <sml:phone>\n                  <sml:voice>+49(0)251/396 371-33</sml:voice>\n                </sml:phone>\n                <sml:address>\n                  <sml:deliveryPoint>Martin-Luther-King-Weg 24</sml:deliveryPoint>\n                  <sml:city>Münster</sml:city>\n                  <sml:postalCode>48155</sml:postalCode>\n                  <sml:country>Germany</sml:country>\n                  <sml:electronicMailAddress>e.h.juerrens@52north.org</sml:electronicMailAddress>\n                </sml:address>\n                <sml:onlineResource xlink:href="http://52north.org/"/>\n              </sml:contactInfo>\n            </sml:ResponsibleParty>\n          </sml:member>\n        </sml:ContactList>\n      </sml:contact>\n      <sml:position name="sensorPosition">\n        <swe:Position fixed="false" referenceFrame="urn:ogc:def:crs:EPSG::4326">\n          <swe:location>\n            <swe:Vector>\n              <swe:coordinate name="northing">\n                <swe:Quantity axisID="y">\n                  <swe:uom code="degree"/>\n                  <swe:value>51.934776306152344</swe:value>\n                </swe:Quantity>\n              </swe:coordinate>\n              <swe:coordinate name="easting">\n                <swe:Quantity axisID="x">\n                  <swe:uom code="degree"/>\n                  <swe:value>7.652375221252441</swe:value>\n                </swe:Quantity>\n              </swe:coordinate>\n              <swe:coordinate name="altitude">\n                <swe:Quantity axisID="z">\n                  <swe:uom code="UNIT_NOT_SET"/>\n                  <swe:value>-INF</swe:value>\n                </swe:Quantity>\n              </swe:coordinate>\n            </swe:Vector>\n          </swe:location>\n        </swe:Position>\n      </sml:position>\n      <sml:inputs>\n        <sml:InputList>\n          <sml:input name="HailAccumulated">\n            <swe:ObservableProperty definition="HailAccumulated"/>\n          </sml:input>\n          <sml:input name="WindSpeedMinimum">\n            <swe:ObservableProperty definition="WindSpeedMinimum"/>\n          </sml:input>\n          <sml:input name="AirTemperature">\n            <swe:ObservableProperty definition="AirTemperature"/>\n          </sml:input>\n          <sml:input name="WindSpeedAverage">\n            <swe:ObservableProperty definition="WindSpeedAverage"/>\n          </sml:input>\n          <sml:input name="HailIntensity">\n            <swe:ObservableProperty definition="HailIntensity"/>\n          </sml:input>\n          <sml:input name="RainfallAccumulated">\n            <swe:ObservableProperty definition="RainfallAccumulated"/>\n          </sml:input>\n          <sml:input name="RainfallPeakIntensity">\n            <swe:ObservableProperty definition="RainfallPeakIntensity"/>\n          </sml:input>\n          <sml:input name="WindSpeedMaximum">\n            <swe:ObservableProperty definition="WindSpeedMaximum"/>\n          </sml:input>\n          <sml:input name="WindDirectionMaximum">\n            <swe:ObservableProperty definition="WindDirectionMaximum"/>\n          </sml:input>\n          <sml:input name="Humidity">\n            <swe:ObservableProperty definition="Humidity"/>\n          </sml:input>\n          <sml:input name="RainfallIntensity">\n            <swe:ObservableProperty definition="RainfallIntensity"/>\n          </sml:input>\n          <sml:input name="WindDirectionMinimum">\n            <swe:ObservableProperty definition="WindDirectionMinimum"/>\n          </sml:input>\n          <sml:input name="HailDuration">\n            <swe:ObservableProperty definition="HailDuration"/>\n          </sml:input>\n          <sml:input name="RainfallDuration">\n            <swe:ObservableProperty definition="RainfallDuration"/>\n          </sml:input>\n          <sml:input name="InSystemTemperature">\n            <swe:ObservableProperty definition="InSystemTemperature"/>\n          </sml:input>\n          <sml:input name="AthmosphericPressure">\n            <swe:ObservableProperty definition="AthmosphericPressure"/>\n          </sml:input>\n          <sml:input name="HailPeakIntensity">\n            <swe:ObservableProperty definition="HailPeakIntensity"/>\n          </sml:input>\n          <sml:input name="WindDirectionAverage">\n            <swe:ObservableProperty definition="WindDirectionAverage"/>\n          </sml:input>\n        </sml:InputList>\n      </sml:inputs>\n      <sml:outputs>\n        <sml:OutputList>\n          <sml:output name="HailAccumulated">\n            <swe:Quantity definition="HailAccumulated">\n              <swe:uom code="hits_cm-2"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="WindSpeedMinimum">\n            <swe:Quantity definition="WindSpeedMinimum">\n              <swe:uom code="m_s"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="AirTemperature">\n            <swe:Quantity definition="AirTemperature">\n              <swe:uom code="degC"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="WindSpeedAverage">\n            <swe:Quantity definition="WindSpeedAverage">\n              <swe:uom code="m_s"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="HailIntensity">\n            <swe:Quantity definition="HailIntensity">\n              <swe:uom code="hits_cm-2_h"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="RainfallAccumulated">\n            <swe:Quantity definition="RainfallAccumulated">\n              <swe:uom code="mm"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="RainfallPeakIntensity">\n            <swe:Quantity definition="RainfallPeakIntensity">\n              <swe:uom code="mm_h"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="WindSpeedMaximum">\n            <swe:Quantity definition="WindSpeedMaximum">\n              <swe:uom code="m_s"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="WindDirectionMaximum">\n            <swe:Quantity definition="WindDirectionMaximum">\n              <swe:uom code="deg"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="Humidity">\n            <swe:Quantity definition="Humidity">\n              <swe:uom code="%"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="RainfallIntensity">\n            <swe:Quantity definition="RainfallIntensity">\n              <swe:uom code="mm_h"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="WindDirectionMinimum">\n            <swe:Quantity definition="WindDirectionMinimum">\n              <swe:uom code="deg"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="HailDuration">\n            <swe:Quantity definition="HailDuration">\n              <swe:uom code="s"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="RainfallDuration">\n            <swe:Quantity definition="RainfallDuration">\n              <swe:uom code="s"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="InSystemTemperature">\n            <swe:Quantity definition="InSystemTemperature">\n              <swe:uom code="degC"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="AthmosphericPressure">\n            <swe:Quantity definition="AthmosphericPressure">\n              <swe:uom code="hPa"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="HailPeakIntensity">\n            <swe:Quantity definition="HailPeakIntensity">\n              <swe:uom code="hits_cm-2_h"/>\n            </swe:Quantity>\n          </sml:output>\n          <sml:output name="WindDirectionAverage">\n            <swe:Quantity definition="WindDirectionAverage">\n              <swe:uom code="deg"/>\n            </swe:Quantity>\n          </sml:output>\n        </sml:OutputList>\n      </sml:outputs>\n    </sml:System>\n  </sml:member>\n</sml:SensorML>
\.


--
-- TOC entry 4194 (class 0 OID 0)
-- Dependencies: 254
-- Name: validproceduretimeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('validproceduretimeid_seq', 1, true);


SET search_path = topology, pg_catalog;

--
-- TOC entry 3650 (class 0 OID 19918)
-- Dependencies: 200
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology  FROM stdin;
\.


--
-- TOC entry 3651 (class 0 OID 19931)
-- Dependencies: 201
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY layer  FROM stdin;
\.


SET search_path = public, pg_catalog;

--
-- TOC entry 3679 (class 2606 OID 20541)
-- Name: blobvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blobvalue
    ADD CONSTRAINT blobvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3681 (class 2606 OID 20548)
-- Name: booleanvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY booleanvalue
    ADD CONSTRAINT booleanvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3683 (class 2606 OID 20553)
-- Name: categoryvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categoryvalue
    ADD CONSTRAINT categoryvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3685 (class 2606 OID 20558)
-- Name: codespace_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY codespace
    ADD CONSTRAINT codespace_pkey PRIMARY KEY (codespaceid);


--
-- TOC entry 3687 (class 2606 OID 20746)
-- Name: codespaceuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY codespace
    ADD CONSTRAINT codespaceuk UNIQUE (codespace);


--
-- TOC entry 3689 (class 2606 OID 20563)
-- Name: compositephenomenon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compositephenomenon
    ADD CONSTRAINT compositephenomenon_pkey PRIMARY KEY (childobservablepropertyid, parentobservablepropertyid);


--
-- TOC entry 3691 (class 2606 OID 20568)
-- Name: countvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY countvalue
    ADD CONSTRAINT countvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3693 (class 2606 OID 20576)
-- Name: featureofinterest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featureofinterest_pkey PRIMARY KEY (featureofinterestid);


--
-- TOC entry 3699 (class 2606 OID 20581)
-- Name: featureofinteresttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinteresttype
    ADD CONSTRAINT featureofinteresttype_pkey PRIMARY KEY (featureofinteresttypeid);


--
-- TOC entry 3703 (class 2606 OID 20586)
-- Name: featurerelation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featurerelation
    ADD CONSTRAINT featurerelation_pkey PRIMARY KEY (childfeatureid, parentfeatureid);


--
-- TOC entry 3701 (class 2606 OID 20752)
-- Name: featuretypeuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinteresttype
    ADD CONSTRAINT featuretypeuk UNIQUE (featureofinteresttype);


--
-- TOC entry 3695 (class 2606 OID 20750)
-- Name: featureurl; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featureurl UNIQUE (url);


--
-- TOC entry 3697 (class 2606 OID 20748)
-- Name: foiidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT foiidentifieruk UNIQUE (identifier);


--
-- TOC entry 3705 (class 2606 OID 20594)
-- Name: geometryvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY geometryvalue
    ADD CONSTRAINT geometryvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3707 (class 2606 OID 20599)
-- Name: numericvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY numericvalue
    ADD CONSTRAINT numericvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3709 (class 2606 OID 20609)
-- Name: observableproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT observableproperty_pkey PRIMARY KEY (observablepropertyid);


--
-- TOC entry 3713 (class 2606 OID 20619)
-- Name: observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observation_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3724 (class 2606 OID 20628)
-- Name: observationconstellation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT observationconstellation_pkey PRIMARY KEY (observationconstellationid);


--
-- TOC entry 3728 (class 2606 OID 20633)
-- Name: observationhasoffering_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationhasoffering
    ADD CONSTRAINT observationhasoffering_pkey PRIMARY KEY (observationid, offeringid);


--
-- TOC entry 3715 (class 2606 OID 20756)
-- Name: observationidentity; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observationidentity UNIQUE (seriesid, phenomenontimestart, phenomenontimeend, resulttime);


--
-- TOC entry 3732 (class 2606 OID 20638)
-- Name: observationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationtype
    ADD CONSTRAINT observationtype_pkey PRIMARY KEY (observationtypeid);


--
-- TOC entry 3734 (class 2606 OID 20769)
-- Name: observationtypeuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationtype
    ADD CONSTRAINT observationtypeuk UNIQUE (observationtype);


--
-- TOC entry 3726 (class 2606 OID 20762)
-- Name: obsnconstellationidentity; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsnconstellationidentity UNIQUE (observablepropertyid, procedureid, offeringid);


--
-- TOC entry 3711 (class 2606 OID 20754)
-- Name: obspropidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT obspropidentifieruk UNIQUE (identifier);


--
-- TOC entry 3736 (class 2606 OID 20648)
-- Name: offering_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offering_pkey PRIMARY KEY (offeringid);


--
-- TOC entry 3740 (class 2606 OID 20653)
-- Name: offeringallowedfeaturetype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedfeaturetype
    ADD CONSTRAINT offeringallowedfeaturetype_pkey PRIMARY KEY (offeringid, featureofinteresttypeid);


--
-- TOC entry 3742 (class 2606 OID 20658)
-- Name: offeringallowedobservationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedobservationtype
    ADD CONSTRAINT offeringallowedobservationtype_pkey PRIMARY KEY (offeringid, observationtypeid);


--
-- TOC entry 3744 (class 2606 OID 20663)
-- Name: offeringhasrelatedfeature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringhasrelatedfeature
    ADD CONSTRAINT offeringhasrelatedfeature_pkey PRIMARY KEY (offeringid, relatedfeatureid);


--
-- TOC entry 3738 (class 2606 OID 20771)
-- Name: offidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offidentifieruk UNIQUE (identifier);


--
-- TOC entry 3746 (class 2606 OID 20671)
-- Name: parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY parameter
    ADD CONSTRAINT parameter_pkey PRIMARY KEY (parameterid);


--
-- TOC entry 3748 (class 2606 OID 20773)
-- Name: procdescformatuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proceduredescriptionformat
    ADD CONSTRAINT procdescformatuk UNIQUE (proceduredescriptionformat);


--
-- TOC entry 3675 (class 2606 OID 20536)
-- Name: procedure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procedure_pkey PRIMARY KEY (procedureid);


--
-- TOC entry 3750 (class 2606 OID 20676)
-- Name: proceduredescriptionformat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proceduredescriptionformat
    ADD CONSTRAINT proceduredescriptionformat_pkey PRIMARY KEY (proceduredescriptionformatid);


--
-- TOC entry 3677 (class 2606 OID 20744)
-- Name: procidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procidentifieruk UNIQUE (identifier);


--
-- TOC entry 3752 (class 2606 OID 20681)
-- Name: relatedfeature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeature
    ADD CONSTRAINT relatedfeature_pkey PRIMARY KEY (relatedfeatureid);


--
-- TOC entry 3754 (class 2606 OID 20686)
-- Name: relatedfeaturehasrole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturehasrole
    ADD CONSTRAINT relatedfeaturehasrole_pkey PRIMARY KEY (relatedfeatureid, relatedfeatureroleid);


--
-- TOC entry 3756 (class 2606 OID 20691)
-- Name: relatedfeaturerole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturerole
    ADD CONSTRAINT relatedfeaturerole_pkey PRIMARY KEY (relatedfeatureroleid);


--
-- TOC entry 3758 (class 2606 OID 20775)
-- Name: relfeatroleuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturerole
    ADD CONSTRAINT relfeatroleuk UNIQUE (relatedfeaturerole);


--
-- TOC entry 3762 (class 2606 OID 20699)
-- Name: resulttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplate_pkey PRIMARY KEY (resulttemplateid);


--
-- TOC entry 3766 (class 2606 OID 20704)
-- Name: sensorsystem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sensorsystem
    ADD CONSTRAINT sensorsystem_pkey PRIMARY KEY (childsensorid, parentsensorid);


--
-- TOC entry 3768 (class 2606 OID 20713)
-- Name: series_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_pkey PRIMARY KEY (seriesid);


--
-- TOC entry 3771 (class 2606 OID 20781)
-- Name: seriesidentity; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesidentity UNIQUE (featureofinterestid, observablepropertyid, procedureid, offeringid);


--
-- TOC entry 3776 (class 2606 OID 20721)
-- Name: swedataarrayvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY swedataarrayvalue
    ADD CONSTRAINT swedataarrayvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3778 (class 2606 OID 20729)
-- Name: textvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY textvalue
    ADD CONSTRAINT textvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3780 (class 2606 OID 20734)
-- Name: unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (unitid);


--
-- TOC entry 3782 (class 2606 OID 20787)
-- Name: unituk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY unit
    ADD CONSTRAINT unituk UNIQUE (unit);


--
-- TOC entry 3784 (class 2606 OID 20742)
-- Name: validproceduretime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validproceduretime
    ADD CONSTRAINT validproceduretime_pkey PRIMARY KEY (validproceduretimeid);


--
-- TOC entry 3720 (class 1259 OID 20763)
-- Name: obsconstobspropidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsconstobspropidx ON observationconstellation USING btree (observablepropertyid);


--
-- TOC entry 3721 (class 1259 OID 20765)
-- Name: obsconstofferingidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsconstofferingidx ON observationconstellation USING btree (offeringid);


--
-- TOC entry 3722 (class 1259 OID 20764)
-- Name: obsconstprocedureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsconstprocedureidx ON observationconstellation USING btree (procedureid);


--
-- TOC entry 3729 (class 1259 OID 20766)
-- Name: obshasoffobservationidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obshasoffobservationidx ON observationhasoffering USING btree (observationid);


--
-- TOC entry 3730 (class 1259 OID 20767)
-- Name: obshasoffofferingidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obshasoffofferingidx ON observationhasoffering USING btree (offeringid);


--
-- TOC entry 3716 (class 1259 OID 20759)
-- Name: obsphentimeendidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsphentimeendidx ON observation USING btree (phenomenontimeend);


--
-- TOC entry 3717 (class 1259 OID 20758)
-- Name: obsphentimestartidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsphentimestartidx ON observation USING btree (phenomenontimestart);


--
-- TOC entry 3718 (class 1259 OID 20760)
-- Name: obsresulttimeidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsresulttimeidx ON observation USING btree (resulttime);


--
-- TOC entry 3719 (class 1259 OID 20757)
-- Name: obsseriesidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsseriesidx ON observation USING btree (seriesid);


--
-- TOC entry 3759 (class 1259 OID 20777)
-- Name: resulttempeobspropidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempeobspropidx ON resulttemplate USING btree (observablepropertyid);


--
-- TOC entry 3760 (class 1259 OID 20779)
-- Name: resulttempidentifieridx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempidentifieridx ON resulttemplate USING btree (identifier);


--
-- TOC entry 3763 (class 1259 OID 20776)
-- Name: resulttempofferingidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempofferingidx ON resulttemplate USING btree (offeringid);


--
-- TOC entry 3764 (class 1259 OID 20778)
-- Name: resulttempprocedureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempprocedureidx ON resulttemplate USING btree (procedureid);


--
-- TOC entry 3769 (class 1259 OID 20782)
-- Name: seriesfeatureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX seriesfeatureidx ON series USING btree (featureofinterestid);


--
-- TOC entry 3772 (class 1259 OID 20783)
-- Name: seriesobspropidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX seriesobspropidx ON series USING btree (observablepropertyid);


--
-- TOC entry 3773 (class 1259 OID 20785)
-- Name: seriesofferingidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX seriesofferingidx ON series USING btree (offeringid);


--
-- TOC entry 3774 (class 1259 OID 20784)
-- Name: seriesprocedureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX seriesprocedureidx ON series USING btree (procedureid);


--
-- TOC entry 3785 (class 1259 OID 20789)
-- Name: validproceduretimeendtimeidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX validproceduretimeendtimeidx ON validproceduretime USING btree (endtime);


--
-- TOC entry 3786 (class 1259 OID 20788)
-- Name: validproceduretimestarttimeidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX validproceduretimestarttimeidx ON validproceduretime USING btree (starttime);


--
-- TOC entry 3797 (class 2606 OID 20840)
-- Name: featurecodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featurecodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3798 (class 2606 OID 20845)
-- Name: featurecodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featurecodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3796 (class 2606 OID 20835)
-- Name: featurefeaturetypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featurefeaturetypefk FOREIGN KEY (featureofinteresttypeid) REFERENCES featureofinteresttype(featureofinteresttypeid);


--
-- TOC entry 3800 (class 2606 OID 20850)
-- Name: featureofinterestchildfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featurerelation
    ADD CONSTRAINT featureofinterestchildfk FOREIGN KEY (childfeatureid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3799 (class 2606 OID 20855)
-- Name: featureofinterestparentfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featurerelation
    ADD CONSTRAINT featureofinterestparentfk FOREIGN KEY (parentfeatureid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3817 (class 2606 OID 20945)
-- Name: fk_6vvrdxvd406n48gkm706ow1pt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedfeaturetype
    ADD CONSTRAINT fk_6vvrdxvd406n48gkm706ow1pt FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3824 (class 2606 OID 20980)
-- Name: fk_6ynwkk91xe8p1uibmjt98sog3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturehasrole
    ADD CONSTRAINT fk_6ynwkk91xe8p1uibmjt98sog3 FOREIGN KEY (relatedfeatureid) REFERENCES relatedfeature(relatedfeatureid);


--
-- TOC entry 3813 (class 2606 OID 20925)
-- Name: fk_9ex7hawh3dbplkllmw5w3kvej; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationhasoffering
    ADD CONSTRAINT fk_9ex7hawh3dbplkllmw5w3kvej FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3819 (class 2606 OID 20955)
-- Name: fk_lkljeohulvu7cr26pduyp5bd0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedobservationtype
    ADD CONSTRAINT fk_lkljeohulvu7cr26pduyp5bd0 FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3806 (class 2606 OID 20885)
-- Name: obscodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT obscodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3807 (class 2606 OID 20890)
-- Name: obscodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT obscodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3811 (class 2606 OID 20910)
-- Name: obsconstobservationiypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsconstobservationiypefk FOREIGN KEY (observationtypeid) REFERENCES observationtype(observationtypeid);


--
-- TOC entry 3809 (class 2606 OID 20900)
-- Name: obsconstobspropfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsconstobspropfk FOREIGN KEY (observablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3812 (class 2606 OID 20915)
-- Name: obsconstofferingfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsconstofferingfk FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3794 (class 2606 OID 20820)
-- Name: observablepropertychildfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compositephenomenon
    ADD CONSTRAINT observablepropertychildfk FOREIGN KEY (childobservablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3793 (class 2606 OID 20825)
-- Name: observablepropertyparentfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compositephenomenon
    ADD CONSTRAINT observablepropertyparentfk FOREIGN KEY (parentobservablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3790 (class 2606 OID 20805)
-- Name: observationblobvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blobvalue
    ADD CONSTRAINT observationblobvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3791 (class 2606 OID 20810)
-- Name: observationbooleanvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY booleanvalue
    ADD CONSTRAINT observationbooleanvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3792 (class 2606 OID 20815)
-- Name: observationcategoryvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categoryvalue
    ADD CONSTRAINT observationcategoryvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3795 (class 2606 OID 20830)
-- Name: observationcountvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY countvalue
    ADD CONSTRAINT observationcountvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3801 (class 2606 OID 20860)
-- Name: observationgeometryvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY geometryvalue
    ADD CONSTRAINT observationgeometryvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3802 (class 2606 OID 20865)
-- Name: observationnumericvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY numericvalue
    ADD CONSTRAINT observationnumericvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3814 (class 2606 OID 20920)
-- Name: observationofferingfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationhasoffering
    ADD CONSTRAINT observationofferingfk FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3805 (class 2606 OID 20880)
-- Name: observationseriesfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observationseriesfk FOREIGN KEY (seriesid) REFERENCES series(seriesid);


--
-- TOC entry 3837 (class 2606 OID 21040)
-- Name: observationswedataarrayvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY swedataarrayvalue
    ADD CONSTRAINT observationswedataarrayvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3838 (class 2606 OID 21045)
-- Name: observationtextvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY textvalue
    ADD CONSTRAINT observationtextvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3808 (class 2606 OID 20895)
-- Name: observationunitfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observationunitfk FOREIGN KEY (unitid) REFERENCES unit(unitid);


--
-- TOC entry 3810 (class 2606 OID 20905)
-- Name: obsnconstprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsnconstprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3804 (class 2606 OID 20870)
-- Name: obspropcodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT obspropcodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3803 (class 2606 OID 20875)
-- Name: obspropcodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT obspropcodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3816 (class 2606 OID 20930)
-- Name: offcodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offcodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3815 (class 2606 OID 20935)
-- Name: offcodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offcodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3818 (class 2606 OID 20940)
-- Name: offeringfeaturetypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedfeaturetype
    ADD CONSTRAINT offeringfeaturetypefk FOREIGN KEY (featureofinteresttypeid) REFERENCES featureofinteresttype(featureofinteresttypeid);


--
-- TOC entry 3820 (class 2606 OID 20950)
-- Name: offeringobservationtypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedobservationtype
    ADD CONSTRAINT offeringobservationtypefk FOREIGN KEY (observationtypeid) REFERENCES observationtype(observationtypeid);


--
-- TOC entry 3821 (class 2606 OID 20965)
-- Name: offeringrelatedfeaturefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringhasrelatedfeature
    ADD CONSTRAINT offeringrelatedfeaturefk FOREIGN KEY (relatedfeatureid) REFERENCES relatedfeature(relatedfeatureid);


--
-- TOC entry 3788 (class 2606 OID 20795)
-- Name: proccodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT proccodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3789 (class 2606 OID 20800)
-- Name: proccodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT proccodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3831 (class 2606 OID 21005)
-- Name: procedurechildfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sensorsystem
    ADD CONSTRAINT procedurechildfk FOREIGN KEY (childsensorid) REFERENCES procedure(procedureid);


--
-- TOC entry 3830 (class 2606 OID 21010)
-- Name: procedureparenffk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sensorsystem
    ADD CONSTRAINT procedureparenffk FOREIGN KEY (parentsensorid) REFERENCES procedure(procedureid);


--
-- TOC entry 3787 (class 2606 OID 20790)
-- Name: procprocdescformatfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procprocdescformatfk FOREIGN KEY (proceduredescriptionformatid) REFERENCES proceduredescriptionformat(proceduredescriptionformatid);


--
-- TOC entry 3825 (class 2606 OID 20975)
-- Name: relatedfeatrelatedfeatrolefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturehasrole
    ADD CONSTRAINT relatedfeatrelatedfeatrolefk FOREIGN KEY (relatedfeatureroleid) REFERENCES relatedfeaturerole(relatedfeatureroleid);


--
-- TOC entry 3823 (class 2606 OID 20970)
-- Name: relatedfeaturefeaturefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeature
    ADD CONSTRAINT relatedfeaturefeaturefk FOREIGN KEY (featureofinterestid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3822 (class 2606 OID 20960)
-- Name: relatedfeatureofferingfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringhasrelatedfeature
    ADD CONSTRAINT relatedfeatureofferingfk FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3826 (class 2606 OID 21000)
-- Name: resulttemplatefeatureidx; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplatefeatureidx FOREIGN KEY (featureofinterestid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3828 (class 2606 OID 20990)
-- Name: resulttemplateobspropfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplateobspropfk FOREIGN KEY (observablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3829 (class 2606 OID 20985)
-- Name: resulttemplateofferingidx; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplateofferingidx FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3827 (class 2606 OID 20995)
-- Name: resulttemplateprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplateprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3832 (class 2606 OID 21015)
-- Name: seriesfeaturefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesfeaturefk FOREIGN KEY (featureofinterestid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3833 (class 2606 OID 21020)
-- Name: seriesobpropfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesobpropfk FOREIGN KEY (observablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3835 (class 2606 OID 21030)
-- Name: seriesofferingfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesofferingfk FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3834 (class 2606 OID 21025)
-- Name: seriesprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3836 (class 2606 OID 21035)
-- Name: seriesunitfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesunitfk FOREIGN KEY (unitid) REFERENCES unit(unitid);


--
-- TOC entry 3840 (class 2606 OID 21050)
-- Name: validproceduretimeprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validproceduretime
    ADD CONSTRAINT validproceduretimeprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3839 (class 2606 OID 21055)
-- Name: validprocprocdescformatfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validproceduretime
    ADD CONSTRAINT validprocprocdescformatfk FOREIGN KEY (proceduredescriptionformatid) REFERENCES proceduredescriptionformat(proceduredescriptionformatid);


--
-- TOC entry 4018 (class 0 OID 0)
-- Dependencies: 8
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2016-11-17 14:56:44 CET

--
-- PostgreSQL database dump complete
--

