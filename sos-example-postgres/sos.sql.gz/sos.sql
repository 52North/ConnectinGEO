--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

-- Started on 2016-11-16 16:41:55 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 1 (class 3079 OID 12361)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 4019 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- TOC entry 2 (class 3079 OID 18441)
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- TOC entry 4020 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- TOC entry 3 (class 3079 OID 19915)
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- TOC entry 4021 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 206 (class 1259 OID 20537)
-- Name: blobvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE blobvalue (
    observationid bigint NOT NULL,
    value oid
);


ALTER TABLE blobvalue OWNER TO postgres;

--
-- TOC entry 4022 (class 0 OID 0)
-- Dependencies: 206
-- Name: TABLE blobvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE blobvalue IS 'Value table for blob observation';


--
-- TOC entry 4023 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN blobvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN blobvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4024 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN blobvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN blobvalue.value IS 'Blob observation value';


--
-- TOC entry 207 (class 1259 OID 20542)
-- Name: booleanvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE booleanvalue (
    observationid bigint NOT NULL,
    value character(1),
    CONSTRAINT booleanvalue_value_check CHECK ((value = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT booleanvalue_value_check1 CHECK ((value = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE booleanvalue OWNER TO postgres;

--
-- TOC entry 4025 (class 0 OID 0)
-- Dependencies: 207
-- Name: TABLE booleanvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE booleanvalue IS 'Value table for boolean observation';


--
-- TOC entry 4026 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN booleanvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN booleanvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4027 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN booleanvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN booleanvalue.value IS 'Boolean observation value';


--
-- TOC entry 208 (class 1259 OID 20549)
-- Name: categoryvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE categoryvalue (
    observationid bigint NOT NULL,
    value character varying(255)
);


ALTER TABLE categoryvalue OWNER TO postgres;

--
-- TOC entry 4028 (class 0 OID 0)
-- Dependencies: 208
-- Name: TABLE categoryvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE categoryvalue IS 'Value table for category observation';


--
-- TOC entry 4029 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN categoryvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN categoryvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4030 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN categoryvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN categoryvalue.value IS 'Category observation value';


--
-- TOC entry 209 (class 1259 OID 20554)
-- Name: codespace; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE codespace (
    codespaceid bigint NOT NULL,
    codespace character varying(255) NOT NULL
);


ALTER TABLE codespace OWNER TO postgres;

--
-- TOC entry 4031 (class 0 OID 0)
-- Dependencies: 209
-- Name: TABLE codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE codespace IS 'Table to store the gml:identifier and gml:name codespace information. Mapping file: mapping/core/Codespace.hbm.xml';


--
-- TOC entry 4032 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN codespace.codespaceid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN codespace.codespaceid IS 'Table primary key, used for relations';


--
-- TOC entry 4033 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN codespace.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN codespace.codespace IS 'The codespace value';


--
-- TOC entry 238 (class 1259 OID 21056)
-- Name: codespaceid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE codespaceid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE codespaceid_seq OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 20559)
-- Name: compositephenomenon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE compositephenomenon (
    parentobservablepropertyid bigint NOT NULL,
    childobservablepropertyid bigint NOT NULL
);


ALTER TABLE compositephenomenon OWNER TO postgres;

--
-- TOC entry 4034 (class 0 OID 0)
-- Dependencies: 210
-- Name: TABLE compositephenomenon; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE compositephenomenon IS 'NOT YET USED! Relation table to store observableProperty hierarchies, aka compositePhenomenon. E.g. define a parent in a query and all childs are also contained in the response. Mapping file: mapping/transactional/TObservableProperty.hbm.xml';


--
-- TOC entry 4035 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN compositephenomenon.parentobservablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN compositephenomenon.parentobservablepropertyid IS 'Foreign Key (FK) to the related parent observableProperty. Contains "observableProperty".observablePropertyid';


--
-- TOC entry 4036 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN compositephenomenon.childobservablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN compositephenomenon.childobservablepropertyid IS 'Foreign Key (FK) to the related child observableProperty. Contains "observableProperty".observablePropertyid';


--
-- TOC entry 211 (class 1259 OID 20564)
-- Name: countvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE countvalue (
    observationid bigint NOT NULL,
    value integer
);


ALTER TABLE countvalue OWNER TO postgres;

--
-- TOC entry 4037 (class 0 OID 0)
-- Dependencies: 211
-- Name: TABLE countvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE countvalue IS 'Value table for count observation';


--
-- TOC entry 4038 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN countvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN countvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4039 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN countvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN countvalue.value IS 'Count observation value';


--
-- TOC entry 212 (class 1259 OID 20569)
-- Name: featureofinterest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featureofinterest (
    featureofinterestid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    featureofinteresttypeid bigint NOT NULL,
    identifier character varying(255),
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    geom geometry,
    descriptionxml text,
    url character varying(255)
);


ALTER TABLE featureofinterest OWNER TO postgres;

--
-- TOC entry 4040 (class 0 OID 0)
-- Dependencies: 212
-- Name: TABLE featureofinterest; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE featureofinterest IS 'Table to store the FeatureOfInterest information. Mapping file: mapping/core/FeatureOfInterest.hbm.xml';


--
-- TOC entry 4041 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.featureofinterestid IS 'Table primary key, used for relations';


--
-- TOC entry 4042 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.featureofinteresttypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.featureofinteresttypeid IS 'Relation/foreign key to the featureOfInterestType table. Describes the type of the featureOfInterest. Contains "featureOfInterestType".featureOfInterestTypeId';


--
-- TOC entry 4043 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.identifier IS 'The identifier of the featureOfInterest, gml:identifier. Used as parameter for queries. Optional but unique';


--
-- TOC entry 4044 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4045 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.name IS 'The name of the featureOfInterest, gml:name. Optional';


--
-- TOC entry 4046 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.codespacename IS 'The name of the featureOfInterest, gml:name. Optional';


--
-- TOC entry 4047 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.description IS 'Description of the featureOfInterest, gml:description. Optional';


--
-- TOC entry 4048 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.geom; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.geom IS 'The geometry of the featureOfInterest (composed of the “latitude” and “longitude”) . Optional';


--
-- TOC entry 4049 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.descriptionxml; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.descriptionxml IS 'XML description of the feature, used when transactional profile is supported . Optional';


--
-- TOC entry 4050 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN featureofinterest.url; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinterest.url IS 'Reference URL to the feature if it is stored in another service, e.g. WFS. Optional but unique';


--
-- TOC entry 239 (class 1259 OID 21058)
-- Name: featureofinterestid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featureofinterestid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featureofinterestid_seq OWNER TO postgres;

--
-- TOC entry 213 (class 1259 OID 20577)
-- Name: featureofinteresttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featureofinteresttype (
    featureofinteresttypeid bigint NOT NULL,
    featureofinteresttype character varying(255) NOT NULL
);


ALTER TABLE featureofinteresttype OWNER TO postgres;

--
-- TOC entry 4051 (class 0 OID 0)
-- Dependencies: 213
-- Name: TABLE featureofinteresttype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE featureofinteresttype IS 'Table to store the FeatureOfInterestType information. Mapping file: mapping/core/FeatureOfInterestType.hbm.xml';


--
-- TOC entry 4052 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN featureofinteresttype.featureofinteresttypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinteresttype.featureofinteresttypeid IS 'Table primary key, used for relations';


--
-- TOC entry 4053 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN featureofinteresttype.featureofinteresttype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featureofinteresttype.featureofinteresttype IS 'The featureOfInterestType value, e.g. http://www.opengis.net/def/samplingFeatureType/OGC-OM/2.0/SF_SamplingPoint (OGC OM 2.0 specification) for point features';


--
-- TOC entry 240 (class 1259 OID 21060)
-- Name: featureofinteresttypeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featureofinteresttypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featureofinteresttypeid_seq OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 20582)
-- Name: featurerelation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featurerelation (
    parentfeatureid bigint NOT NULL,
    childfeatureid bigint NOT NULL
);


ALTER TABLE featurerelation OWNER TO postgres;

--
-- TOC entry 4054 (class 0 OID 0)
-- Dependencies: 214
-- Name: TABLE featurerelation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE featurerelation IS 'Relation table to store feature hierarchies. E.g. define a parent in a query and all childs are also contained in the response. Mapping file: mapping/transactional/TFeatureOfInterest.hbm.xml';


--
-- TOC entry 4055 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN featurerelation.parentfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featurerelation.parentfeatureid IS 'Foreign Key (FK) to the related parent featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 4056 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN featurerelation.childfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN featurerelation.childfeatureid IS 'Foreign Key (FK) to the related child featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 215 (class 1259 OID 20587)
-- Name: geometryvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE geometryvalue (
    observationid bigint NOT NULL,
    value geometry
);


ALTER TABLE geometryvalue OWNER TO postgres;

--
-- TOC entry 4057 (class 0 OID 0)
-- Dependencies: 215
-- Name: TABLE geometryvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE geometryvalue IS 'Value table for geometry observation';


--
-- TOC entry 4058 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN geometryvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN geometryvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4059 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN geometryvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN geometryvalue.value IS 'Geometry observation value';


--
-- TOC entry 216 (class 1259 OID 20595)
-- Name: numericvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE numericvalue (
    observationid bigint NOT NULL,
    value double precision
);


ALTER TABLE numericvalue OWNER TO postgres;

--
-- TOC entry 4060 (class 0 OID 0)
-- Dependencies: 216
-- Name: TABLE numericvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE numericvalue IS 'Value table for numeric/Measurment observation';


--
-- TOC entry 4061 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN numericvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN numericvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4062 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN numericvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN numericvalue.value IS 'Numeric/Measurment observation value';


--
-- TOC entry 217 (class 1259 OID 20600)
-- Name: observableproperty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observableproperty (
    observablepropertyid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    identifier character varying(255) NOT NULL,
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    disabled character(1) DEFAULT 'F'::bpchar NOT NULL,
    CONSTRAINT observableproperty_disabled_check CHECK ((disabled = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE observableproperty OWNER TO postgres;

--
-- TOC entry 4063 (class 0 OID 0)
-- Dependencies: 217
-- Name: TABLE observableproperty; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observableproperty IS 'Table to store the ObservedProperty/Phenomenon information. Mapping file: mapping/core/ObservableProperty.hbm.xml';


--
-- TOC entry 4064 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.observablepropertyid IS 'Table primary key, used for relations';


--
-- TOC entry 4065 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.identifier IS 'The identifier of the observableProperty, gml:identifier. Used as parameter for queries. Unique';


--
-- TOC entry 4066 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4067 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.name IS 'The name of the observableProperty, gml:name. Optional';


--
-- TOC entry 4068 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.codespacename IS 'Relation/foreign key to the codespace table. Contains the gml:name codespace. Optional';


--
-- TOC entry 4069 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.description IS 'Description of the observableProperty, gml:description. Optional';


--
-- TOC entry 4070 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN observableproperty.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observableproperty.disabled IS 'For later use by the SOS. Indicator if this observableProperty should not be provided by the SOS.';


--
-- TOC entry 241 (class 1259 OID 21062)
-- Name: observablepropertyid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observablepropertyid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observablepropertyid_seq OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 20610)
-- Name: observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observation (
    observationid bigint NOT NULL,
    seriesid bigint NOT NULL,
    phenomenontimestart timestamp without time zone NOT NULL,
    phenomenontimeend timestamp without time zone NOT NULL,
    resulttime timestamp without time zone NOT NULL,
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    validtimestart timestamp without time zone,
    validtimeend timestamp without time zone,
    samplinggeometry geometry,
    identifier character varying(255),
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    unitid bigint,
    CONSTRAINT observation_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE observation OWNER TO postgres;

--
-- TOC entry 4071 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE observation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observation IS 'Stores the observations. Mapping file: mapping/series/observation/SeriesObservation.hbm.xml';


--
-- TOC entry 4072 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.identifier IS 'The identifier of the observation, gml:identifier. Used as parameter for queries. Optional but unique';


--
-- TOC entry 4073 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4074 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.name IS 'The name of the observation, gml:name. Optional';


--
-- TOC entry 4075 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.codespacename IS 'The name of the observation, gml:name. Optional';


--
-- TOC entry 4076 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.description IS 'Description of the observation, gml:description. Optional';


--
-- TOC entry 4077 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.unitid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observation.unitid IS 'Foreign Key (FK) to the related unit of measure. Contains "unit".unitid. Optional';


--
-- TOC entry 219 (class 1259 OID 20620)
-- Name: observationconstellation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observationconstellation (
    observationconstellationid bigint NOT NULL,
    observablepropertyid bigint NOT NULL,
    procedureid bigint NOT NULL,
    observationtypeid bigint,
    offeringid bigint NOT NULL,
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    hiddenchild character(1) DEFAULT 'F'::bpchar NOT NULL,
    CONSTRAINT observationconstellation_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT observationconstellation_hiddenchild_check CHECK ((hiddenchild = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE observationconstellation OWNER TO postgres;

--
-- TOC entry 4078 (class 0 OID 0)
-- Dependencies: 219
-- Name: TABLE observationconstellation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observationconstellation IS 'Table to store the ObservationConstellation information. Contains information about the constellation of observableProperty, procedure, offering and the observationType. Mapping file: mapping/core/ObservationConstellation.hbm.xml';


--
-- TOC entry 4079 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.observationconstellationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.observationconstellationid IS 'Table primary key, used for relations';


--
-- TOC entry 4080 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.observablepropertyid IS 'Foreign Key (FK) to the related observableProperty. Contains "observableproperty".observablepropertyid';


--
-- TOC entry 4081 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureid';


--
-- TOC entry 4082 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.observationtypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.observationtypeid IS 'Foreign Key (FK) to the related observableProperty. Contains "observationtype".observationtypeid';


--
-- TOC entry 4083 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.offeringid IS 'Foreign Key (FK) to the related observableProperty. Contains "offering".offeringid';


--
-- TOC entry 4084 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.deleted IS 'Flag to indicate that this observationConstellation is deleted or not. Set if the related procedure is deleted via DeleteSensor operation (OGC SWES 2.0 - DeleteSensor operation)';


--
-- TOC entry 4085 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN observationconstellation.hiddenchild; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationconstellation.hiddenchild IS 'Flag to indicate that this observationConstellations procedure is a child procedure of another procedure. If true, the related procedure is not contained in OGC SOS 2.0 Capabilities but in OGC SOS 1.0.0 Capabilities.';


--
-- TOC entry 242 (class 1259 OID 21064)
-- Name: observationconstellationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observationconstellationid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observationconstellationid_seq OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 20629)
-- Name: observationhasoffering; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observationhasoffering (
    observationid bigint NOT NULL,
    offeringid bigint NOT NULL
);


ALTER TABLE observationhasoffering OWNER TO postgres;

--
-- TOC entry 4086 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE observationhasoffering; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observationhasoffering IS 'Table to store relations between observation and associated offerings. Mapping file: mapping/ereporting/EReportingObservation.hbm.xml';


--
-- TOC entry 243 (class 1259 OID 21066)
-- Name: observationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observationid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observationid_seq OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 20634)
-- Name: observationtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE observationtype (
    observationtypeid bigint NOT NULL,
    observationtype character varying(255) NOT NULL
);


ALTER TABLE observationtype OWNER TO postgres;

--
-- TOC entry 4087 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE observationtype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE observationtype IS 'Table to store the observationTypes. Mapping file: mapping/core/ObservationType.hbm.xml';


--
-- TOC entry 4088 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN observationtype.observationtypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationtype.observationtypeid IS 'Table primary key, used for relations';


--
-- TOC entry 4089 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN observationtype.observationtype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN observationtype.observationtype IS 'The observationType value, e.g. http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement (OGC OM 2.0 specification) for OM_Measurement';


--
-- TOC entry 244 (class 1259 OID 21068)
-- Name: observationtypeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE observationtypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observationtypeid_seq OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 20639)
-- Name: offering; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offering (
    offeringid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    identifier character varying(255) NOT NULL,
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    disabled character(1) DEFAULT 'F'::bpchar NOT NULL,
    CONSTRAINT offering_disabled_check CHECK ((disabled = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE offering OWNER TO postgres;

--
-- TOC entry 4090 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE offering; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offering IS 'Table to store the offering information. Mapping file: mapping/core/Offering.hbm.xml';


--
-- TOC entry 4091 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.offeringid IS 'Table primary key, used for relations';


--
-- TOC entry 4092 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.identifier IS 'The identifier of the offering, gml:identifier. Used as parameter for queries. Unique';


--
-- TOC entry 4093 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4094 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.name IS 'The name of the offering, gml:name. If available, displyed in the contents of the Capabilites. Optional';


--
-- TOC entry 4095 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.codespacename IS 'Relation/foreign key to the codespace table. Contains the gml:name codespace. Optional';


--
-- TOC entry 4096 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.description IS 'Description of the offering, gml:description. Optional';


--
-- TOC entry 4097 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN offering.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offering.disabled IS 'For later use by the SOS. Indicator if this offering should not be provided by the SOS.';


--
-- TOC entry 223 (class 1259 OID 20649)
-- Name: offeringallowedfeaturetype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offeringallowedfeaturetype (
    offeringid bigint NOT NULL,
    featureofinteresttypeid bigint NOT NULL
);


ALTER TABLE offeringallowedfeaturetype OWNER TO postgres;

--
-- TOC entry 4098 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE offeringallowedfeaturetype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offeringallowedfeaturetype IS 'Table to store relations between offering and allowed featureOfInterestTypes, defined in InsertSensor request. Mapping file: mapping/transactional/TOffering.hbm.xml';


--
-- TOC entry 4099 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN offeringallowedfeaturetype.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedfeaturetype.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 4100 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN offeringallowedfeaturetype.featureofinteresttypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedfeaturetype.featureofinteresttypeid IS 'Foreign Key (FK) to the related featureOfInterestTypeId. Contains "featureOfInterestType".featureOfInterestTypeId';


--
-- TOC entry 224 (class 1259 OID 20654)
-- Name: offeringallowedobservationtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offeringallowedobservationtype (
    offeringid bigint NOT NULL,
    observationtypeid bigint NOT NULL
);


ALTER TABLE offeringallowedobservationtype OWNER TO postgres;

--
-- TOC entry 4101 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE offeringallowedobservationtype; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offeringallowedobservationtype IS 'Table to store relations between offering and allowed observationTypes, defined in InsertSensor request. Mapping file: mapping/transactional/TOffering.hbm.xml';


--
-- TOC entry 4102 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN offeringallowedobservationtype.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedobservationtype.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 4103 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN offeringallowedobservationtype.observationtypeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringallowedobservationtype.observationtypeid IS 'Foreign Key (FK) to the related observationType. Contains "observationType".observationTypeId';


--
-- TOC entry 225 (class 1259 OID 20659)
-- Name: offeringhasrelatedfeature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE offeringhasrelatedfeature (
    relatedfeatureid bigint NOT NULL,
    offeringid bigint NOT NULL
);


ALTER TABLE offeringhasrelatedfeature OWNER TO postgres;

--
-- TOC entry 4104 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE offeringhasrelatedfeature; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE offeringhasrelatedfeature IS 'Table to store relations between offering and associated relatedFeatures. Mapping file: mapping/transactional/TOffering.hbm.xml';


--
-- TOC entry 4105 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN offeringhasrelatedfeature.relatedfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringhasrelatedfeature.relatedfeatureid IS 'Foreign Key (FK) to the related relatedFeature. Contains "relatedFeature".relatedFeatureid';


--
-- TOC entry 4106 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN offeringhasrelatedfeature.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN offeringhasrelatedfeature.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 245 (class 1259 OID 21070)
-- Name: offeringid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE offeringid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE offeringid_seq OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 20664)
-- Name: parameter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE parameter (
    parameterid bigint NOT NULL,
    observationid bigint NOT NULL,
    definition character varying(255) NOT NULL,
    title character varying(255),
    value oid NOT NULL
);


ALTER TABLE parameter OWNER TO postgres;

--
-- TOC entry 4107 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE parameter; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE parameter IS 'NOT YET USED! Table to store additional obervation information (om:parameter). Mapping file: mapping/transactional/Parameter.hbm.xml';


--
-- TOC entry 4108 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.parameterid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.parameterid IS 'Table primary key';


--
-- TOC entry 4109 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.observationid IS 'Foreign Key (FK) to the related observation. Contains "observation".observationid';


--
-- TOC entry 4110 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.definition; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.definition IS 'Definition of the additional information';


--
-- TOC entry 4111 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.title IS 'optional title of the additional information. Optional';


--
-- TOC entry 4112 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN parameter.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN parameter.value IS 'Value of the additional information';


--
-- TOC entry 246 (class 1259 OID 21072)
-- Name: parameterid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE parameterid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE parameterid_seq OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 21074)
-- Name: procdescformatid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE procdescformatid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procdescformatid_seq OWNER TO postgres;

--
-- TOC entry 205 (class 1259 OID 20523)
-- Name: procedure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE procedure (
    procedureid bigint NOT NULL,
    hibernatediscriminator character(1) NOT NULL,
    proceduredescriptionformatid bigint NOT NULL,
    identifier character varying(255) NOT NULL,
    codespace bigint,
    name character varying(255),
    codespacename bigint,
    description character varying(255),
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    disabled character(1) DEFAULT 'F'::bpchar NOT NULL,
    descriptionfile text,
    referenceflag character(1) DEFAULT 'F'::bpchar,
    CONSTRAINT procedure_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT procedure_disabled_check CHECK ((disabled = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT procedure_referenceflag_check CHECK ((referenceflag = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE procedure OWNER TO postgres;

--
-- TOC entry 4113 (class 0 OID 0)
-- Dependencies: 205
-- Name: TABLE procedure; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE procedure IS 'Table to store the procedure/sensor. Mapping file: mapping/core/Procedure.hbm.xml';


--
-- TOC entry 4114 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.procedureid IS 'Table primary key, used for relations';


--
-- TOC entry 4115 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.proceduredescriptionformatid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.proceduredescriptionformatid IS 'Relation/foreign key to the procedureDescriptionFormat table. Describes the format of the procedure description.';


--
-- TOC entry 4116 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.identifier IS 'The identifier of the procedure, gml:identifier. Used as parameter for queries. Unique';


--
-- TOC entry 4117 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.codespace; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.codespace IS 'Relation/foreign key to the codespace table. Contains the gml:identifier codespace. Optional';


--
-- TOC entry 4118 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.name IS 'The name of the procedure, gml:name. Optional';


--
-- TOC entry 4119 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.codespacename; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.codespacename IS 'Relation/foreign key to the codespace table. Contains the gml:name codespace. Optional';


--
-- TOC entry 4120 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.description IS 'Description of the procedure, gml:description. Optional';


--
-- TOC entry 4121 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.deleted IS 'Flag to indicate that this procedure is deleted or not (OGC SWES 2.0 - DeleteSensor operation)';


--
-- TOC entry 4122 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.disabled; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.disabled IS 'For later use by the SOS. Indicator if this procedure should not be provided by the SOS.';


--
-- TOC entry 4123 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.descriptionfile; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.descriptionfile IS 'Field for full (XML) encoded procedure description or link to a procedure description file. Optional';


--
-- TOC entry 4124 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN procedure.referenceflag; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN procedure.referenceflag IS 'Flag to indicate that this procedure is a reference procedure of another procedure. Not used by the SOS but by the Sensor Web REST-API';


--
-- TOC entry 227 (class 1259 OID 20672)
-- Name: proceduredescriptionformat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE proceduredescriptionformat (
    proceduredescriptionformatid bigint NOT NULL,
    proceduredescriptionformat character varying(255) NOT NULL
);


ALTER TABLE proceduredescriptionformat OWNER TO postgres;

--
-- TOC entry 4125 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE proceduredescriptionformat; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE proceduredescriptionformat IS 'Table to store the ProcedureDescriptionFormat information of procedures. Mapping file: mapping/core/ProcedureDescriptionFormat.hbm.xml';


--
-- TOC entry 4126 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN proceduredescriptionformat.proceduredescriptionformatid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN proceduredescriptionformat.proceduredescriptionformatid IS 'Table primary key, used for relations';


--
-- TOC entry 4127 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN proceduredescriptionformat.proceduredescriptionformat; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN proceduredescriptionformat.proceduredescriptionformat IS 'The procedureDescriptionFormat value, e.g. http://www.opengis.net/sensorML/1.0.1 for procedures descriptions as specified in OGC SensorML 1.0.1';


--
-- TOC entry 248 (class 1259 OID 21076)
-- Name: procedureid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE procedureid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procedureid_seq OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 20677)
-- Name: relatedfeature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE relatedfeature (
    relatedfeatureid bigint NOT NULL,
    featureofinterestid bigint NOT NULL
);


ALTER TABLE relatedfeature OWNER TO postgres;

--
-- TOC entry 4128 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE relatedfeature; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE relatedfeature IS 'Table to store related feature information used in the OGC SOS 2.0 Capabilities (See also OGC SWES 2.0). Mapping file: mapping/transactionl/RelatedFeature.hbm.xml';


--
-- TOC entry 4129 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN relatedfeature.relatedfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeature.relatedfeatureid IS 'Table primary key, used for relations';


--
-- TOC entry 4130 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN relatedfeature.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeature.featureofinterestid IS 'Foreign Key (FK) to the related featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 229 (class 1259 OID 20682)
-- Name: relatedfeaturehasrole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE relatedfeaturehasrole (
    relatedfeatureid bigint NOT NULL,
    relatedfeatureroleid bigint NOT NULL
);


ALTER TABLE relatedfeaturehasrole OWNER TO postgres;

--
-- TOC entry 4131 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE relatedfeaturehasrole; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE relatedfeaturehasrole IS 'Relation table to store relatedFeatures and their associated relatedFeatureRoles. Mapping file: mapping/transactionl/RelatedFeature.hbm.xml';


--
-- TOC entry 4132 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN relatedfeaturehasrole.relatedfeatureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturehasrole.relatedfeatureid IS 'Foreign Key (FK) to the related relatedFeature. Contains "relatedFeature".relatedFeatureid';


--
-- TOC entry 4133 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN relatedfeaturehasrole.relatedfeatureroleid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturehasrole.relatedfeatureroleid IS 'Foreign Key (FK) to the related relatedFeatureRole. Contains "relatedFeatureRole".relatedFeatureRoleid';


--
-- TOC entry 249 (class 1259 OID 21078)
-- Name: relatedfeatureid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE relatedfeatureid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE relatedfeatureid_seq OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 20687)
-- Name: relatedfeaturerole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE relatedfeaturerole (
    relatedfeatureroleid bigint NOT NULL,
    relatedfeaturerole character varying(255) NOT NULL
);


ALTER TABLE relatedfeaturerole OWNER TO postgres;

--
-- TOC entry 4134 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE relatedfeaturerole; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE relatedfeaturerole IS 'Table to store related feature role information used in the OGC SOS 2.0 Capabilities (See also OGC SWES 2.0). Mapping file: mapping/transactionl/RelatedFeatureRole.hbm.xml';


--
-- TOC entry 4135 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN relatedfeaturerole.relatedfeatureroleid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturerole.relatedfeatureroleid IS 'Table primary key, used for relations';


--
-- TOC entry 4136 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN relatedfeaturerole.relatedfeaturerole; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN relatedfeaturerole.relatedfeaturerole IS 'The related feature role definition. See OGC SWES 2.0 specification';


--
-- TOC entry 250 (class 1259 OID 21080)
-- Name: relatedfeatureroleid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE relatedfeatureroleid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE relatedfeatureroleid_seq OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 20692)
-- Name: resulttemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE resulttemplate (
    resulttemplateid bigint NOT NULL,
    offeringid bigint NOT NULL,
    observablepropertyid bigint NOT NULL,
    procedureid bigint NOT NULL,
    featureofinterestid bigint NOT NULL,
    identifier character varying(255) NOT NULL,
    resultstructure text NOT NULL,
    resultencoding text NOT NULL
);


ALTER TABLE resulttemplate OWNER TO postgres;

--
-- TOC entry 4137 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE resulttemplate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE resulttemplate IS 'Table to store resultTemplates (OGC SOS 2.0 result handling profile). Mapping file: mapping/transactionl/ResultTemplate.hbm.xml';


--
-- TOC entry 4138 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.resulttemplateid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.resulttemplateid IS 'Table primary key';


--
-- TOC entry 4139 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.offeringid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.offeringid IS 'Foreign Key (FK) to the related offering. Contains "offering".offeringid';


--
-- TOC entry 4140 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.observablepropertyid IS 'Foreign Key (FK) to the related observableProperty. Contains "observableProperty".observablePropertyId';


--
-- TOC entry 4141 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureId';


--
-- TOC entry 4142 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.featureofinterestid IS 'Foreign Key (FK) to the related featureOfInterest. Contains "featureOfInterest".featureOfInterestid';


--
-- TOC entry 4143 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.identifier IS 'The resultTemplate identifier, required for InsertResult requests.';


--
-- TOC entry 4144 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.resultstructure; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.resultstructure IS 'The resultStructure as XML string. Describes the types and order of the values in a GetResultResponse/InsertResultRequest';


--
-- TOC entry 4145 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN resulttemplate.resultencoding; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN resulttemplate.resultencoding IS 'The resultEncoding as XML string. Describes the encoding of the values in a GetResultResponse/InsertResultRequest';


--
-- TOC entry 251 (class 1259 OID 21082)
-- Name: resulttemplateid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE resulttemplateid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE resulttemplateid_seq OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 20700)
-- Name: sensorsystem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE sensorsystem (
    parentsensorid bigint NOT NULL,
    childsensorid bigint NOT NULL
);


ALTER TABLE sensorsystem OWNER TO postgres;

--
-- TOC entry 4146 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE sensorsystem; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE sensorsystem IS 'Relation table to store procedure hierarchies. E.g. define a parent in a query and all childs are also contained in the response. Mapping file: mapping/transactional/TProcedure.hbm.xml';


--
-- TOC entry 4147 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN sensorsystem.parentsensorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN sensorsystem.parentsensorid IS 'Foreign Key (FK) to the related parent procedure. Contains "procedure".procedureid';


--
-- TOC entry 4148 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN sensorsystem.childsensorid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN sensorsystem.childsensorid IS 'Foreign Key (FK) to the related child procedure. Contains "procedure".procedureid';


--
-- TOC entry 233 (class 1259 OID 20705)
-- Name: series; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE series (
    seriesid bigint NOT NULL,
    featureofinterestid bigint NOT NULL,
    observablepropertyid bigint NOT NULL,
    procedureid bigint NOT NULL,
    deleted character(1) DEFAULT 'F'::bpchar NOT NULL,
    published character(1) DEFAULT 'T'::bpchar NOT NULL,
    firsttimestamp timestamp without time zone,
    lasttimestamp timestamp without time zone,
    firstnumericvalue double precision,
    lastnumericvalue double precision,
    unitid bigint,
    CONSTRAINT series_deleted_check CHECK ((deleted = ANY (ARRAY['T'::bpchar, 'F'::bpchar]))),
    CONSTRAINT series_published_check CHECK ((published = ANY (ARRAY['T'::bpchar, 'F'::bpchar])))
);


ALTER TABLE series OWNER TO postgres;

--
-- TOC entry 4149 (class 0 OID 0)
-- Dependencies: 233
-- Name: TABLE series; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE series IS 'Table to store a (time-) series which consists of featureOfInterest, observableProperty, and procedure. Mapping file: mapping/series/Series.hbm.xml';


--
-- TOC entry 4150 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.seriesid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.seriesid IS 'Table primary key, used for relations';


--
-- TOC entry 4151 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.featureofinterestid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.featureofinterestid IS 'Foreign Key (FK) to the related featureOfInterest. Contains "featureOfInterest".featureOfInterestId';


--
-- TOC entry 4152 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.observablepropertyid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.observablepropertyid IS 'Foreign Key (FK) to the related observableProperty. Contains "observableproperty".observablepropertyid';


--
-- TOC entry 4153 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureid';


--
-- TOC entry 4154 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.deleted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.deleted IS 'Flag to indicate that this series is deleted or not. Set if the related procedure is deleted via DeleteSensor operation (OGC SWES 2.0 - DeleteSensor operation)';


--
-- TOC entry 4155 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.published; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.published IS 'Flag to indicate that this series is published or not. A not published series is not contained in GetObservation and GetDataAvailability responses';


--
-- TOC entry 4156 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.firsttimestamp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.firsttimestamp IS 'The time stamp of the first (temporal) observation associated to this series';


--
-- TOC entry 4157 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.lasttimestamp; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.lasttimestamp IS 'The time stamp of the last (temporal) observation associated to this series';


--
-- TOC entry 4158 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.firstnumericvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.firstnumericvalue IS 'The value of the first (temporal) observation associated to this series';


--
-- TOC entry 4159 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.lastnumericvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.lastnumericvalue IS 'The value of the last (temporal) observation associated to this series';


--
-- TOC entry 4160 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN series.unitid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN series.unitid IS 'Foreign Key (FK) to the related unit of the first/last numeric values . Contains "unit".unitid';


--
-- TOC entry 252 (class 1259 OID 21084)
-- Name: seriesid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE seriesid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seriesid_seq OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 20714)
-- Name: swedataarrayvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE swedataarrayvalue (
    observationid bigint NOT NULL,
    value text
);


ALTER TABLE swedataarrayvalue OWNER TO postgres;

--
-- TOC entry 4161 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE swedataarrayvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE swedataarrayvalue IS 'Value table for SweDataArray observation';


--
-- TOC entry 4162 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN swedataarrayvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN swedataarrayvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4163 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN swedataarrayvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN swedataarrayvalue.value IS 'SweDataArray observation value';


--
-- TOC entry 235 (class 1259 OID 20722)
-- Name: textvalue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE textvalue (
    observationid bigint NOT NULL,
    value text
);


ALTER TABLE textvalue OWNER TO postgres;

--
-- TOC entry 4164 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE textvalue; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE textvalue IS 'Value table for text observation';


--
-- TOC entry 4165 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN textvalue.observationid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN textvalue.observationid IS 'Foreign Key (FK) to the related observation from the observation table. Contains "observation".observationid';


--
-- TOC entry 4166 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN textvalue.value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN textvalue.value IS 'Text observation value';


--
-- TOC entry 236 (class 1259 OID 20730)
-- Name: unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE unit (
    unitid bigint NOT NULL,
    unit character varying(255) NOT NULL
);


ALTER TABLE unit OWNER TO postgres;

--
-- TOC entry 4167 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE unit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE unit IS 'Table to store the unit of measure information, used in observations. Mapping file: mapping/core/Unit.hbm.xml';


--
-- TOC entry 4168 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN unit.unitid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN unit.unitid IS 'Table primary key, used for relations';


--
-- TOC entry 4169 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN unit.unit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN unit.unit IS 'The unit of measure of observations. See http://unitsofmeasure.org/ucum.html';


--
-- TOC entry 253 (class 1259 OID 21086)
-- Name: unitid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE unitid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE unitid_seq OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 20735)
-- Name: validproceduretime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE validproceduretime (
    validproceduretimeid bigint NOT NULL,
    procedureid bigint NOT NULL,
    proceduredescriptionformatid bigint NOT NULL,
    starttime timestamp without time zone NOT NULL,
    endtime timestamp without time zone,
    descriptionxml text NOT NULL
);


ALTER TABLE validproceduretime OWNER TO postgres;

--
-- TOC entry 4170 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE validproceduretime; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE validproceduretime IS 'Table to store procedure descriptions which were inserted or updated via the transactional Profile. Mapping file: mapping/transactionl/ValidProcedureTime.hbm.xml';


--
-- TOC entry 4171 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.validproceduretimeid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.validproceduretimeid IS 'Table primary key';


--
-- TOC entry 4172 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.procedureid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.procedureid IS 'Foreign Key (FK) to the related procedure. Contains "procedure".procedureid';


--
-- TOC entry 4173 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.proceduredescriptionformatid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.proceduredescriptionformatid IS 'Foreign Key (FK) to the related procedureDescriptionFormat. Contains "procedureDescriptionFormat".procedureDescriptionFormatid';


--
-- TOC entry 4174 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.starttime; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.starttime IS 'Timestamp since this procedure description is valid';


--
-- TOC entry 4175 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.endtime; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.endtime IS 'Timestamp since this procedure description is invalid';


--
-- TOC entry 4176 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN validproceduretime.descriptionxml; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN validproceduretime.descriptionxml IS 'Procedure description as XML string';


--
-- TOC entry 254 (class 1259 OID 21088)
-- Name: validproceduretimeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE validproceduretimeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE validproceduretimeid_seq OWNER TO postgres;

--
-- TOC entry 3963 (class 0 OID 20537)
-- Dependencies: 206
-- Data for Name: blobvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3964 (class 0 OID 20542)
-- Dependencies: 207
-- Data for Name: booleanvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3965 (class 0 OID 20549)
-- Dependencies: 208
-- Data for Name: categoryvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3966 (class 0 OID 20554)
-- Dependencies: 209
-- Data for Name: codespace; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO codespace VALUES (1, 'http://www.opengis.net/def/nil/OGC/0/unknown');


--
-- TOC entry 4177 (class 0 OID 0)
-- Dependencies: 238
-- Name: codespaceid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('codespaceid_seq', 1, true);


--
-- TOC entry 3967 (class 0 OID 20559)
-- Dependencies: 210
-- Data for Name: compositephenomenon; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3968 (class 0 OID 20564)
-- Dependencies: 211
-- Data for Name: countvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3969 (class 0 OID 20569)
-- Dependencies: 212
-- Data for Name: featureofinterest; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO featureofinterest VALUES (1, 'T', 2, 'wxt520', 1, 'wxt520', 1, NULL, '0101000020E6100000FEFFFF3F089C1E40FAFFFFBFA6F74940', NULL, NULL);


--
-- TOC entry 4178 (class 0 OID 0)
-- Dependencies: 239
-- Name: featureofinterestid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featureofinterestid_seq', 1, true);


--
-- TOC entry 3970 (class 0 OID 20577)
-- Dependencies: 213
-- Data for Name: featureofinteresttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO featureofinteresttype VALUES (1, 'http://www.opengis.net/def/samplingFeatureType/OGC-OM/2.0/SF_SamplingPoint');
INSERT INTO featureofinteresttype VALUES (2, 'http://www.opengis.net/def/nil/OGC/0/unknown');


--
-- TOC entry 4179 (class 0 OID 0)
-- Dependencies: 240
-- Name: featureofinteresttypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featureofinteresttypeid_seq', 2, true);


--
-- TOC entry 3971 (class 0 OID 20582)
-- Dependencies: 214
-- Data for Name: featurerelation; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3972 (class 0 OID 20587)
-- Dependencies: 215
-- Data for Name: geometryvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3973 (class 0 OID 20595)
-- Dependencies: 216
-- Data for Name: numericvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO numericvalue VALUES (1, 12.5);
INSERT INTO numericvalue VALUES (2, 12.5);
INSERT INTO numericvalue VALUES (3, 15.9000000000000004);
INSERT INTO numericvalue VALUES (4, 16.8000000000000007);
INSERT INTO numericvalue VALUES (5, 16.6000000000000014);
INSERT INTO numericvalue VALUES (6, 13.1999999999999993);
INSERT INTO numericvalue VALUES (7, 13.5999999999999996);
INSERT INTO numericvalue VALUES (8, 11.5999999999999996);
INSERT INTO numericvalue VALUES (9, 12);
INSERT INTO numericvalue VALUES (10, 9.80000000000000071);
INSERT INTO numericvalue VALUES (11, 10.0999999999999996);
INSERT INTO numericvalue VALUES (12, 13.4000000000000004);
INSERT INTO numericvalue VALUES (13, 11.4000000000000004);
INSERT INTO numericvalue VALUES (14, 10.6999999999999993);
INSERT INTO numericvalue VALUES (15, 16.5);
INSERT INTO numericvalue VALUES (16, 17.1999999999999993);
INSERT INTO numericvalue VALUES (17, 13.6999999999999993);
INSERT INTO numericvalue VALUES (18, 13.9000000000000004);
INSERT INTO numericvalue VALUES (19, 11.1999999999999993);
INSERT INTO numericvalue VALUES (20, 10.3000000000000007);
INSERT INTO numericvalue VALUES (21, 10.9000000000000004);
INSERT INTO numericvalue VALUES (22, 11.9000000000000004);
INSERT INTO numericvalue VALUES (23, 6.79999999999999982);
INSERT INTO numericvalue VALUES (24, 11.5);
INSERT INTO numericvalue VALUES (25, 11.5);
INSERT INTO numericvalue VALUES (26, 14);
INSERT INTO numericvalue VALUES (27, 12.6999999999999993);
INSERT INTO numericvalue VALUES (28, 9.59999999999999964);
INSERT INTO numericvalue VALUES (29, 7.59999999999999964);
INSERT INTO numericvalue VALUES (30, 7);
INSERT INTO numericvalue VALUES (31, 6.90000000000000036);
INSERT INTO numericvalue VALUES (32, 8);
INSERT INTO numericvalue VALUES (33, 9.30000000000000071);
INSERT INTO numericvalue VALUES (34, 9.40000000000000036);
INSERT INTO numericvalue VALUES (35, 11.1999999999999993);
INSERT INTO numericvalue VALUES (36, 11.5);
INSERT INTO numericvalue VALUES (37, 10.5999999999999996);
INSERT INTO numericvalue VALUES (38, 10.8000000000000007);
INSERT INTO numericvalue VALUES (39, 10.5);
INSERT INTO numericvalue VALUES (40, 10.9000000000000004);
INSERT INTO numericvalue VALUES (41, 10.5999999999999996);
INSERT INTO numericvalue VALUES (42, 10.8000000000000007);
INSERT INTO numericvalue VALUES (43, 11.5);
INSERT INTO numericvalue VALUES (44, 14.5999999999999996);
INSERT INTO numericvalue VALUES (45, 13.5999999999999996);
INSERT INTO numericvalue VALUES (46, 13.8000000000000007);
INSERT INTO numericvalue VALUES (47, 12.1999999999999993);
INSERT INTO numericvalue VALUES (48, 11.6999999999999993);
INSERT INTO numericvalue VALUES (49, 10.3000000000000007);
INSERT INTO numericvalue VALUES (50, 8.30000000000000071);
INSERT INTO numericvalue VALUES (51, 6.79999999999999982);
INSERT INTO numericvalue VALUES (52, 8.69999999999999929);
INSERT INTO numericvalue VALUES (53, 13.5999999999999996);
INSERT INTO numericvalue VALUES (54, 14);
INSERT INTO numericvalue VALUES (55, 12.5999999999999996);
INSERT INTO numericvalue VALUES (56, 12.1999999999999993);
INSERT INTO numericvalue VALUES (57, 8.09999999999999964);
INSERT INTO numericvalue VALUES (58, 9.19999999999999929);
INSERT INTO numericvalue VALUES (59, 9.09999999999999964);
INSERT INTO numericvalue VALUES (60, 5.79999999999999982);
INSERT INTO numericvalue VALUES (61, 4.79999999999999982);
INSERT INTO numericvalue VALUES (62, 6.79999999999999982);
INSERT INTO numericvalue VALUES (63, 11.6999999999999993);
INSERT INTO numericvalue VALUES (64, 13.6999999999999993);
INSERT INTO numericvalue VALUES (65, 11.8000000000000007);
INSERT INTO numericvalue VALUES (66, 9.09999999999999964);
INSERT INTO numericvalue VALUES (67, 9);
INSERT INTO numericvalue VALUES (68, 5.5);
INSERT INTO numericvalue VALUES (69, 3.89999999999999991);
INSERT INTO numericvalue VALUES (70, 5.90000000000000036);
INSERT INTO numericvalue VALUES (71, 6.70000000000000018);
INSERT INTO numericvalue VALUES (72, 8.30000000000000071);
INSERT INTO numericvalue VALUES (73, 8);
INSERT INTO numericvalue VALUES (74, 9.69999999999999929);
INSERT INTO numericvalue VALUES (75, 10);
INSERT INTO numericvalue VALUES (76, 9.90000000000000036);
INSERT INTO numericvalue VALUES (77, 9.30000000000000071);
INSERT INTO numericvalue VALUES (78, 8.19999999999999929);
INSERT INTO numericvalue VALUES (79, 7.70000000000000018);
INSERT INTO numericvalue VALUES (80, 7.79999999999999982);
INSERT INTO numericvalue VALUES (81, 6.59999999999999964);
INSERT INTO numericvalue VALUES (82, 7.5);
INSERT INTO numericvalue VALUES (83, 10.4000000000000004);
INSERT INTO numericvalue VALUES (84, 12.8000000000000007);
INSERT INTO numericvalue VALUES (85, 13.8000000000000007);
INSERT INTO numericvalue VALUES (86, 11.5);
INSERT INTO numericvalue VALUES (87, 8.80000000000000071);
INSERT INTO numericvalue VALUES (88, 13);
INSERT INTO numericvalue VALUES (89, 12.1999999999999993);
INSERT INTO numericvalue VALUES (90, 13.6999999999999993);
INSERT INTO numericvalue VALUES (91, 13.4000000000000004);
INSERT INTO numericvalue VALUES (92, 8.5);
INSERT INTO numericvalue VALUES (93, 8.30000000000000071);
INSERT INTO numericvalue VALUES (94, 5.90000000000000036);
INSERT INTO numericvalue VALUES (95, 4.70000000000000018);
INSERT INTO numericvalue VALUES (96, 4.20000000000000018);
INSERT INTO numericvalue VALUES (97, 8.69999999999999929);
INSERT INTO numericvalue VALUES (98, 16.5);
INSERT INTO numericvalue VALUES (99, 19.3000000000000007);
INSERT INTO numericvalue VALUES (100, 18.1999999999999993);
INSERT INTO numericvalue VALUES (101, 12.0999999999999996);
INSERT INTO numericvalue VALUES (102, 9.69999999999999929);
INSERT INTO numericvalue VALUES (103, 9.90000000000000036);
INSERT INTO numericvalue VALUES (104, 8.69999999999999929);
INSERT INTO numericvalue VALUES (105, 9.69999999999999929);
INSERT INTO numericvalue VALUES (106, 9.40000000000000036);
INSERT INTO numericvalue VALUES (107, 13.0999999999999996);
INSERT INTO numericvalue VALUES (108, 15.4000000000000004);
INSERT INTO numericvalue VALUES (109, 15.0999999999999996);
INSERT INTO numericvalue VALUES (110, 13.4000000000000004);
INSERT INTO numericvalue VALUES (111, 11.0999999999999996);
INSERT INTO numericvalue VALUES (112, 8.59999999999999964);
INSERT INTO numericvalue VALUES (113, 9.19999999999999929);
INSERT INTO numericvalue VALUES (114, 7.20000000000000018);
INSERT INTO numericvalue VALUES (115, 7.90000000000000036);
INSERT INTO numericvalue VALUES (116, 6.90000000000000036);
INSERT INTO numericvalue VALUES (117, 11.0999999999999996);
INSERT INTO numericvalue VALUES (118, 9.40000000000000036);
INSERT INTO numericvalue VALUES (119, 10.0999999999999996);
INSERT INTO numericvalue VALUES (120, 9.09999999999999964);
INSERT INTO numericvalue VALUES (121, 8.19999999999999929);
INSERT INTO numericvalue VALUES (122, 8.19999999999999929);
INSERT INTO numericvalue VALUES (123, 7.09999999999999964);
INSERT INTO numericvalue VALUES (124, 6.70000000000000018);
INSERT INTO numericvalue VALUES (125, 6.59999999999999964);
INSERT INTO numericvalue VALUES (126, 7.70000000000000018);
INSERT INTO numericvalue VALUES (127, 9.19999999999999929);
INSERT INTO numericvalue VALUES (128, 8);
INSERT INTO numericvalue VALUES (129, 7.70000000000000018);
INSERT INTO numericvalue VALUES (130, 8.19999999999999929);
INSERT INTO numericvalue VALUES (131, 8.09999999999999964);
INSERT INTO numericvalue VALUES (132, 8.69999999999999929);
INSERT INTO numericvalue VALUES (133, 8.30000000000000071);
INSERT INTO numericvalue VALUES (134, 7.59999999999999964);
INSERT INTO numericvalue VALUES (135, 7.5);
INSERT INTO numericvalue VALUES (136, 9.40000000000000036);
INSERT INTO numericvalue VALUES (137, 9.69999999999999929);
INSERT INTO numericvalue VALUES (138, 9);
INSERT INTO numericvalue VALUES (139, 8.09999999999999964);
INSERT INTO numericvalue VALUES (140, 5.20000000000000018);
INSERT INTO numericvalue VALUES (141, 4.70000000000000018);
INSERT INTO numericvalue VALUES (142, 2.70000000000000018);
INSERT INTO numericvalue VALUES (143, 2.29999999999999982);
INSERT INTO numericvalue VALUES (144, 2.29999999999999982);
INSERT INTO numericvalue VALUES (145, 5);
INSERT INTO numericvalue VALUES (146, 9.5);
INSERT INTO numericvalue VALUES (147, 10.6999999999999993);
INSERT INTO numericvalue VALUES (148, 6.79999999999999982);
INSERT INTO numericvalue VALUES (149, 6.90000000000000036);
INSERT INTO numericvalue VALUES (150, 5.70000000000000018);
INSERT INTO numericvalue VALUES (151, 5.59999999999999964);
INSERT INTO numericvalue VALUES (152, 5.79999999999999982);
INSERT INTO numericvalue VALUES (153, 6.5);
INSERT INTO numericvalue VALUES (154, 7.09999999999999964);
INSERT INTO numericvalue VALUES (155, 9.30000000000000071);
INSERT INTO numericvalue VALUES (156, 9);
INSERT INTO numericvalue VALUES (157, 9.69999999999999929);
INSERT INTO numericvalue VALUES (158, 9.5);
INSERT INTO numericvalue VALUES (159, 9.30000000000000071);
INSERT INTO numericvalue VALUES (160, 9.40000000000000036);
INSERT INTO numericvalue VALUES (161, 9.09999999999999964);
INSERT INTO numericvalue VALUES (162, 8.69999999999999929);
INSERT INTO numericvalue VALUES (163, 8.5);
INSERT INTO numericvalue VALUES (164, 10);
INSERT INTO numericvalue VALUES (165, 10.5999999999999996);
INSERT INTO numericvalue VALUES (166, 12.9000000000000004);
INSERT INTO numericvalue VALUES (167, 12.5999999999999996);
INSERT INTO numericvalue VALUES (168, 11.9000000000000004);
INSERT INTO numericvalue VALUES (169, 11.3000000000000007);
INSERT INTO numericvalue VALUES (170, 11.1999999999999993);
INSERT INTO numericvalue VALUES (171, 12);
INSERT INTO numericvalue VALUES (172, 12);
INSERT INTO numericvalue VALUES (173, 7.70000000000000018);
INSERT INTO numericvalue VALUES (174, 8.30000000000000071);
INSERT INTO numericvalue VALUES (175, 14.9000000000000004);
INSERT INTO numericvalue VALUES (176, 14.0999999999999996);
INSERT INTO numericvalue VALUES (177, 15);
INSERT INTO numericvalue VALUES (178, 8.80000000000000071);
INSERT INTO numericvalue VALUES (179, 7.5);
INSERT INTO numericvalue VALUES (180, 8);
INSERT INTO numericvalue VALUES (181, 7.79999999999999982);
INSERT INTO numericvalue VALUES (182, 6.79999999999999982);
INSERT INTO numericvalue VALUES (183, 6.09999999999999964);
INSERT INTO numericvalue VALUES (184, 7.70000000000000018);
INSERT INTO numericvalue VALUES (185, 13.9000000000000004);
INSERT INTO numericvalue VALUES (186, 13.0999999999999996);
INSERT INTO numericvalue VALUES (187, 13.3000000000000007);
INSERT INTO numericvalue VALUES (188, 11);
INSERT INTO numericvalue VALUES (189, 9.40000000000000036);
INSERT INTO numericvalue VALUES (190, 9.80000000000000071);
INSERT INTO numericvalue VALUES (191, 10.1999999999999993);
INSERT INTO numericvalue VALUES (192, 9);
INSERT INTO numericvalue VALUES (193, 10.4000000000000004);
INSERT INTO numericvalue VALUES (194, 15.5999999999999996);
INSERT INTO numericvalue VALUES (195, 16.3999999999999986);
INSERT INTO numericvalue VALUES (196, 13.9000000000000004);
INSERT INTO numericvalue VALUES (197, 10.6999999999999993);
INSERT INTO numericvalue VALUES (198, 7.90000000000000036);
INSERT INTO numericvalue VALUES (199, 6.90000000000000036);
INSERT INTO numericvalue VALUES (200, 6.79999999999999982);
INSERT INTO numericvalue VALUES (201, 12.5);
INSERT INTO numericvalue VALUES (202, 12.5999999999999996);
INSERT INTO numericvalue VALUES (203, 16.8000000000000007);
INSERT INTO numericvalue VALUES (204, 17.6999999999999993);
INSERT INTO numericvalue VALUES (205, 17.1000000000000014);
INSERT INTO numericvalue VALUES (206, 13.1999999999999993);
INSERT INTO numericvalue VALUES (207, 13.5999999999999996);
INSERT INTO numericvalue VALUES (208, 11.5999999999999996);
INSERT INTO numericvalue VALUES (209, 11.9000000000000004);
INSERT INTO numericvalue VALUES (210, 9.80000000000000071);
INSERT INTO numericvalue VALUES (211, 10.0999999999999996);
INSERT INTO numericvalue VALUES (212, 13.6999999999999993);
INSERT INTO numericvalue VALUES (213, 11.5);
INSERT INTO numericvalue VALUES (214, 10.9000000000000004);
INSERT INTO numericvalue VALUES (215, 18.1000000000000014);
INSERT INTO numericvalue VALUES (216, 17.8999999999999986);
INSERT INTO numericvalue VALUES (217, 13.8000000000000007);
INSERT INTO numericvalue VALUES (218, 13.8000000000000007);
INSERT INTO numericvalue VALUES (219, 11.5999999999999996);
INSERT INTO numericvalue VALUES (220, 10.4000000000000004);
INSERT INTO numericvalue VALUES (221, 11.5);
INSERT INTO numericvalue VALUES (222, 12);
INSERT INTO numericvalue VALUES (223, 6.79999999999999982);
INSERT INTO numericvalue VALUES (224, 12.4000000000000004);
INSERT INTO numericvalue VALUES (225, 11.8000000000000007);
INSERT INTO numericvalue VALUES (226, 14.8000000000000007);
INSERT INTO numericvalue VALUES (227, 13.4000000000000004);
INSERT INTO numericvalue VALUES (228, 9.69999999999999929);
INSERT INTO numericvalue VALUES (229, 7.70000000000000018);
INSERT INTO numericvalue VALUES (230, 7);
INSERT INTO numericvalue VALUES (231, 7);
INSERT INTO numericvalue VALUES (232, 7.90000000000000036);
INSERT INTO numericvalue VALUES (233, 9.5);
INSERT INTO numericvalue VALUES (234, 9.80000000000000071);
INSERT INTO numericvalue VALUES (235, 11.5);
INSERT INTO numericvalue VALUES (236, 11.8000000000000007);
INSERT INTO numericvalue VALUES (237, 10.6999999999999993);
INSERT INTO numericvalue VALUES (238, 10.9000000000000004);
INSERT INTO numericvalue VALUES (239, 10.6999999999999993);
INSERT INTO numericvalue VALUES (240, 11);
INSERT INTO numericvalue VALUES (241, 10.8000000000000007);
INSERT INTO numericvalue VALUES (242, 11);
INSERT INTO numericvalue VALUES (243, 11.8000000000000007);
INSERT INTO numericvalue VALUES (244, 15.1999999999999993);
INSERT INTO numericvalue VALUES (245, 14);
INSERT INTO numericvalue VALUES (246, 14.4000000000000004);
INSERT INTO numericvalue VALUES (247, 12.5);
INSERT INTO numericvalue VALUES (248, 11.9000000000000004);
INSERT INTO numericvalue VALUES (249, 10.4000000000000004);
INSERT INTO numericvalue VALUES (250, 8.40000000000000036);
INSERT INTO numericvalue VALUES (251, 6.79999999999999982);
INSERT INTO numericvalue VALUES (252, 10.6999999999999993);
INSERT INTO numericvalue VALUES (253, 14.8000000000000007);
INSERT INTO numericvalue VALUES (254, 15.4000000000000004);
INSERT INTO numericvalue VALUES (255, 12.9000000000000004);
INSERT INTO numericvalue VALUES (256, 12.5999999999999996);
INSERT INTO numericvalue VALUES (257, 8.09999999999999964);
INSERT INTO numericvalue VALUES (258, 9.30000000000000071);
INSERT INTO numericvalue VALUES (259, 9.19999999999999929);
INSERT INTO numericvalue VALUES (260, 5.79999999999999982);
INSERT INTO numericvalue VALUES (261, 4.90000000000000036);
INSERT INTO numericvalue VALUES (262, 7.09999999999999964);
INSERT INTO numericvalue VALUES (263, 13.9000000000000004);
INSERT INTO numericvalue VALUES (264, 15.3000000000000007);
INSERT INTO numericvalue VALUES (265, 12.0999999999999996);
INSERT INTO numericvalue VALUES (266, 9.19999999999999929);
INSERT INTO numericvalue VALUES (267, 9.19999999999999929);
INSERT INTO numericvalue VALUES (268, 5.59999999999999964);
INSERT INTO numericvalue VALUES (269, 4);
INSERT INTO numericvalue VALUES (270, 5.90000000000000036);
INSERT INTO numericvalue VALUES (271, 6.79999999999999982);
INSERT INTO numericvalue VALUES (272, 8.59999999999999964);
INSERT INTO numericvalue VALUES (273, 8.19999999999999929);
INSERT INTO numericvalue VALUES (274, 10);
INSERT INTO numericvalue VALUES (275, 10.1999999999999993);
INSERT INTO numericvalue VALUES (276, 10.0999999999999996);
INSERT INTO numericvalue VALUES (277, 9.5);
INSERT INTO numericvalue VALUES (278, 8.80000000000000071);
INSERT INTO numericvalue VALUES (279, 7.70000000000000018);
INSERT INTO numericvalue VALUES (280, 7.90000000000000036);
INSERT INTO numericvalue VALUES (281, 6.70000000000000018);
INSERT INTO numericvalue VALUES (282, 7.79999999999999982);
INSERT INTO numericvalue VALUES (283, 12.3000000000000007);
INSERT INTO numericvalue VALUES (284, 13.5);
INSERT INTO numericvalue VALUES (285, 14);
INSERT INTO numericvalue VALUES (286, 11.6999999999999993);
INSERT INTO numericvalue VALUES (287, 8.90000000000000036);
INSERT INTO numericvalue VALUES (288, 13.0999999999999996);
INSERT INTO numericvalue VALUES (289, 12.4000000000000004);
INSERT INTO numericvalue VALUES (290, 13.9000000000000004);
INSERT INTO numericvalue VALUES (291, 13.9000000000000004);
INSERT INTO numericvalue VALUES (292, 8.59999999999999964);
INSERT INTO numericvalue VALUES (293, 8.30000000000000071);
INSERT INTO numericvalue VALUES (294, 6);
INSERT INTO numericvalue VALUES (295, 4.70000000000000018);
INSERT INTO numericvalue VALUES (296, 4.40000000000000036);
INSERT INTO numericvalue VALUES (297, 8.59999999999999964);
INSERT INTO numericvalue VALUES (298, 17.6000000000000014);
INSERT INTO numericvalue VALUES (299, 20.8000000000000007);
INSERT INTO numericvalue VALUES (300, 18.1999999999999993);
INSERT INTO numericvalue VALUES (301, 12.0999999999999996);
INSERT INTO numericvalue VALUES (302, 9.59999999999999964);
INSERT INTO numericvalue VALUES (303, 10);
INSERT INTO numericvalue VALUES (304, 8.80000000000000071);
INSERT INTO numericvalue VALUES (305, 9.80000000000000071);
INSERT INTO numericvalue VALUES (306, 9.40000000000000036);
INSERT INTO numericvalue VALUES (307, 13.5);
INSERT INTO numericvalue VALUES (308, 15.8000000000000007);
INSERT INTO numericvalue VALUES (309, 15.4000000000000004);
INSERT INTO numericvalue VALUES (310, 13.5999999999999996);
INSERT INTO numericvalue VALUES (311, 11.1999999999999993);
INSERT INTO numericvalue VALUES (312, 8.69999999999999929);
INSERT INTO numericvalue VALUES (313, 9.19999999999999929);
INSERT INTO numericvalue VALUES (314, 7.20000000000000018);
INSERT INTO numericvalue VALUES (315, 8);
INSERT INTO numericvalue VALUES (316, 6.90000000000000036);
INSERT INTO numericvalue VALUES (317, 12.3000000000000007);
INSERT INTO numericvalue VALUES (318, 9.80000000000000071);
INSERT INTO numericvalue VALUES (319, 10.3000000000000007);
INSERT INTO numericvalue VALUES (320, 8.80000000000000071);
INSERT INTO numericvalue VALUES (321, 8.19999999999999929);
INSERT INTO numericvalue VALUES (322, 8.30000000000000071);
INSERT INTO numericvalue VALUES (323, 7.20000000000000018);
INSERT INTO numericvalue VALUES (324, 7.40000000000000036);
INSERT INTO numericvalue VALUES (325, 6.79999999999999982);
INSERT INTO numericvalue VALUES (326, 7.59999999999999964);
INSERT INTO numericvalue VALUES (327, 9.5);
INSERT INTO numericvalue VALUES (328, 8.40000000000000036);
INSERT INTO numericvalue VALUES (329, 7.70000000000000018);
INSERT INTO numericvalue VALUES (330, 8.19999999999999929);
INSERT INTO numericvalue VALUES (331, 8.19999999999999929);
INSERT INTO numericvalue VALUES (332, 8.80000000000000071);
INSERT INTO numericvalue VALUES (333, 8.19999999999999929);
INSERT INTO numericvalue VALUES (334, 7.70000000000000018);
INSERT INTO numericvalue VALUES (335, 7.70000000000000018);
INSERT INTO numericvalue VALUES (336, 10.0999999999999996);
INSERT INTO numericvalue VALUES (337, 10.1999999999999993);
INSERT INTO numericvalue VALUES (338, 9.40000000000000036);
INSERT INTO numericvalue VALUES (339, 8.30000000000000071);
INSERT INTO numericvalue VALUES (340, 5.29999999999999982);
INSERT INTO numericvalue VALUES (341, 5);
INSERT INTO numericvalue VALUES (342, 2.89999999999999991);
INSERT INTO numericvalue VALUES (343, 2.39999999999999991);
INSERT INTO numericvalue VALUES (344, 2.5);
INSERT INTO numericvalue VALUES (345, 5.5);
INSERT INTO numericvalue VALUES (346, 11.1999999999999993);
INSERT INTO numericvalue VALUES (347, 11.5999999999999996);
INSERT INTO numericvalue VALUES (348, 7);
INSERT INTO numericvalue VALUES (349, 7);
INSERT INTO numericvalue VALUES (350, 5.79999999999999982);
INSERT INTO numericvalue VALUES (351, 5.59999999999999964);
INSERT INTO numericvalue VALUES (352, 5.90000000000000036);
INSERT INTO numericvalue VALUES (353, 6.59999999999999964);
INSERT INTO numericvalue VALUES (354, 7.29999999999999982);
INSERT INTO numericvalue VALUES (355, 9.09999999999999964);
INSERT INTO numericvalue VALUES (356, 9.69999999999999929);
INSERT INTO numericvalue VALUES (357, 9.90000000000000036);
INSERT INTO numericvalue VALUES (358, 9.59999999999999964);
INSERT INTO numericvalue VALUES (359, 9.59999999999999964);
INSERT INTO numericvalue VALUES (360, 9.5);
INSERT INTO numericvalue VALUES (361, 9.19999999999999929);
INSERT INTO numericvalue VALUES (362, 8.90000000000000036);
INSERT INTO numericvalue VALUES (363, 8.69999999999999929);
INSERT INTO numericvalue VALUES (364, 10.0999999999999996);
INSERT INTO numericvalue VALUES (365, 10.5999999999999996);
INSERT INTO numericvalue VALUES (366, 13.1999999999999993);
INSERT INTO numericvalue VALUES (367, 12.9000000000000004);
INSERT INTO numericvalue VALUES (368, 12.0999999999999996);
INSERT INTO numericvalue VALUES (369, 11.4000000000000004);
INSERT INTO numericvalue VALUES (370, 11.3000000000000007);
INSERT INTO numericvalue VALUES (371, 12.1999999999999993);
INSERT INTO numericvalue VALUES (372, 12.0999999999999996);
INSERT INTO numericvalue VALUES (373, 7.79999999999999982);
INSERT INTO numericvalue VALUES (374, 9.09999999999999964);
INSERT INTO numericvalue VALUES (375, 15.3000000000000007);
INSERT INTO numericvalue VALUES (376, 15.6999999999999993);
INSERT INTO numericvalue VALUES (377, 15.8000000000000007);
INSERT INTO numericvalue VALUES (378, 11.3000000000000007);
INSERT INTO numericvalue VALUES (379, 8.09999999999999964);
INSERT INTO numericvalue VALUES (380, 7.29999999999999982);
INSERT INTO numericvalue VALUES (381, 7.90000000000000036);
INSERT INTO numericvalue VALUES (382, 6.90000000000000036);
INSERT INTO numericvalue VALUES (383, 6.20000000000000018);
INSERT INTO numericvalue VALUES (384, 8);
INSERT INTO numericvalue VALUES (385, 14.5999999999999996);
INSERT INTO numericvalue VALUES (386, 13.5999999999999996);
INSERT INTO numericvalue VALUES (387, 11.6999999999999993);
INSERT INTO numericvalue VALUES (388, 10.4000000000000004);
INSERT INTO numericvalue VALUES (389, 9.5);
INSERT INTO numericvalue VALUES (390, 9.90000000000000036);
INSERT INTO numericvalue VALUES (391, 10.3000000000000007);
INSERT INTO numericvalue VALUES (392, 9.09999999999999964);
INSERT INTO numericvalue VALUES (393, 11.0999999999999996);
INSERT INTO numericvalue VALUES (394, 16.8999999999999986);
INSERT INTO numericvalue VALUES (395, 18.1000000000000014);
INSERT INTO numericvalue VALUES (396, 14);
INSERT INTO numericvalue VALUES (397, 10.8000000000000007);
INSERT INTO numericvalue VALUES (398, 8.09999999999999964);
INSERT INTO numericvalue VALUES (399, 7);
INSERT INTO numericvalue VALUES (400, 6.79999999999999982);
INSERT INTO numericvalue VALUES (401, 85);
INSERT INTO numericvalue VALUES (402, 85.2000000000000028);
INSERT INTO numericvalue VALUES (403, 79.5999999999999943);
INSERT INTO numericvalue VALUES (404, 66.7000000000000028);
INSERT INTO numericvalue VALUES (405, 65.5999999999999943);
INSERT INTO numericvalue VALUES (406, 83.7999999999999972);
INSERT INTO numericvalue VALUES (407, 82.5999999999999943);
INSERT INTO numericvalue VALUES (408, 90.5999999999999943);
INSERT INTO numericvalue VALUES (409, 87.0999999999999943);
INSERT INTO numericvalue VALUES (410, 90.0999999999999943);
INSERT INTO numericvalue VALUES (411, 84.7999999999999972);
INSERT INTO numericvalue VALUES (412, 68.9000000000000057);
INSERT INTO numericvalue VALUES (413, 86.2999999999999972);
INSERT INTO numericvalue VALUES (414, 90);
INSERT INTO numericvalue VALUES (415, 84.7000000000000028);
INSERT INTO numericvalue VALUES (416, 57.7000000000000028);
INSERT INTO numericvalue VALUES (417, 82.0999999999999943);
INSERT INTO numericvalue VALUES (418, 87.7999999999999972);
INSERT INTO numericvalue VALUES (419, 90.2999999999999972);
INSERT INTO numericvalue VALUES (420, 91.9000000000000057);
INSERT INTO numericvalue VALUES (421, 92.0999999999999943);
INSERT INTO numericvalue VALUES (422, 89);
INSERT INTO numericvalue VALUES (423, 81.7000000000000028);
INSERT INTO numericvalue VALUES (424, 62.7000000000000028);
INSERT INTO numericvalue VALUES (425, 58.7000000000000028);
INSERT INTO numericvalue VALUES (426, 45.3999999999999986);
INSERT INTO numericvalue VALUES (427, 49.2000000000000028);
INSERT INTO numericvalue VALUES (428, 60.6000000000000014);
INSERT INTO numericvalue VALUES (429, 66.2999999999999972);
INSERT INTO numericvalue VALUES (430, 75.2000000000000028);
INSERT INTO numericvalue VALUES (431, 76.5999999999999943);
INSERT INTO numericvalue VALUES (432, 71.7999999999999972);
INSERT INTO numericvalue VALUES (433, 68.0999999999999943);
INSERT INTO numericvalue VALUES (434, 74.2999999999999972);
INSERT INTO numericvalue VALUES (435, 72.2999999999999972);
INSERT INTO numericvalue VALUES (436, 75);
INSERT INTO numericvalue VALUES (437, 83.7000000000000028);
INSERT INTO numericvalue VALUES (438, 82.2000000000000028);
INSERT INTO numericvalue VALUES (439, 85.2000000000000028);
INSERT INTO numericvalue VALUES (440, 83.0999999999999943);
INSERT INTO numericvalue VALUES (441, 84.5999999999999943);
INSERT INTO numericvalue VALUES (442, 83);
INSERT INTO numericvalue VALUES (443, 80.9000000000000057);
INSERT INTO numericvalue VALUES (444, 65.9000000000000057);
INSERT INTO numericvalue VALUES (445, 65.2000000000000028);
INSERT INTO numericvalue VALUES (446, 76.2000000000000028);
INSERT INTO numericvalue VALUES (447, 78.0999999999999943);
INSERT INTO numericvalue VALUES (448, 83.5999999999999943);
INSERT INTO numericvalue VALUES (449, 87.2000000000000028);
INSERT INTO numericvalue VALUES (450, 81.7999999999999972);
INSERT INTO numericvalue VALUES (451, 89.5999999999999943);
INSERT INTO numericvalue VALUES (452, 83);
INSERT INTO numericvalue VALUES (453, 57.2999999999999972);
INSERT INTO numericvalue VALUES (454, 46.1000000000000014);
INSERT INTO numericvalue VALUES (455, 49.6000000000000014);
INSERT INTO numericvalue VALUES (456, 62.1000000000000014);
INSERT INTO numericvalue VALUES (457, 78.7999999999999972);
INSERT INTO numericvalue VALUES (458, 77.2000000000000028);
INSERT INTO numericvalue VALUES (459, 78.5);
INSERT INTO numericvalue VALUES (460, 88.5999999999999943);
INSERT INTO numericvalue VALUES (461, 91.0999999999999943);
INSERT INTO numericvalue VALUES (462, 86.4000000000000057);
INSERT INTO numericvalue VALUES (463, 51.5);
INSERT INTO numericvalue VALUES (464, 48.7999999999999972);
INSERT INTO numericvalue VALUES (465, 57.8999999999999986);
INSERT INTO numericvalue VALUES (466, 75.0999999999999943);
INSERT INTO numericvalue VALUES (467, 77);
INSERT INTO numericvalue VALUES (468, 88.5);
INSERT INTO numericvalue VALUES (469, 86.7999999999999972);
INSERT INTO numericvalue VALUES (470, 89.7999999999999972);
INSERT INTO numericvalue VALUES (471, 84.4000000000000057);
INSERT INTO numericvalue VALUES (472, 77.2000000000000028);
INSERT INTO numericvalue VALUES (473, 80.9000000000000057);
INSERT INTO numericvalue VALUES (474, 72.9000000000000057);
INSERT INTO numericvalue VALUES (475, 74.9000000000000057);
INSERT INTO numericvalue VALUES (476, 70.5);
INSERT INTO numericvalue VALUES (477, 71.7999999999999972);
INSERT INTO numericvalue VALUES (478, 79.4000000000000057);
INSERT INTO numericvalue VALUES (479, 81);
INSERT INTO numericvalue VALUES (480, 80.2999999999999972);
INSERT INTO numericvalue VALUES (481, 83.5999999999999943);
INSERT INTO numericvalue VALUES (482, 78.2999999999999972);
INSERT INTO numericvalue VALUES (483, 61.2999999999999972);
INSERT INTO numericvalue VALUES (484, 57.8999999999999986);
INSERT INTO numericvalue VALUES (485, 59);
INSERT INTO numericvalue VALUES (486, 68);
INSERT INTO numericvalue VALUES (487, 88.2999999999999972);
INSERT INTO numericvalue VALUES (488, 82.0999999999999943);
INSERT INTO numericvalue VALUES (489, 89.7000000000000028);
INSERT INTO numericvalue VALUES (490, 82.2000000000000028);
INSERT INTO numericvalue VALUES (491, 88.9000000000000057);
INSERT INTO numericvalue VALUES (492, 92.0999999999999943);
INSERT INTO numericvalue VALUES (493, 91.2999999999999972);
INSERT INTO numericvalue VALUES (494, 91.7000000000000028);
INSERT INTO numericvalue VALUES (495, 90.9000000000000057);
INSERT INTO numericvalue VALUES (496, 92.2999999999999972);
INSERT INTO numericvalue VALUES (497, 89.5999999999999943);
INSERT INTO numericvalue VALUES (498, 60.2999999999999972);
INSERT INTO numericvalue VALUES (499, 48.7000000000000028);
INSERT INTO numericvalue VALUES (500, 54.7000000000000028);
INSERT INTO numericvalue VALUES (501, 79.0999999999999943);
INSERT INTO numericvalue VALUES (502, 85.2000000000000028);
INSERT INTO numericvalue VALUES (503, 83.5);
INSERT INTO numericvalue VALUES (504, 88.5);
INSERT INTO numericvalue VALUES (505, 87.7999999999999972);
INSERT INTO numericvalue VALUES (506, 92.2000000000000028);
INSERT INTO numericvalue VALUES (507, 88.2999999999999972);
INSERT INTO numericvalue VALUES (508, 59.1000000000000014);
INSERT INTO numericvalue VALUES (509, 57);
INSERT INTO numericvalue VALUES (510, 66);
INSERT INTO numericvalue VALUES (511, 88.7000000000000028);
INSERT INTO numericvalue VALUES (512, 91.5999999999999943);
INSERT INTO numericvalue VALUES (513, 86.5999999999999943);
INSERT INTO numericvalue VALUES (514, 83.7000000000000028);
INSERT INTO numericvalue VALUES (515, 89.2000000000000028);
INSERT INTO numericvalue VALUES (516, 91);
INSERT INTO numericvalue VALUES (517, 69.0999999999999943);
INSERT INTO numericvalue VALUES (518, 80.5999999999999943);
INSERT INTO numericvalue VALUES (519, 73.0999999999999943);
INSERT INTO numericvalue VALUES (520, 86.7999999999999972);
INSERT INTO numericvalue VALUES (521, 89.2999999999999972);
INSERT INTO numericvalue VALUES (522, 89.5);
INSERT INTO numericvalue VALUES (523, 89.4000000000000057);
INSERT INTO numericvalue VALUES (524, 84.7999999999999972);
INSERT INTO numericvalue VALUES (525, 87.4000000000000057);
INSERT INTO numericvalue VALUES (526, 83.4000000000000057);
INSERT INTO numericvalue VALUES (527, 76);
INSERT INTO numericvalue VALUES (528, 87.2999999999999972);
INSERT INTO numericvalue VALUES (529, 90.5);
INSERT INTO numericvalue VALUES (530, 90.5);
INSERT INTO numericvalue VALUES (531, 91.7999999999999972);
INSERT INTO numericvalue VALUES (532, 90.7000000000000028);
INSERT INTO numericvalue VALUES (533, 90.5999999999999943);
INSERT INTO numericvalue VALUES (534, 89.5999999999999943);
INSERT INTO numericvalue VALUES (535, 88.4000000000000057);
INSERT INTO numericvalue VALUES (536, 76.0999999999999943);
INSERT INTO numericvalue VALUES (537, 73.7000000000000028);
INSERT INTO numericvalue VALUES (538, 79.9000000000000057);
INSERT INTO numericvalue VALUES (539, 80);
INSERT INTO numericvalue VALUES (540, 89.4000000000000057);
INSERT INTO numericvalue VALUES (541, 91.5);
INSERT INTO numericvalue VALUES (542, 93);
INSERT INTO numericvalue VALUES (543, 93.4000000000000057);
INSERT INTO numericvalue VALUES (544, 93.5999999999999943);
INSERT INTO numericvalue VALUES (545, 92.5);
INSERT INTO numericvalue VALUES (546, 73.9000000000000057);
INSERT INTO numericvalue VALUES (547, 70.7000000000000028);
INSERT INTO numericvalue VALUES (548, 85.2999999999999972);
INSERT INTO numericvalue VALUES (549, 81.9000000000000057);
INSERT INTO numericvalue VALUES (550, 87.2000000000000028);
INSERT INTO numericvalue VALUES (551, 88.5999999999999943);
INSERT INTO numericvalue VALUES (552, 89.2999999999999972);
INSERT INTO numericvalue VALUES (553, 88.2999999999999972);
INSERT INTO numericvalue VALUES (554, 86.5999999999999943);
INSERT INTO numericvalue VALUES (555, 90.2000000000000028);
INSERT INTO numericvalue VALUES (556, 85.2999999999999972);
INSERT INTO numericvalue VALUES (557, 87.0999999999999943);
INSERT INTO numericvalue VALUES (558, 85.0999999999999943);
INSERT INTO numericvalue VALUES (559, 88.7000000000000028);
INSERT INTO numericvalue VALUES (560, 89.5);
INSERT INTO numericvalue VALUES (561, 89.7999999999999972);
INSERT INTO numericvalue VALUES (562, 89.7999999999999972);
INSERT INTO numericvalue VALUES (563, 87.9000000000000057);
INSERT INTO numericvalue VALUES (564, 90);
INSERT INTO numericvalue VALUES (565, 89.2999999999999972);
INSERT INTO numericvalue VALUES (566, 82.2999999999999972);
INSERT INTO numericvalue VALUES (567, 81.0999999999999943);
INSERT INTO numericvalue VALUES (568, 80.5999999999999943);
INSERT INTO numericvalue VALUES (569, 82.5);
INSERT INTO numericvalue VALUES (570, 86.9000000000000057);
INSERT INTO numericvalue VALUES (571, 85.5999999999999943);
INSERT INTO numericvalue VALUES (572, 83.2000000000000028);
INSERT INTO numericvalue VALUES (573, 85.7000000000000028);
INSERT INTO numericvalue VALUES (574, 92.5999999999999943);
INSERT INTO numericvalue VALUES (575, 61.2999999999999972);
INSERT INTO numericvalue VALUES (576, 54.7999999999999972);
INSERT INTO numericvalue VALUES (577, 54.7999999999999972);
INSERT INTO numericvalue VALUES (578, 83.2999999999999972);
INSERT INTO numericvalue VALUES (579, 87);
INSERT INTO numericvalue VALUES (580, 88.7999999999999972);
INSERT INTO numericvalue VALUES (581, 89);
INSERT INTO numericvalue VALUES (582, 91);
INSERT INTO numericvalue VALUES (583, 91.5);
INSERT INTO numericvalue VALUES (584, 89.4000000000000057);
INSERT INTO numericvalue VALUES (585, 69.0999999999999943);
INSERT INTO numericvalue VALUES (586, 68.9000000000000057);
INSERT INTO numericvalue VALUES (587, 82.5);
INSERT INTO numericvalue VALUES (588, 87.2000000000000028);
INSERT INTO numericvalue VALUES (589, 88.7000000000000028);
INSERT INTO numericvalue VALUES (590, 85.7999999999999972);
INSERT INTO numericvalue VALUES (591, 83.4000000000000057);
INSERT INTO numericvalue VALUES (592, 87.4000000000000057);
INSERT INTO numericvalue VALUES (593, 78.5999999999999943);
INSERT INTO numericvalue VALUES (594, 57.8999999999999986);
INSERT INTO numericvalue VALUES (595, 55.1000000000000014);
INSERT INTO numericvalue VALUES (596, 60.2000000000000028);
INSERT INTO numericvalue VALUES (597, 85.5);
INSERT INTO numericvalue VALUES (598, 90.5);
INSERT INTO numericvalue VALUES (599, 89.2000000000000028);
INSERT INTO numericvalue VALUES (600, 90);
INSERT INTO numericvalue VALUES (601, 1003.20000000000005);
INSERT INTO numericvalue VALUES (602, 1002.79999999999995);
INSERT INTO numericvalue VALUES (603, 1002.60000000000002);
INSERT INTO numericvalue VALUES (604, 1000.70000000000005);
INSERT INTO numericvalue VALUES (605, 1000.20000000000005);
INSERT INTO numericvalue VALUES (606, 1001);
INSERT INTO numericvalue VALUES (607, 1002);
INSERT INTO numericvalue VALUES (608, 1001.60000000000002);
INSERT INTO numericvalue VALUES (609, 1002.10000000000002);
INSERT INTO numericvalue VALUES (610, 1001.79999999999995);
INSERT INTO numericvalue VALUES (611, 1002.29999999999995);
INSERT INTO numericvalue VALUES (612, 1002.79999999999995);
INSERT INTO numericvalue VALUES (613, 1003.5);
INSERT INTO numericvalue VALUES (614, 1014.89999999999998);
INSERT INTO numericvalue VALUES (615, 1016.89999999999998);
INSERT INTO numericvalue VALUES (616, 1018.20000000000005);
INSERT INTO numericvalue VALUES (617, 1018.70000000000005);
INSERT INTO numericvalue VALUES (618, 1019.70000000000005);
INSERT INTO numericvalue VALUES (619, 1022.60000000000002);
INSERT INTO numericvalue VALUES (620, 1023.20000000000005);
INSERT INTO numericvalue VALUES (621, 1024.20000000000005);
INSERT INTO numericvalue VALUES (622, 1025);
INSERT INTO numericvalue VALUES (623, 1025.59999999999991);
INSERT INTO numericvalue VALUES (624, 1028.40000000000009);
INSERT INTO numericvalue VALUES (625, 1028.09999999999991);
INSERT INTO numericvalue VALUES (626, 1025.79999999999995);
INSERT INTO numericvalue VALUES (627, 1024.40000000000009);
INSERT INTO numericvalue VALUES (628, 1023.29999999999995);
INSERT INTO numericvalue VALUES (629, 1023.20000000000005);
INSERT INTO numericvalue VALUES (630, 1021.79999999999995);
INSERT INTO numericvalue VALUES (631, 1019.79999999999995);
INSERT INTO numericvalue VALUES (632, 1018.70000000000005);
INSERT INTO numericvalue VALUES (633, 1018.5);
INSERT INTO numericvalue VALUES (634, 1017.70000000000005);
INSERT INTO numericvalue VALUES (635, 1016.20000000000005);
INSERT INTO numericvalue VALUES (636, 1016.10000000000002);
INSERT INTO numericvalue VALUES (637, 1016.10000000000002);
INSERT INTO numericvalue VALUES (638, 1016.10000000000002);
INSERT INTO numericvalue VALUES (639, 1015.5);
INSERT INTO numericvalue VALUES (640, 1015);
INSERT INTO numericvalue VALUES (641, 1014.20000000000005);
INSERT INTO numericvalue VALUES (642, 1014.10000000000002);
INSERT INTO numericvalue VALUES (643, 1014.79999999999995);
INSERT INTO numericvalue VALUES (644, 1014.60000000000002);
INSERT INTO numericvalue VALUES (645, 1013.60000000000002);
INSERT INTO numericvalue VALUES (646, 1013.79999999999995);
INSERT INTO numericvalue VALUES (647, 1014.70000000000005);
INSERT INTO numericvalue VALUES (648, 1014.79999999999995);
INSERT INTO numericvalue VALUES (649, 1015.39999999999998);
INSERT INTO numericvalue VALUES (650, 1015.20000000000005);
INSERT INTO numericvalue VALUES (651, 1015.89999999999998);
INSERT INTO numericvalue VALUES (652, 1016.70000000000005);
INSERT INTO numericvalue VALUES (653, 1017.29999999999995);
INSERT INTO numericvalue VALUES (654, 1017);
INSERT INTO numericvalue VALUES (655, 1017.20000000000005);
INSERT INTO numericvalue VALUES (656, 1018.10000000000002);
INSERT INTO numericvalue VALUES (657, 1018.70000000000005);
INSERT INTO numericvalue VALUES (658, 1018.60000000000002);
INSERT INTO numericvalue VALUES (659, 1018.20000000000005);
INSERT INTO numericvalue VALUES (660, 1018.10000000000002);
INSERT INTO numericvalue VALUES (661, 1018.5);
INSERT INTO numericvalue VALUES (662, 1017.70000000000005);
INSERT INTO numericvalue VALUES (663, 1017.5);
INSERT INTO numericvalue VALUES (664, 1015.79999999999995);
INSERT INTO numericvalue VALUES (665, 1015.5);
INSERT INTO numericvalue VALUES (666, 1016);
INSERT INTO numericvalue VALUES (667, 1015.89999999999998);
INSERT INTO numericvalue VALUES (668, 1015.5);
INSERT INTO numericvalue VALUES (669, 1015.10000000000002);
INSERT INTO numericvalue VALUES (670, 1014.5);
INSERT INTO numericvalue VALUES (671, 1013.60000000000002);
INSERT INTO numericvalue VALUES (672, 1014.60000000000002);
INSERT INTO numericvalue VALUES (673, 1012.60000000000002);
INSERT INTO numericvalue VALUES (674, 1011.89999999999998);
INSERT INTO numericvalue VALUES (675, 1010.89999999999998);
INSERT INTO numericvalue VALUES (676, 1009.10000000000002);
INSERT INTO numericvalue VALUES (677, 1008.89999999999998);
INSERT INTO numericvalue VALUES (678, 1008.10000000000002);
INSERT INTO numericvalue VALUES (679, 1007.29999999999995);
INSERT INTO numericvalue VALUES (680, 1006.79999999999995);
INSERT INTO numericvalue VALUES (681, 1004.5);
INSERT INTO numericvalue VALUES (682, 1004);
INSERT INTO numericvalue VALUES (683, 1003.10000000000002);
INSERT INTO numericvalue VALUES (684, 1002.20000000000005);
INSERT INTO numericvalue VALUES (685, 1000.89999999999998);
INSERT INTO numericvalue VALUES (686, 1000.10000000000002);
INSERT INTO numericvalue VALUES (687, 999.5);
INSERT INTO numericvalue VALUES (688, 1002.39999999999998);
INSERT INTO numericvalue VALUES (689, 1004.70000000000005);
INSERT INTO numericvalue VALUES (690, 1007.20000000000005);
INSERT INTO numericvalue VALUES (691, 1008.60000000000002);
INSERT INTO numericvalue VALUES (692, 1010.70000000000005);
INSERT INTO numericvalue VALUES (693, 1011.29999999999995);
INSERT INTO numericvalue VALUES (694, 1012.29999999999995);
INSERT INTO numericvalue VALUES (695, 1012.89999999999998);
INSERT INTO numericvalue VALUES (696, 1012.89999999999998);
INSERT INTO numericvalue VALUES (697, 1013.89999999999998);
INSERT INTO numericvalue VALUES (698, 1014);
INSERT INTO numericvalue VALUES (699, 1013.20000000000005);
INSERT INTO numericvalue VALUES (700, 1012.79999999999995);
INSERT INTO numericvalue VALUES (701, 1013.10000000000002);
INSERT INTO numericvalue VALUES (702, 1013.5);
INSERT INTO numericvalue VALUES (703, 1013.20000000000005);
INSERT INTO numericvalue VALUES (704, 1012.39999999999998);
INSERT INTO numericvalue VALUES (705, 1012.20000000000005);
INSERT INTO numericvalue VALUES (706, 1013.79999999999995);
INSERT INTO numericvalue VALUES (707, 1013.5);
INSERT INTO numericvalue VALUES (708, 1013);
INSERT INTO numericvalue VALUES (709, 1009.79999999999995);
INSERT INTO numericvalue VALUES (710, 1008.79999999999995);
INSERT INTO numericvalue VALUES (711, 1009.29999999999995);
INSERT INTO numericvalue VALUES (712, 1009.5);
INSERT INTO numericvalue VALUES (713, 1007.5);
INSERT INTO numericvalue VALUES (714, 1006.79999999999995);
INSERT INTO numericvalue VALUES (715, 1005.79999999999995);
INSERT INTO numericvalue VALUES (716, 1005.60000000000002);
INSERT INTO numericvalue VALUES (717, 1005.89999999999998);
INSERT INTO numericvalue VALUES (718, 1005.5);
INSERT INTO numericvalue VALUES (719, 1006);
INSERT INTO numericvalue VALUES (720, 1006.5);
INSERT INTO numericvalue VALUES (721, 1006.79999999999995);
INSERT INTO numericvalue VALUES (722, 1007.5);
INSERT INTO numericvalue VALUES (723, 1007.70000000000005);
INSERT INTO numericvalue VALUES (724, 1007.5);
INSERT INTO numericvalue VALUES (725, 1008.10000000000002);
INSERT INTO numericvalue VALUES (726, 1008.20000000000005);
INSERT INTO numericvalue VALUES (727, 1007.10000000000002);
INSERT INTO numericvalue VALUES (728, 1006.70000000000005);
INSERT INTO numericvalue VALUES (729, 1006);
INSERT INTO numericvalue VALUES (730, 1005.89999999999998);
INSERT INTO numericvalue VALUES (731, 1005.39999999999998);
INSERT INTO numericvalue VALUES (732, 1005.20000000000005);
INSERT INTO numericvalue VALUES (733, 1005);
INSERT INTO numericvalue VALUES (734, 1005.5);
INSERT INTO numericvalue VALUES (735, 1006.60000000000002);
INSERT INTO numericvalue VALUES (736, 1007);
INSERT INTO numericvalue VALUES (737, 1007.10000000000002);
INSERT INTO numericvalue VALUES (738, 1007.29999999999995);
INSERT INTO numericvalue VALUES (739, 1007.89999999999998);
INSERT INTO numericvalue VALUES (740, 1008.10000000000002);
INSERT INTO numericvalue VALUES (741, 1007.79999999999995);
INSERT INTO numericvalue VALUES (742, 1007.79999999999995);
INSERT INTO numericvalue VALUES (743, 1007.10000000000002);
INSERT INTO numericvalue VALUES (744, 1007);
INSERT INTO numericvalue VALUES (745, 1007.60000000000002);
INSERT INTO numericvalue VALUES (746, 1006.89999999999998);
INSERT INTO numericvalue VALUES (747, 1005.60000000000002);
INSERT INTO numericvalue VALUES (748, 1006.20000000000005);
INSERT INTO numericvalue VALUES (749, 1005.70000000000005);
INSERT INTO numericvalue VALUES (750, 1006.29999999999995);
INSERT INTO numericvalue VALUES (751, 1006.10000000000002);
INSERT INTO numericvalue VALUES (752, 1006.10000000000002);
INSERT INTO numericvalue VALUES (753, 1006.79999999999995);
INSERT INTO numericvalue VALUES (754, 1012.70000000000005);
INSERT INTO numericvalue VALUES (755, 1014.5);
INSERT INTO numericvalue VALUES (756, 1015.89999999999998);
INSERT INTO numericvalue VALUES (757, 1016.60000000000002);
INSERT INTO numericvalue VALUES (758, 1017.79999999999995);
INSERT INTO numericvalue VALUES (759, 1019.60000000000002);
INSERT INTO numericvalue VALUES (760, 1020.10000000000002);
INSERT INTO numericvalue VALUES (761, 1019.89999999999998);
INSERT INTO numericvalue VALUES (762, 1020.5);
INSERT INTO numericvalue VALUES (763, 1020.39999999999998);
INSERT INTO numericvalue VALUES (764, 1023.39999999999998);
INSERT INTO numericvalue VALUES (765, 1024.70000000000005);
INSERT INTO numericvalue VALUES (766, 1024.90000000000009);
INSERT INTO numericvalue VALUES (767, 1025.09999999999991);
INSERT INTO numericvalue VALUES (768, 1024.29999999999995);
INSERT INTO numericvalue VALUES (769, 1024.70000000000005);
INSERT INTO numericvalue VALUES (770, 1023.70000000000005);
INSERT INTO numericvalue VALUES (771, 1024.20000000000005);
INSERT INTO numericvalue VALUES (772, 1022.5);
INSERT INTO numericvalue VALUES (773, 1022.29999999999995);
INSERT INTO numericvalue VALUES (774, 1027.5);
INSERT INTO numericvalue VALUES (775, 1027.70000000000005);
INSERT INTO numericvalue VALUES (776, 1026.09999999999991);
INSERT INTO numericvalue VALUES (777, 1025.70000000000005);
INSERT INTO numericvalue VALUES (778, 1025.79999999999995);
INSERT INTO numericvalue VALUES (779, 1025.29999999999995);
INSERT INTO numericvalue VALUES (780, 1025.70000000000005);
INSERT INTO numericvalue VALUES (781, 1024.79999999999995);
INSERT INTO numericvalue VALUES (782, 1024.20000000000005);
INSERT INTO numericvalue VALUES (783, 1023.39999999999998);
INSERT INTO numericvalue VALUES (784, 1025);
INSERT INTO numericvalue VALUES (785, 1024.09999999999991);
INSERT INTO numericvalue VALUES (786, 1023.29999999999995);
INSERT INTO numericvalue VALUES (787, 1023.10000000000002);
INSERT INTO numericvalue VALUES (788, 1023.79999999999995);
INSERT INTO numericvalue VALUES (789, 1023.79999999999995);
INSERT INTO numericvalue VALUES (790, 1023.29999999999995);
INSERT INTO numericvalue VALUES (791, 1022.20000000000005);
INSERT INTO numericvalue VALUES (792, 1021.89999999999998);
INSERT INTO numericvalue VALUES (793, 1022.5);
INSERT INTO numericvalue VALUES (794, 1022);
INSERT INTO numericvalue VALUES (795, 1020.89999999999998);
INSERT INTO numericvalue VALUES (796, 1020.29999999999995);
INSERT INTO numericvalue VALUES (797, 1019.70000000000005);
INSERT INTO numericvalue VALUES (798, 1019.60000000000002);
INSERT INTO numericvalue VALUES (799, 1018.70000000000005);
INSERT INTO numericvalue VALUES (800, 1017.5);


--
-- TOC entry 3974 (class 0 OID 20600)
-- Dependencies: 217
-- Data for Name: observableproperty; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO observableproperty VALUES (1, 'F', 'AirTemperature', 1, NULL, 1, NULL, 'F');
INSERT INTO observableproperty VALUES (2, 'F', 'AthmosphericPressure', 1, NULL, 1, NULL, 'F');
INSERT INTO observableproperty VALUES (3, 'F', 'Humidity', 1, NULL, 1, NULL, 'F');
INSERT INTO observableproperty VALUES (4, 'F', 'InSystemTemperature', 1, NULL, 1, NULL, 'F');


--
-- TOC entry 4180 (class 0 OID 0)
-- Dependencies: 241
-- Name: observablepropertyid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observablepropertyid_seq', 4, true);


--
-- TOC entry 3975 (class 0 OID 20610)
-- Dependencies: 218
-- Data for Name: observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO observation VALUES (1, 1, '2016-10-01 06:31:54', '2016-10-01 06:31:54', '2016-10-01 06:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (2, 1, '2016-10-01 07:16:54', '2016-10-01 07:16:54', '2016-10-01 07:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (3, 1, '2016-10-01 11:16:54', '2016-10-01 11:16:54', '2016-10-01 11:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (4, 1, '2016-10-01 13:46:53', '2016-10-01 13:46:53', '2016-10-01 13:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (5, 1, '2016-10-01 16:01:53', '2016-10-01 16:01:53', '2016-10-01 16:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (6, 1, '2016-10-01 18:46:53', '2016-10-01 18:46:53', '2016-10-01 18:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (7, 1, '2016-10-01 20:31:52', '2016-10-01 20:31:52', '2016-10-01 20:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (8, 1, '2016-10-01 22:01:52', '2016-10-01 22:01:52', '2016-10-01 22:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (9, 1, '2016-10-02 00:16:52', '2016-10-02 00:16:52', '2016-10-02 00:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (10, 1, '2016-10-02 05:01:52', '2016-10-02 05:01:52', '2016-10-02 05:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (11, 1, '2016-10-02 06:31:48', '2016-10-02 06:31:48', '2016-10-02 06:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (12, 1, '2016-10-02 09:01:48', '2016-10-02 09:01:48', '2016-10-02 09:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (13, 1, '2016-10-02 11:01:48', '2016-10-02 11:01:48', '2016-10-02 11:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (14, 1, '2016-10-03 06:46:52', '2016-10-03 06:46:52', '2016-10-03 06:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (15, 1, '2016-10-03 11:31:52', '2016-10-03 11:31:52', '2016-10-03 11:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (16, 1, '2016-10-03 13:31:52', '2016-10-03 13:31:52', '2016-10-03 13:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (17, 1, '2016-10-03 15:46:51', '2016-10-03 15:46:51', '2016-10-03 15:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (18, 1, '2016-10-03 16:46:51', '2016-10-03 16:46:51', '2016-10-03 16:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (19, 1, '2016-10-03 20:31:51', '2016-10-03 20:31:51', '2016-10-03 20:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (20, 1, '2016-10-03 22:46:51', '2016-10-03 22:46:51', '2016-10-03 22:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (21, 1, '2016-10-04 00:31:50', '2016-10-04 00:31:50', '2016-10-04 00:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (22, 1, '2016-10-04 05:01:50', '2016-10-04 05:01:50', '2016-10-04 05:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (23, 1, '2016-10-05 06:31:53', '2016-10-05 06:31:53', '2016-10-05 06:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (24, 1, '2016-10-05 10:01:53', '2016-10-05 10:01:53', '2016-10-05 10:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (25, 1, '2016-10-05 11:46:53', '2016-10-05 11:46:53', '2016-10-05 11:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (26, 1, '2016-10-05 13:31:53', '2016-10-05 13:31:53', '2016-10-05 13:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (27, 1, '2016-10-05 16:16:52', '2016-10-05 16:16:52', '2016-10-05 16:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (28, 1, '2016-10-05 19:16:52', '2016-10-05 19:16:52', '2016-10-05 19:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (29, 1, '2016-10-05 22:16:52', '2016-10-05 22:16:52', '2016-10-05 22:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (30, 1, '2016-10-05 23:16:52', '2016-10-05 23:16:52', '2016-10-05 23:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (31, 1, '2016-10-06 03:31:51', '2016-10-06 03:31:51', '2016-10-06 03:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (32, 1, '2016-10-06 05:16:51', '2016-10-06 05:16:51', '2016-10-06 05:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (33, 1, '2016-10-06 09:01:50', '2016-10-06 09:01:50', '2016-10-06 09:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (34, 1, '2016-10-06 10:46:49', '2016-10-06 10:46:49', '2016-10-06 10:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (35, 1, '2016-10-06 13:16:49', '2016-10-06 13:16:49', '2016-10-06 13:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (36, 1, '2016-10-06 15:32:01', '2016-10-06 15:32:01', '2016-10-06 15:32:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (37, 1, '2016-10-06 17:17:01', '2016-10-06 17:17:01', '2016-10-06 17:17:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (38, 1, '2016-10-06 19:17:00', '2016-10-06 19:17:00', '2016-10-06 19:17:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (39, 1, '2016-10-06 23:32:00', '2016-10-06 23:32:00', '2016-10-06 23:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (40, 1, '2016-10-07 00:47:00', '2016-10-07 00:47:00', '2016-10-07 00:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (41, 1, '2016-10-07 02:47:00', '2016-10-07 02:47:00', '2016-10-07 02:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (42, 1, '2016-10-07 07:46:47', '2016-10-07 07:46:47', '2016-10-07 07:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (43, 1, '2016-10-07 10:01:47', '2016-10-07 10:01:47', '2016-10-07 10:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (44, 1, '2016-10-07 12:16:46', '2016-10-07 12:16:46', '2016-10-07 12:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (45, 1, '2016-10-07 14:01:46', '2016-10-07 14:01:46', '2016-10-07 14:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (46, 1, '2016-10-07 16:16:46', '2016-10-07 16:16:46', '2016-10-07 16:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (47, 1, '2016-10-07 18:46:46', '2016-10-07 18:46:46', '2016-10-07 18:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (48, 1, '2016-10-07 22:31:45', '2016-10-07 22:31:45', '2016-10-07 22:31:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (49, 1, '2016-10-08 01:31:45', '2016-10-08 01:31:45', '2016-10-08 01:31:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (50, 1, '2016-10-08 04:01:45', '2016-10-08 04:01:45', '2016-10-08 04:01:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (51, 1, '2016-10-08 06:16:50', '2016-10-08 06:16:50', '2016-10-08 06:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (52, 1, '2016-10-08 07:46:50', '2016-10-08 07:46:50', '2016-10-08 07:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (53, 1, '2016-10-08 10:31:50', '2016-10-08 10:31:50', '2016-10-08 10:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (54, 1, '2016-10-08 14:16:49', '2016-10-08 14:16:49', '2016-10-08 14:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (55, 1, '2016-10-08 15:01:49', '2016-10-08 15:01:49', '2016-10-08 15:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (56, 1, '2016-10-08 17:16:49', '2016-10-08 17:16:49', '2016-10-08 17:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (57, 1, '2016-10-08 21:16:48', '2016-10-08 21:16:48', '2016-10-08 21:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (58, 1, '2016-10-08 22:31:48', '2016-10-08 22:31:48', '2016-10-08 22:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (59, 1, '2016-10-09 00:46:48', '2016-10-09 00:46:48', '2016-10-09 00:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (60, 1, '2016-10-09 05:16:48', '2016-10-09 05:16:48', '2016-10-09 05:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (61, 1, '2016-10-09 06:31:51', '2016-10-09 06:31:51', '2016-10-09 06:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (62, 1, '2016-10-10 07:46:52', '2016-10-10 07:46:52', '2016-10-10 07:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (63, 1, '2016-10-10 11:01:51', '2016-10-10 11:01:51', '2016-10-10 11:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (64, 1, '2016-10-10 13:31:51', '2016-10-10 13:31:51', '2016-10-10 13:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (65, 1, '2016-10-10 14:46:51', '2016-10-10 14:46:51', '2016-10-10 14:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (66, 1, '2016-10-10 18:31:51', '2016-10-10 18:31:51', '2016-10-10 18:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (67, 1, '2016-10-10 21:16:50', '2016-10-10 21:16:50', '2016-10-10 21:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (68, 1, '2016-10-11 00:16:50', '2016-10-11 00:16:50', '2016-10-11 00:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (69, 1, '2016-10-11 03:16:50', '2016-10-11 03:16:50', '2016-10-11 03:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (70, 1, '2016-10-11 05:46:50', '2016-10-11 05:46:50', '2016-10-11 05:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (71, 1, '2016-10-11 06:46:49', '2016-10-11 06:46:49', '2016-10-11 06:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (72, 1, '2016-10-12 09:01:54', '2016-10-12 09:01:54', '2016-10-12 09:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (73, 1, '2016-10-13 07:16:51', '2016-10-13 07:16:51', '2016-10-13 07:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (74, 1, '2016-10-13 10:46:51', '2016-10-13 10:46:51', '2016-10-13 10:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (75, 1, '2016-10-13 13:32:03', '2016-10-13 13:32:03', '2016-10-13 13:32:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (76, 1, '2016-10-13 16:02:03', '2016-10-13 16:02:03', '2016-10-13 16:02:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (77, 1, '2016-10-13 17:32:03', '2016-10-13 17:32:03', '2016-10-13 17:32:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (78, 1, '2016-10-13 21:17:03', '2016-10-13 21:17:03', '2016-10-13 21:17:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (79, 1, '2016-10-13 23:02:03', '2016-10-13 23:02:03', '2016-10-13 23:02:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (80, 1, '2016-10-14 00:47:03', '2016-10-14 00:47:03', '2016-10-14 00:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (81, 1, '2016-10-14 04:02:02', '2016-10-14 04:02:02', '2016-10-14 04:02:02', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (82, 1, '2016-10-14 07:31:49', '2016-10-14 07:31:49', '2016-10-14 07:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (83, 1, '2016-10-14 09:31:49', '2016-10-14 09:31:49', '2016-10-14 09:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (84, 1, '2016-10-14 11:16:49', '2016-10-14 11:16:49', '2016-10-14 11:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (85, 1, '2016-10-14 15:16:48', '2016-10-14 15:16:48', '2016-10-14 15:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (86, 1, '2016-10-14 18:01:48', '2016-10-14 18:01:48', '2016-10-14 18:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (87, 1, '2016-10-15 06:31:52', '2016-10-15 06:31:52', '2016-10-15 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (88, 1, '2016-10-15 10:31:52', '2016-10-15 10:31:52', '2016-10-15 10:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (89, 1, '2016-10-15 13:01:52', '2016-10-15 13:01:52', '2016-10-15 13:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (90, 1, '2016-10-15 16:01:51', '2016-10-15 16:01:51', '2016-10-15 16:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (91, 1, '2016-10-15 16:46:51', '2016-10-15 16:46:51', '2016-10-15 16:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (92, 1, '2016-10-15 19:46:51', '2016-10-15 19:46:51', '2016-10-15 19:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (93, 1, '2016-10-15 21:01:51', '2016-10-15 21:01:51', '2016-10-15 21:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (94, 1, '2016-10-15 23:46:51', '2016-10-15 23:46:51', '2016-10-15 23:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (95, 1, '2016-10-16 03:01:51', '2016-10-16 03:01:51', '2016-10-16 03:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (96, 1, '2016-10-16 06:46:48', '2016-10-16 06:46:48', '2016-10-16 06:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (97, 1, '2016-10-16 08:46:48', '2016-10-16 08:46:48', '2016-10-16 08:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (98, 1, '2016-10-16 11:01:48', '2016-10-16 11:01:48', '2016-10-16 11:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (99, 1, '2016-10-16 14:01:47', '2016-10-16 14:01:47', '2016-10-16 14:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (100, 1, '2016-10-16 15:46:47', '2016-10-16 15:46:47', '2016-10-16 15:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (101, 1, '2016-10-16 18:31:47', '2016-10-16 18:31:47', '2016-10-16 18:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (102, 1, '2016-10-16 21:16:47', '2016-10-16 21:16:47', '2016-10-16 21:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (103, 1, '2016-10-17 01:01:46', '2016-10-17 01:01:46', '2016-10-17 01:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (104, 1, '2016-10-17 01:46:46', '2016-10-17 01:46:46', '2016-10-17 01:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (105, 1, '2016-10-17 06:16:46', '2016-10-17 06:16:46', '2016-10-17 06:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (106, 1, '2016-10-18 06:31:55', '2016-10-18 06:31:55', '2016-10-18 06:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (107, 1, '2016-10-18 09:31:55', '2016-10-18 09:31:55', '2016-10-18 09:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (108, 1, '2016-10-18 12:16:55', '2016-10-18 12:16:55', '2016-10-18 12:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (109, 1, '2016-10-18 13:16:55', '2016-10-18 13:16:55', '2016-10-18 13:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (110, 1, '2016-10-18 16:31:54', '2016-10-18 16:31:54', '2016-10-18 16:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (111, 1, '2016-10-18 18:01:54', '2016-10-18 18:01:54', '2016-10-18 18:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (112, 1, '2016-10-18 22:01:54', '2016-10-18 22:01:54', '2016-10-18 22:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (113, 1, '2016-10-19 01:16:54', '2016-10-19 01:16:54', '2016-10-19 01:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (114, 1, '2016-10-19 02:31:54', '2016-10-19 02:31:54', '2016-10-19 02:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (115, 1, '2016-10-19 06:46:48', '2016-10-19 06:46:48', '2016-10-19 06:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (116, 1, '2016-10-20 06:46:52', '2016-10-20 06:46:52', '2016-10-20 06:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (117, 1, '2016-10-20 11:16:52', '2016-10-20 11:16:52', '2016-10-20 11:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (118, 1, '2016-10-20 12:31:52', '2016-10-20 12:31:52', '2016-10-20 12:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (119, 1, '2016-10-20 14:32:00', '2016-10-20 14:32:00', '2016-10-20 14:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (120, 1, '2016-10-20 16:32:00', '2016-10-20 16:32:00', '2016-10-20 16:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (121, 1, '2016-10-20 20:17:00', '2016-10-20 20:17:00', '2016-10-20 20:17:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (122, 1, '2016-10-20 22:02:00', '2016-10-20 22:02:00', '2016-10-20 22:02:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (123, 1, '2016-10-21 02:16:59', '2016-10-21 02:16:59', '2016-10-21 02:16:59', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (124, 1, '2016-10-21 05:01:59', '2016-10-21 05:01:59', '2016-10-21 05:01:59', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (125, 1, '2016-10-21 06:31:50', '2016-10-21 06:31:50', '2016-10-21 06:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (126, 1, '2016-10-21 09:01:50', '2016-10-21 09:01:50', '2016-10-21 09:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (127, 1, '2016-10-21 12:31:50', '2016-10-21 12:31:50', '2016-10-21 12:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (128, 1, '2016-10-21 15:01:50', '2016-10-21 15:01:50', '2016-10-21 15:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (129, 1, '2016-10-21 16:46:50', '2016-10-21 16:46:50', '2016-10-21 16:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (130, 1, '2016-10-21 19:31:49', '2016-10-21 19:31:49', '2016-10-21 19:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (131, 1, '2016-10-21 20:31:49', '2016-10-21 20:31:49', '2016-10-21 20:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (132, 1, '2016-10-21 23:46:49', '2016-10-21 23:46:49', '2016-10-21 23:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (133, 1, '2016-10-22 02:31:49', '2016-10-22 02:31:49', '2016-10-22 02:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (134, 1, '2016-10-22 05:46:49', '2016-10-22 05:46:49', '2016-10-22 05:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (135, 1, '2016-10-22 08:46:49', '2016-10-22 08:46:49', '2016-10-22 08:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (136, 1, '2016-10-22 11:01:49', '2016-10-22 11:01:49', '2016-10-22 11:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (137, 1, '2016-10-22 13:31:49', '2016-10-22 13:31:49', '2016-10-22 13:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (138, 1, '2016-10-22 14:16:49', '2016-10-22 14:16:49', '2016-10-22 14:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (139, 1, '2016-10-22 18:31:48', '2016-10-22 18:31:48', '2016-10-22 18:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (140, 1, '2016-10-22 21:01:48', '2016-10-22 21:01:48', '2016-10-22 21:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (141, 1, '2016-10-22 23:31:48', '2016-10-22 23:31:48', '2016-10-22 23:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (142, 1, '2016-10-23 01:16:48', '2016-10-23 01:16:48', '2016-10-23 01:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (143, 1, '2016-10-23 03:46:48', '2016-10-23 03:46:48', '2016-10-23 03:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (144, 1, '2016-10-23 07:16:47', '2016-10-23 07:16:47', '2016-10-23 07:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (145, 1, '2016-10-23 10:16:47', '2016-10-23 10:16:47', '2016-10-23 10:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (146, 1, '2016-10-23 12:31:47', '2016-10-23 12:31:47', '2016-10-23 12:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (147, 1, '2016-10-23 14:31:47', '2016-10-23 14:31:47', '2016-10-23 14:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (148, 1, '2016-10-23 17:46:46', '2016-10-23 17:46:46', '2016-10-23 17:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (149, 1, '2016-10-23 19:16:46', '2016-10-23 19:16:46', '2016-10-23 19:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (150, 1, '2016-10-23 22:46:46', '2016-10-23 22:46:46', '2016-10-23 22:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (151, 1, '2016-10-23 23:46:46', '2016-10-23 23:46:46', '2016-10-23 23:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (152, 1, '2016-10-24 04:01:46', '2016-10-24 04:01:46', '2016-10-24 04:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (153, 1, '2016-10-24 06:46:48', '2016-10-24 06:46:48', '2016-10-24 06:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (154, 1, '2016-10-24 08:16:48', '2016-10-24 08:16:48', '2016-10-24 08:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (155, 1, '2016-10-25 09:31:55', '2016-10-25 09:31:55', '2016-10-25 09:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (156, 1, '2016-10-25 10:46:55', '2016-10-25 10:46:55', '2016-10-25 10:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (157, 1, '2016-10-25 14:46:55', '2016-10-25 14:46:55', '2016-10-25 14:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (158, 1, '2016-10-25 15:16:55', '2016-10-25 15:16:55', '2016-10-25 15:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (159, 1, '2016-10-25 18:31:54', '2016-10-25 18:31:54', '2016-10-25 18:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (160, 1, '2016-10-25 21:01:54', '2016-10-25 21:01:54', '2016-10-25 21:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (161, 1, '2016-10-26 00:31:54', '2016-10-26 00:31:54', '2016-10-26 00:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (162, 1, '2016-10-26 01:46:54', '2016-10-26 01:46:54', '2016-10-26 01:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (163, 1, '2016-10-26 05:31:53', '2016-10-26 05:31:53', '2016-10-26 05:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (164, 1, '2016-10-27 06:46:56', '2016-10-27 06:46:56', '2016-10-27 06:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (165, 1, '2016-10-27 08:31:56', '2016-10-27 08:31:56', '2016-10-27 08:31:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (166, 1, '2016-10-27 12:16:56', '2016-10-27 12:16:56', '2016-10-27 12:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (167, 1, '2016-10-27 12:46:56', '2016-10-27 12:46:56', '2016-10-27 12:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (168, 1, '2016-10-27 16:17:05', '2016-10-27 16:17:05', '2016-10-27 16:17:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (169, 1, '2016-10-27 20:02:04', '2016-10-27 20:02:04', '2016-10-27 20:02:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (170, 1, '2016-10-27 21:32:04', '2016-10-27 21:32:04', '2016-10-27 21:32:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (171, 1, '2016-10-27 22:47:04', '2016-10-27 22:47:04', '2016-10-27 22:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (172, 1, '2016-10-28 03:47:04', '2016-10-28 03:47:04', '2016-10-28 03:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (173, 1, '2016-10-29 06:31:57', '2016-10-29 06:31:57', '2016-10-29 06:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (174, 1, '2016-10-29 08:16:57', '2016-10-29 08:16:57', '2016-10-29 08:16:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (175, 1, '2016-10-29 11:31:57', '2016-10-29 11:31:57', '2016-10-29 11:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (176, 1, '2016-10-29 11:46:57', '2016-10-29 11:46:57', '2016-10-29 11:46:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (177, 1, '2016-10-29 14:31:57', '2016-10-29 14:31:57', '2016-10-29 14:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (178, 1, '2016-10-29 19:01:56', '2016-10-29 19:01:56', '2016-10-29 19:01:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (179, 1, '2016-10-29 20:46:56', '2016-10-29 20:46:56', '2016-10-29 20:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (180, 1, '2016-10-29 23:16:56', '2016-10-29 23:16:56', '2016-10-29 23:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (181, 1, '2016-10-30 01:31:56', '2016-10-30 01:31:56', '2016-10-30 01:31:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (182, 1, '2016-10-30 03:31:56', '2016-10-30 03:31:56', '2016-10-30 03:31:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (183, 1, '2016-10-30 07:01:51', '2016-10-30 07:01:51', '2016-10-30 07:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (184, 1, '2016-10-30 08:46:51', '2016-10-30 08:46:51', '2016-10-30 08:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (185, 1, '2016-10-30 12:46:51', '2016-10-30 12:46:51', '2016-10-30 12:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (186, 1, '2016-10-30 13:01:51', '2016-10-30 13:01:51', '2016-10-30 13:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (187, 1, '2016-10-30 15:31:51', '2016-10-30 15:31:51', '2016-10-30 15:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (188, 1, '2016-10-30 18:01:50', '2016-10-30 18:01:50', '2016-10-30 18:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (189, 1, '2016-10-30 21:31:50', '2016-10-30 21:31:50', '2016-10-30 21:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (190, 1, '2016-10-30 23:01:50', '2016-10-30 23:01:50', '2016-10-30 23:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (191, 1, '2016-10-31 02:16:50', '2016-10-31 02:16:50', '2016-10-31 02:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (192, 1, '2016-10-31 06:31:52', '2016-10-31 06:31:52', '2016-10-31 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (193, 1, '2016-10-31 08:46:52', '2016-10-31 08:46:52', '2016-10-31 08:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (194, 1, '2016-10-31 11:46:52', '2016-10-31 11:46:52', '2016-10-31 11:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (195, 1, '2016-10-31 13:01:52', '2016-10-31 13:01:52', '2016-10-31 13:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (196, 1, '2016-10-31 16:01:51', '2016-10-31 16:01:51', '2016-10-31 16:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (197, 1, '2016-10-31 17:31:51', '2016-10-31 17:31:51', '2016-10-31 17:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (198, 1, '2016-10-31 20:31:51', '2016-10-31 20:31:51', '2016-10-31 20:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (199, 1, '2016-10-31 23:16:51', '2016-10-31 23:16:51', '2016-10-31 23:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (200, 1, '2016-11-01 00:46:51', '2016-11-01 00:46:51', '2016-11-01 00:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (201, 2, '2016-10-01 06:31:54', '2016-10-01 06:31:54', '2016-10-01 06:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (202, 2, '2016-10-01 07:16:54', '2016-10-01 07:16:54', '2016-10-01 07:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (203, 2, '2016-10-01 11:16:54', '2016-10-01 11:16:54', '2016-10-01 11:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (204, 2, '2016-10-01 12:01:53', '2016-10-01 12:01:53', '2016-10-01 12:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (205, 2, '2016-10-01 16:01:53', '2016-10-01 16:01:53', '2016-10-01 16:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (206, 2, '2016-10-01 18:46:53', '2016-10-01 18:46:53', '2016-10-01 18:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (207, 2, '2016-10-01 20:31:52', '2016-10-01 20:31:52', '2016-10-01 20:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (208, 2, '2016-10-01 22:16:52', '2016-10-01 22:16:52', '2016-10-01 22:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (209, 2, '2016-10-02 01:01:52', '2016-10-02 01:01:52', '2016-10-02 01:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (210, 2, '2016-10-02 05:01:52', '2016-10-02 05:01:52', '2016-10-02 05:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (211, 2, '2016-10-02 06:31:48', '2016-10-02 06:31:48', '2016-10-02 06:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (212, 2, '2016-10-02 09:01:48', '2016-10-02 09:01:48', '2016-10-02 09:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (213, 2, '2016-10-02 11:01:48', '2016-10-02 11:01:48', '2016-10-02 11:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (214, 2, '2016-10-03 06:46:52', '2016-10-03 06:46:52', '2016-10-03 06:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (215, 2, '2016-10-03 11:31:52', '2016-10-03 11:31:52', '2016-10-03 11:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (216, 2, '2016-10-03 13:31:52', '2016-10-03 13:31:52', '2016-10-03 13:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (217, 2, '2016-10-03 15:46:51', '2016-10-03 15:46:51', '2016-10-03 15:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (218, 2, '2016-10-03 17:01:51', '2016-10-03 17:01:51', '2016-10-03 17:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (219, 2, '2016-10-03 19:46:51', '2016-10-03 19:46:51', '2016-10-03 19:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (220, 2, '2016-10-03 22:46:51', '2016-10-03 22:46:51', '2016-10-03 22:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (221, 2, '2016-10-04 02:16:50', '2016-10-04 02:16:50', '2016-10-04 02:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (222, 2, '2016-10-04 05:01:50', '2016-10-04 05:01:50', '2016-10-04 05:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (223, 2, '2016-10-05 06:31:53', '2016-10-05 06:31:53', '2016-10-05 06:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (224, 2, '2016-10-05 10:01:53', '2016-10-05 10:01:53', '2016-10-05 10:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (225, 2, '2016-10-05 11:46:53', '2016-10-05 11:46:53', '2016-10-05 11:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (226, 2, '2016-10-05 13:31:53', '2016-10-05 13:31:53', '2016-10-05 13:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (227, 2, '2016-10-05 16:01:52', '2016-10-05 16:01:52', '2016-10-05 16:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (228, 2, '2016-10-05 19:16:52', '2016-10-05 19:16:52', '2016-10-05 19:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (229, 2, '2016-10-05 22:16:52', '2016-10-05 22:16:52', '2016-10-05 22:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (230, 2, '2016-10-05 23:31:52', '2016-10-05 23:31:52', '2016-10-05 23:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (231, 2, '2016-10-06 03:31:51', '2016-10-06 03:31:51', '2016-10-06 03:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (232, 2, '2016-10-06 04:46:51', '2016-10-06 04:46:51', '2016-10-06 04:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (233, 2, '2016-10-06 09:01:50', '2016-10-06 09:01:50', '2016-10-06 09:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (234, 2, '2016-10-06 11:16:49', '2016-10-06 11:16:49', '2016-10-06 11:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (235, 2, '2016-10-06 13:16:49', '2016-10-06 13:16:49', '2016-10-06 13:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (236, 2, '2016-10-06 15:17:01', '2016-10-06 15:17:01', '2016-10-06 15:17:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (237, 2, '2016-10-06 17:32:01', '2016-10-06 17:32:01', '2016-10-06 17:32:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (238, 2, '2016-10-06 19:17:00', '2016-10-06 19:17:00', '2016-10-06 19:17:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (239, 2, '2016-10-06 22:47:00', '2016-10-06 22:47:00', '2016-10-06 22:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (240, 2, '2016-10-07 00:32:00', '2016-10-07 00:32:00', '2016-10-07 00:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (241, 2, '2016-10-07 02:47:00', '2016-10-07 02:47:00', '2016-10-07 02:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (242, 2, '2016-10-07 07:46:47', '2016-10-07 07:46:47', '2016-10-07 07:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (243, 2, '2016-10-07 10:01:47', '2016-10-07 10:01:47', '2016-10-07 10:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (244, 2, '2016-10-07 12:01:46', '2016-10-07 12:01:46', '2016-10-07 12:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (245, 2, '2016-10-07 14:01:46', '2016-10-07 14:01:46', '2016-10-07 14:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (246, 2, '2016-10-07 15:31:46', '2016-10-07 15:31:46', '2016-10-07 15:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (247, 2, '2016-10-07 18:16:46', '2016-10-07 18:16:46', '2016-10-07 18:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (248, 2, '2016-10-07 22:16:45', '2016-10-07 22:16:45', '2016-10-07 22:16:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (249, 2, '2016-10-08 01:31:45', '2016-10-08 01:31:45', '2016-10-08 01:31:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (250, 2, '2016-10-08 04:01:45', '2016-10-08 04:01:45', '2016-10-08 04:01:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (251, 2, '2016-10-08 06:16:50', '2016-10-08 06:16:50', '2016-10-08 06:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (252, 2, '2016-10-08 09:01:50', '2016-10-08 09:01:50', '2016-10-08 09:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (253, 2, '2016-10-08 10:31:50', '2016-10-08 10:31:50', '2016-10-08 10:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (254, 2, '2016-10-08 14:16:49', '2016-10-08 14:16:49', '2016-10-08 14:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (255, 2, '2016-10-08 15:01:49', '2016-10-08 15:01:49', '2016-10-08 15:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (256, 2, '2016-10-08 17:01:49', '2016-10-08 17:01:49', '2016-10-08 17:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (257, 2, '2016-10-08 21:31:48', '2016-10-08 21:31:48', '2016-10-08 21:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (258, 2, '2016-10-08 22:46:48', '2016-10-08 22:46:48', '2016-10-08 22:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (259, 2, '2016-10-09 00:46:48', '2016-10-09 00:46:48', '2016-10-09 00:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (260, 2, '2016-10-09 05:16:48', '2016-10-09 05:16:48', '2016-10-09 05:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (261, 2, '2016-10-09 06:31:51', '2016-10-09 06:31:51', '2016-10-09 06:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (262, 2, '2016-10-10 07:31:52', '2016-10-10 07:31:52', '2016-10-10 07:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (263, 2, '2016-10-10 11:16:51', '2016-10-10 11:16:51', '2016-10-10 11:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (264, 2, '2016-10-10 13:31:51', '2016-10-10 13:31:51', '2016-10-10 13:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (265, 2, '2016-10-10 15:01:51', '2016-10-10 15:01:51', '2016-10-10 15:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (266, 2, '2016-10-10 18:31:51', '2016-10-10 18:31:51', '2016-10-10 18:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (267, 2, '2016-10-10 21:16:50', '2016-10-10 21:16:50', '2016-10-10 21:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (268, 2, '2016-10-11 00:16:50', '2016-10-11 00:16:50', '2016-10-11 00:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (269, 2, '2016-10-11 03:16:50', '2016-10-11 03:16:50', '2016-10-11 03:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (270, 2, '2016-10-11 05:46:50', '2016-10-11 05:46:50', '2016-10-11 05:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (271, 2, '2016-10-11 06:46:49', '2016-10-11 06:46:49', '2016-10-11 06:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (272, 2, '2016-10-12 09:31:54', '2016-10-12 09:31:54', '2016-10-12 09:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (273, 2, '2016-10-13 07:16:51', '2016-10-13 07:16:51', '2016-10-13 07:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (274, 2, '2016-10-13 11:01:51', '2016-10-13 11:01:51', '2016-10-13 11:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (275, 2, '2016-10-13 11:46:51', '2016-10-13 11:46:51', '2016-10-13 11:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (276, 2, '2016-10-13 15:47:03', '2016-10-13 15:47:03', '2016-10-13 15:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (277, 2, '2016-10-13 17:17:03', '2016-10-13 17:17:03', '2016-10-13 17:17:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (278, 2, '2016-10-13 20:17:03', '2016-10-13 20:17:03', '2016-10-13 20:17:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (279, 2, '2016-10-13 23:17:03', '2016-10-13 23:17:03', '2016-10-13 23:17:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (280, 2, '2016-10-14 00:47:03', '2016-10-14 00:47:03', '2016-10-14 00:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (281, 2, '2016-10-14 03:47:02', '2016-10-14 03:47:02', '2016-10-14 03:47:02', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (282, 2, '2016-10-14 07:46:49', '2016-10-14 07:46:49', '2016-10-14 07:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (283, 2, '2016-10-14 10:31:49', '2016-10-14 10:31:49', '2016-10-14 10:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (284, 2, '2016-10-14 11:16:49', '2016-10-14 11:16:49', '2016-10-14 11:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (285, 2, '2016-10-14 15:16:48', '2016-10-14 15:16:48', '2016-10-14 15:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (286, 2, '2016-10-14 18:01:48', '2016-10-14 18:01:48', '2016-10-14 18:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (287, 2, '2016-10-15 06:31:52', '2016-10-15 06:31:52', '2016-10-15 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (288, 2, '2016-10-15 10:31:52', '2016-10-15 10:31:52', '2016-10-15 10:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (289, 2, '2016-10-15 13:16:52', '2016-10-15 13:16:52', '2016-10-15 13:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (290, 2, '2016-10-15 16:01:51', '2016-10-15 16:01:51', '2016-10-15 16:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (291, 2, '2016-10-15 16:31:51', '2016-10-15 16:31:51', '2016-10-15 16:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (292, 2, '2016-10-15 19:46:51', '2016-10-15 19:46:51', '2016-10-15 19:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (293, 2, '2016-10-15 21:01:51', '2016-10-15 21:01:51', '2016-10-15 21:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (294, 2, '2016-10-15 23:46:51', '2016-10-15 23:46:51', '2016-10-15 23:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (295, 2, '2016-10-16 03:01:51', '2016-10-16 03:01:51', '2016-10-16 03:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (296, 2, '2016-10-16 07:01:48', '2016-10-16 07:01:48', '2016-10-16 07:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (297, 2, '2016-10-16 08:46:48', '2016-10-16 08:46:48', '2016-10-16 08:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (298, 2, '2016-10-16 10:46:48', '2016-10-16 10:46:48', '2016-10-16 10:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (299, 2, '2016-10-16 14:01:47', '2016-10-16 14:01:47', '2016-10-16 14:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (300, 2, '2016-10-16 16:01:47', '2016-10-16 16:01:47', '2016-10-16 16:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (301, 2, '2016-10-16 18:31:47', '2016-10-16 18:31:47', '2016-10-16 18:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (302, 2, '2016-10-16 21:31:47', '2016-10-16 21:31:47', '2016-10-16 21:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (303, 2, '2016-10-17 00:31:46', '2016-10-17 00:31:46', '2016-10-17 00:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (304, 2, '2016-10-17 02:01:46', '2016-10-17 02:01:46', '2016-10-17 02:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (305, 2, '2016-10-17 06:16:46', '2016-10-17 06:16:46', '2016-10-17 06:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (306, 2, '2016-10-18 06:31:55', '2016-10-18 06:31:55', '2016-10-18 06:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (307, 2, '2016-10-18 09:31:55', '2016-10-18 09:31:55', '2016-10-18 09:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (308, 2, '2016-10-18 12:16:55', '2016-10-18 12:16:55', '2016-10-18 12:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (309, 2, '2016-10-18 13:16:55', '2016-10-18 13:16:55', '2016-10-18 13:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (310, 2, '2016-10-18 16:31:54', '2016-10-18 16:31:54', '2016-10-18 16:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (311, 2, '2016-10-18 18:01:54', '2016-10-18 18:01:54', '2016-10-18 18:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (312, 2, '2016-10-18 21:46:54', '2016-10-18 21:46:54', '2016-10-18 21:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (313, 2, '2016-10-19 01:16:54', '2016-10-19 01:16:54', '2016-10-19 01:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (314, 2, '2016-10-19 02:31:54', '2016-10-19 02:31:54', '2016-10-19 02:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (315, 2, '2016-10-19 06:16:49', '2016-10-19 06:16:49', '2016-10-19 06:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (316, 2, '2016-10-20 06:31:52', '2016-10-20 06:31:52', '2016-10-20 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (317, 2, '2016-10-20 11:01:52', '2016-10-20 11:01:52', '2016-10-20 11:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (318, 2, '2016-10-20 12:31:52', '2016-10-20 12:31:52', '2016-10-20 12:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (319, 2, '2016-10-20 14:32:00', '2016-10-20 14:32:00', '2016-10-20 14:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (320, 2, '2016-10-20 17:47:00', '2016-10-20 17:47:00', '2016-10-20 17:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (321, 2, '2016-10-20 20:32:00', '2016-10-20 20:32:00', '2016-10-20 20:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (322, 2, '2016-10-20 21:32:00', '2016-10-20 21:32:00', '2016-10-20 21:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (323, 2, '2016-10-21 02:02:00', '2016-10-21 02:02:00', '2016-10-21 02:02:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (324, 2, '2016-10-21 02:46:59', '2016-10-21 02:46:59', '2016-10-21 02:46:59', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (325, 2, '2016-10-21 06:31:50', '2016-10-21 06:31:50', '2016-10-21 06:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (326, 2, '2016-10-21 08:01:50', '2016-10-21 08:01:50', '2016-10-21 08:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (327, 2, '2016-10-21 12:31:50', '2016-10-21 12:31:50', '2016-10-21 12:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (328, 2, '2016-10-21 14:16:50', '2016-10-21 14:16:50', '2016-10-21 14:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (329, 2, '2016-10-21 16:46:50', '2016-10-21 16:46:50', '2016-10-21 16:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (330, 2, '2016-10-21 19:01:49', '2016-10-21 19:01:49', '2016-10-21 19:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (331, 2, '2016-10-21 20:31:49', '2016-10-21 20:31:49', '2016-10-21 20:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (332, 2, '2016-10-21 23:46:49', '2016-10-21 23:46:49', '2016-10-21 23:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (333, 2, '2016-10-22 03:01:49', '2016-10-22 03:01:49', '2016-10-22 03:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (334, 2, '2016-10-22 05:46:49', '2016-10-22 05:46:49', '2016-10-22 05:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (335, 2, '2016-10-22 08:46:49', '2016-10-22 08:46:49', '2016-10-22 08:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (336, 2, '2016-10-22 11:01:49', '2016-10-22 11:01:49', '2016-10-22 11:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (337, 2, '2016-10-22 13:46:49', '2016-10-22 13:46:49', '2016-10-22 13:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (338, 2, '2016-10-22 14:16:49', '2016-10-22 14:16:49', '2016-10-22 14:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (339, 2, '2016-10-22 18:16:48', '2016-10-22 18:16:48', '2016-10-22 18:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (340, 2, '2016-10-22 21:01:48', '2016-10-22 21:01:48', '2016-10-22 21:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (341, 2, '2016-10-22 23:01:48', '2016-10-22 23:01:48', '2016-10-22 23:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (342, 2, '2016-10-23 01:16:48', '2016-10-23 01:16:48', '2016-10-23 01:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (343, 2, '2016-10-23 04:46:48', '2016-10-23 04:46:48', '2016-10-23 04:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (344, 2, '2016-10-23 07:16:47', '2016-10-23 07:16:47', '2016-10-23 07:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (345, 2, '2016-10-23 10:16:47', '2016-10-23 10:16:47', '2016-10-23 10:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (346, 2, '2016-10-23 12:46:47', '2016-10-23 12:46:47', '2016-10-23 12:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (347, 2, '2016-10-23 14:16:47', '2016-10-23 14:16:47', '2016-10-23 14:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (348, 2, '2016-10-23 17:46:46', '2016-10-23 17:46:46', '2016-10-23 17:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (349, 2, '2016-10-23 19:16:46', '2016-10-23 19:16:46', '2016-10-23 19:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (350, 2, '2016-10-23 22:46:46', '2016-10-23 22:46:46', '2016-10-23 22:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (351, 2, '2016-10-23 23:46:46', '2016-10-23 23:46:46', '2016-10-23 23:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (352, 2, '2016-10-24 04:01:46', '2016-10-24 04:01:46', '2016-10-24 04:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (353, 2, '2016-10-24 06:46:48', '2016-10-24 06:46:48', '2016-10-24 06:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (354, 2, '2016-10-24 08:16:48', '2016-10-24 08:16:48', '2016-10-24 08:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (355, 2, '2016-10-25 09:01:55', '2016-10-25 09:01:55', '2016-10-25 09:01:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (356, 2, '2016-10-25 11:16:55', '2016-10-25 11:16:55', '2016-10-25 11:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (357, 2, '2016-10-25 14:46:55', '2016-10-25 14:46:55', '2016-10-25 14:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (358, 2, '2016-10-25 15:31:54', '2016-10-25 15:31:54', '2016-10-25 15:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (359, 2, '2016-10-25 19:31:54', '2016-10-25 19:31:54', '2016-10-25 19:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (360, 2, '2016-10-25 20:01:54', '2016-10-25 20:01:54', '2016-10-25 20:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (361, 2, '2016-10-26 01:01:54', '2016-10-26 01:01:54', '2016-10-26 01:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (362, 2, '2016-10-26 01:46:54', '2016-10-26 01:46:54', '2016-10-26 01:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (363, 2, '2016-10-26 05:46:53', '2016-10-26 05:46:53', '2016-10-26 05:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (364, 2, '2016-10-27 06:31:56', '2016-10-27 06:31:56', '2016-10-27 06:31:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (365, 2, '2016-10-27 08:16:56', '2016-10-27 08:16:56', '2016-10-27 08:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (366, 2, '2016-10-27 12:16:56', '2016-10-27 12:16:56', '2016-10-27 12:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (367, 2, '2016-10-27 12:46:56', '2016-10-27 12:46:56', '2016-10-27 12:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (368, 2, '2016-10-27 16:02:05', '2016-10-27 16:02:05', '2016-10-27 16:02:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (369, 2, '2016-10-27 20:02:04', '2016-10-27 20:02:04', '2016-10-27 20:02:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (370, 2, '2016-10-27 21:32:04', '2016-10-27 21:32:04', '2016-10-27 21:32:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (371, 2, '2016-10-27 22:47:04', '2016-10-27 22:47:04', '2016-10-27 22:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (372, 2, '2016-10-28 03:47:04', '2016-10-28 03:47:04', '2016-10-28 03:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (373, 2, '2016-10-29 06:31:57', '2016-10-29 06:31:57', '2016-10-29 06:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (374, 2, '2016-10-29 08:46:57', '2016-10-29 08:46:57', '2016-10-29 08:46:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (375, 2, '2016-10-29 11:01:57', '2016-10-29 11:01:57', '2016-10-29 11:01:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (376, 2, '2016-10-29 13:31:57', '2016-10-29 13:31:57', '2016-10-29 13:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (377, 2, '2016-10-29 14:31:57', '2016-10-29 14:31:57', '2016-10-29 14:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (378, 2, '2016-10-29 17:16:56', '2016-10-29 17:16:56', '2016-10-29 17:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (379, 2, '2016-10-29 20:01:56', '2016-10-29 20:01:56', '2016-10-29 20:01:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (380, 2, '2016-10-29 21:46:56', '2016-10-29 21:46:56', '2016-10-29 21:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (381, 2, '2016-10-30 01:31:56', '2016-10-30 01:31:56', '2016-10-30 01:31:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (382, 2, '2016-10-30 03:31:56', '2016-10-30 03:31:56', '2016-10-30 03:31:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (383, 2, '2016-10-30 07:01:51', '2016-10-30 07:01:51', '2016-10-30 07:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (384, 2, '2016-10-30 08:46:51', '2016-10-30 08:46:51', '2016-10-30 08:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (385, 2, '2016-10-30 12:16:51', '2016-10-30 12:16:51', '2016-10-30 12:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (386, 2, '2016-10-30 15:16:51', '2016-10-30 15:16:51', '2016-10-30 15:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (387, 2, '2016-10-30 16:46:50', '2016-10-30 16:46:50', '2016-10-30 16:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (388, 2, '2016-10-30 19:31:50', '2016-10-30 19:31:50', '2016-10-30 19:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (389, 2, '2016-10-30 21:31:50', '2016-10-30 21:31:50', '2016-10-30 21:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (390, 2, '2016-10-30 23:01:50', '2016-10-30 23:01:50', '2016-10-30 23:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (391, 2, '2016-10-31 03:01:50', '2016-10-31 03:01:50', '2016-10-31 03:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (392, 2, '2016-10-31 06:46:52', '2016-10-31 06:46:52', '2016-10-31 06:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (393, 2, '2016-10-31 09:01:52', '2016-10-31 09:01:52', '2016-10-31 09:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (394, 2, '2016-10-31 11:46:52', '2016-10-31 11:46:52', '2016-10-31 11:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (395, 2, '2016-10-31 13:01:52', '2016-10-31 13:01:52', '2016-10-31 13:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (396, 2, '2016-10-31 16:01:51', '2016-10-31 16:01:51', '2016-10-31 16:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (397, 2, '2016-10-31 17:31:51', '2016-10-31 17:31:51', '2016-10-31 17:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (398, 2, '2016-10-31 20:31:51', '2016-10-31 20:31:51', '2016-10-31 20:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (399, 2, '2016-10-31 23:16:51', '2016-10-31 23:16:51', '2016-10-31 23:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (400, 2, '2016-11-01 00:46:51', '2016-11-01 00:46:51', '2016-11-01 00:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 1);
INSERT INTO observation VALUES (401, 3, '2016-10-01 06:31:54', '2016-10-01 06:31:54', '2016-10-01 06:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (402, 3, '2016-10-01 07:16:54', '2016-10-01 07:16:54', '2016-10-01 07:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (403, 3, '2016-10-01 10:16:54', '2016-10-01 10:16:54', '2016-10-01 10:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (404, 3, '2016-10-01 12:01:53', '2016-10-01 12:01:53', '2016-10-01 12:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (405, 3, '2016-10-01 16:01:53', '2016-10-01 16:01:53', '2016-10-01 16:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (406, 3, '2016-10-01 18:46:53', '2016-10-01 18:46:53', '2016-10-01 18:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (407, 3, '2016-10-01 20:16:52', '2016-10-01 20:16:52', '2016-10-01 20:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (408, 3, '2016-10-01 22:31:52', '2016-10-01 22:31:52', '2016-10-01 22:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (409, 3, '2016-10-02 02:01:52', '2016-10-02 02:01:52', '2016-10-02 02:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (410, 3, '2016-10-02 05:01:52', '2016-10-02 05:01:52', '2016-10-02 05:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (411, 3, '2016-10-02 07:16:48', '2016-10-02 07:16:48', '2016-10-02 07:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (412, 3, '2016-10-02 09:01:48', '2016-10-02 09:01:48', '2016-10-02 09:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (413, 3, '2016-10-02 11:01:48', '2016-10-02 11:01:48', '2016-10-02 11:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (414, 3, '2016-10-03 06:46:52', '2016-10-03 06:46:52', '2016-10-03 06:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (415, 3, '2016-10-03 09:16:52', '2016-10-03 09:16:52', '2016-10-03 09:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (416, 3, '2016-10-03 13:31:52', '2016-10-03 13:31:52', '2016-10-03 13:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (417, 3, '2016-10-03 15:31:51', '2016-10-03 15:31:51', '2016-10-03 15:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (418, 3, '2016-10-03 17:16:51', '2016-10-03 17:16:51', '2016-10-03 17:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (419, 3, '2016-10-03 19:46:51', '2016-10-03 19:46:51', '2016-10-03 19:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (420, 3, '2016-10-03 23:16:51', '2016-10-03 23:16:51', '2016-10-03 23:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (421, 3, '2016-10-04 02:01:50', '2016-10-04 02:01:50', '2016-10-04 02:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (422, 3, '2016-10-04 05:01:50', '2016-10-04 05:01:50', '2016-10-04 05:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (423, 3, '2016-10-05 06:31:53', '2016-10-05 06:31:53', '2016-10-05 06:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (424, 3, '2016-10-05 09:31:53', '2016-10-05 09:31:53', '2016-10-05 09:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (425, 3, '2016-10-05 11:46:53', '2016-10-05 11:46:53', '2016-10-05 11:46:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (426, 3, '2016-10-05 13:16:53', '2016-10-05 13:16:53', '2016-10-05 13:16:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (427, 3, '2016-10-05 15:46:52', '2016-10-05 15:46:52', '2016-10-05 15:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (428, 3, '2016-10-05 17:46:52', '2016-10-05 17:46:52', '2016-10-05 17:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (429, 3, '2016-10-05 20:46:52', '2016-10-05 20:46:52', '2016-10-05 20:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (430, 3, '2016-10-05 23:31:52', '2016-10-05 23:31:52', '2016-10-05 23:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (431, 3, '2016-10-06 03:46:51', '2016-10-06 03:46:51', '2016-10-06 03:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (432, 3, '2016-10-06 05:01:51', '2016-10-06 05:01:51', '2016-10-06 05:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (433, 3, '2016-10-06 07:31:50', '2016-10-06 07:31:50', '2016-10-06 07:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (434, 3, '2016-10-06 11:01:49', '2016-10-06 11:01:49', '2016-10-06 11:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (435, 3, '2016-10-06 13:32:01', '2016-10-06 13:32:01', '2016-10-06 13:32:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (436, 3, '2016-10-06 15:32:01', '2016-10-06 15:32:01', '2016-10-06 15:32:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (437, 3, '2016-10-06 17:17:01', '2016-10-06 17:17:01', '2016-10-06 17:17:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (438, 3, '2016-10-06 20:02:00', '2016-10-06 20:02:00', '2016-10-06 20:02:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (439, 3, '2016-10-06 23:17:00', '2016-10-06 23:17:00', '2016-10-06 23:17:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (440, 3, '2016-10-07 00:47:00', '2016-10-07 00:47:00', '2016-10-07 00:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (441, 3, '2016-10-07 02:47:00', '2016-10-07 02:47:00', '2016-10-07 02:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (442, 3, '2016-10-07 07:31:47', '2016-10-07 07:31:47', '2016-10-07 07:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (443, 3, '2016-10-07 10:01:47', '2016-10-07 10:01:47', '2016-10-07 10:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (444, 3, '2016-10-07 12:01:46', '2016-10-07 12:01:46', '2016-10-07 12:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (445, 3, '2016-10-07 14:46:46', '2016-10-07 14:46:46', '2016-10-07 14:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (446, 3, '2016-10-07 17:46:46', '2016-10-07 17:46:46', '2016-10-07 17:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (447, 3, '2016-10-07 19:31:46', '2016-10-07 19:31:46', '2016-10-07 19:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (448, 3, '2016-10-07 22:46:45', '2016-10-07 22:46:45', '2016-10-07 22:46:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (449, 3, '2016-10-07 23:46:45', '2016-10-07 23:46:45', '2016-10-07 23:46:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (450, 3, '2016-10-08 01:46:45', '2016-10-08 01:46:45', '2016-10-08 01:46:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (451, 3, '2016-10-08 06:16:50', '2016-10-08 06:16:50', '2016-10-08 06:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (452, 3, '2016-10-08 08:01:50', '2016-10-08 08:01:50', '2016-10-08 08:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (453, 3, '2016-10-08 10:16:50', '2016-10-08 10:16:50', '2016-10-08 10:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (454, 3, '2016-10-08 12:16:49', '2016-10-08 12:16:49', '2016-10-08 12:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (455, 3, '2016-10-08 15:46:49', '2016-10-08 15:46:49', '2016-10-08 15:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (456, 3, '2016-10-08 18:31:49', '2016-10-08 18:31:49', '2016-10-08 18:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (457, 3, '2016-10-08 21:16:48', '2016-10-08 21:16:48', '2016-10-08 21:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (458, 3, '2016-10-08 22:46:48', '2016-10-08 22:46:48', '2016-10-08 22:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (459, 3, '2016-10-09 00:46:48', '2016-10-09 00:46:48', '2016-10-09 00:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (460, 3, '2016-10-09 05:16:48', '2016-10-09 05:16:48', '2016-10-09 05:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (461, 3, '2016-10-10 06:31:52', '2016-10-10 06:31:52', '2016-10-10 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (462, 3, '2016-10-10 09:31:52', '2016-10-10 09:31:52', '2016-10-10 09:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (463, 3, '2016-10-10 12:01:51', '2016-10-10 12:01:51', '2016-10-10 12:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (464, 3, '2016-10-10 13:31:51', '2016-10-10 13:31:51', '2016-10-10 13:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (465, 3, '2016-10-10 15:46:51', '2016-10-10 15:46:51', '2016-10-10 15:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (466, 3, '2016-10-10 18:31:51', '2016-10-10 18:31:51', '2016-10-10 18:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (467, 3, '2016-10-10 21:16:50', '2016-10-10 21:16:50', '2016-10-10 21:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (468, 3, '2016-10-11 00:16:50', '2016-10-11 00:16:50', '2016-10-11 00:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (469, 3, '2016-10-11 01:31:50', '2016-10-11 01:31:50', '2016-10-11 01:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (470, 3, '2016-10-11 03:46:50', '2016-10-11 03:46:50', '2016-10-11 03:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (471, 3, '2016-10-12 07:31:54', '2016-10-12 07:31:54', '2016-10-12 07:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (472, 3, '2016-10-12 09:31:54', '2016-10-12 09:31:54', '2016-10-12 09:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (473, 3, '2016-10-13 07:16:51', '2016-10-13 07:16:51', '2016-10-13 07:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (474, 3, '2016-10-13 11:01:51', '2016-10-13 11:01:51', '2016-10-13 11:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (475, 3, '2016-10-13 13:47:03', '2016-10-13 13:47:03', '2016-10-13 13:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (476, 3, '2016-10-13 15:47:03', '2016-10-13 15:47:03', '2016-10-13 15:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (477, 3, '2016-10-13 16:47:03', '2016-10-13 16:47:03', '2016-10-13 16:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (478, 3, '2016-10-13 21:02:03', '2016-10-13 21:02:03', '2016-10-13 21:02:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (479, 3, '2016-10-13 23:02:03', '2016-10-13 23:02:03', '2016-10-13 23:02:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (480, 3, '2016-10-14 01:47:02', '2016-10-14 01:47:02', '2016-10-14 01:47:02', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (481, 3, '2016-10-14 04:17:02', '2016-10-14 04:17:02', '2016-10-14 04:17:02', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (482, 3, '2016-10-14 07:46:49', '2016-10-14 07:46:49', '2016-10-14 07:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (483, 3, '2016-10-14 10:31:49', '2016-10-14 10:31:49', '2016-10-14 10:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (484, 3, '2016-10-14 11:16:49', '2016-10-14 11:16:49', '2016-10-14 11:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (485, 3, '2016-10-14 14:31:48', '2016-10-14 14:31:48', '2016-10-14 14:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (486, 3, '2016-10-14 18:01:48', '2016-10-14 18:01:48', '2016-10-14 18:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (487, 3, '2016-10-15 08:16:52', '2016-10-15 08:16:52', '2016-10-15 08:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (488, 3, '2016-10-15 10:46:52', '2016-10-15 10:46:52', '2016-10-15 10:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (489, 3, '2016-10-15 13:01:52', '2016-10-15 13:01:52', '2016-10-15 13:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (490, 3, '2016-10-15 15:31:51', '2016-10-15 15:31:51', '2016-10-15 15:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (491, 3, '2016-10-15 17:46:51', '2016-10-15 17:46:51', '2016-10-15 17:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (492, 3, '2016-10-15 20:31:51', '2016-10-15 20:31:51', '2016-10-15 20:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (493, 3, '2016-10-15 21:16:51', '2016-10-15 21:16:51', '2016-10-15 21:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (494, 3, '2016-10-16 00:16:51', '2016-10-16 00:16:51', '2016-10-16 00:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (495, 3, '2016-10-16 02:46:51', '2016-10-16 02:46:51', '2016-10-16 02:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (496, 3, '2016-10-16 07:16:48', '2016-10-16 07:16:48', '2016-10-16 07:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (497, 3, '2016-10-16 08:46:48', '2016-10-16 08:46:48', '2016-10-16 08:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (498, 3, '2016-10-16 11:01:48', '2016-10-16 11:01:48', '2016-10-16 11:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (499, 3, '2016-10-16 14:01:47', '2016-10-16 14:01:47', '2016-10-16 14:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (500, 3, '2016-10-16 15:46:47', '2016-10-16 15:46:47', '2016-10-16 15:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (501, 3, '2016-10-16 18:16:47', '2016-10-16 18:16:47', '2016-10-16 18:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (502, 3, '2016-10-16 20:01:47', '2016-10-16 20:01:47', '2016-10-16 20:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (503, 3, '2016-10-17 00:16:47', '2016-10-17 00:16:47', '2016-10-17 00:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (504, 3, '2016-10-17 02:31:46', '2016-10-17 02:31:46', '2016-10-17 02:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (505, 3, '2016-10-17 06:16:46', '2016-10-17 06:16:46', '2016-10-17 06:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (506, 3, '2016-10-18 06:31:55', '2016-10-18 06:31:55', '2016-10-18 06:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (507, 3, '2016-10-18 08:16:55', '2016-10-18 08:16:55', '2016-10-18 08:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (508, 3, '2016-10-18 12:16:55', '2016-10-18 12:16:55', '2016-10-18 12:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (509, 3, '2016-10-18 13:31:55', '2016-10-18 13:31:55', '2016-10-18 13:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (510, 3, '2016-10-18 16:31:54', '2016-10-18 16:31:54', '2016-10-18 16:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (511, 3, '2016-10-18 18:31:54', '2016-10-18 18:31:54', '2016-10-18 18:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (512, 3, '2016-10-18 22:16:54', '2016-10-18 22:16:54', '2016-10-18 22:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (513, 3, '2016-10-19 01:31:54', '2016-10-19 01:31:54', '2016-10-19 01:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (514, 3, '2016-10-19 02:16:54', '2016-10-19 02:16:54', '2016-10-19 02:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (515, 3, '2016-10-19 04:16:54', '2016-10-19 04:16:54', '2016-10-19 04:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (516, 3, '2016-10-20 06:31:52', '2016-10-20 06:31:52', '2016-10-20 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (517, 3, '2016-10-20 11:01:52', '2016-10-20 11:01:52', '2016-10-20 11:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (518, 3, '2016-10-20 12:46:52', '2016-10-20 12:46:52', '2016-10-20 12:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (519, 3, '2016-10-20 14:32:00', '2016-10-20 14:32:00', '2016-10-20 14:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (520, 3, '2016-10-20 18:47:00', '2016-10-20 18:47:00', '2016-10-20 18:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (521, 3, '2016-10-20 20:17:00', '2016-10-20 20:17:00', '2016-10-20 20:17:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (522, 3, '2016-10-20 21:47:00', '2016-10-20 21:47:00', '2016-10-20 21:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (523, 3, '2016-10-21 02:02:00', '2016-10-21 02:02:00', '2016-10-21 02:02:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (524, 3, '2016-10-21 03:31:59', '2016-10-21 03:31:59', '2016-10-21 03:31:59', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (525, 3, '2016-10-21 06:31:50', '2016-10-21 06:31:50', '2016-10-21 06:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (526, 3, '2016-10-21 10:01:50', '2016-10-21 10:01:50', '2016-10-21 10:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (527, 3, '2016-10-21 12:31:50', '2016-10-21 12:31:50', '2016-10-21 12:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (528, 3, '2016-10-21 14:46:50', '2016-10-21 14:46:50', '2016-10-21 14:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (529, 3, '2016-10-21 16:01:50', '2016-10-21 16:01:50', '2016-10-21 16:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (530, 3, '2016-10-21 18:31:49', '2016-10-21 18:31:49', '2016-10-21 18:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (531, 3, '2016-10-21 22:01:49', '2016-10-21 22:01:49', '2016-10-21 22:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (532, 3, '2016-10-22 00:31:49', '2016-10-22 00:31:49', '2016-10-22 00:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (533, 3, '2016-10-22 02:16:49', '2016-10-22 02:16:49', '2016-10-22 02:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (534, 3, '2016-10-22 04:01:49', '2016-10-22 04:01:49', '2016-10-22 04:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (535, 3, '2016-10-22 09:01:49', '2016-10-22 09:01:49', '2016-10-22 09:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (536, 3, '2016-10-22 11:01:49', '2016-10-22 11:01:49', '2016-10-22 11:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (537, 3, '2016-10-22 13:46:49', '2016-10-22 13:46:49', '2016-10-22 13:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (538, 3, '2016-10-22 15:31:49', '2016-10-22 15:31:49', '2016-10-22 15:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (539, 3, '2016-10-22 17:16:48', '2016-10-22 17:16:48', '2016-10-22 17:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (540, 3, '2016-10-22 20:01:48', '2016-10-22 20:01:48', '2016-10-22 20:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (541, 3, '2016-10-22 21:46:48', '2016-10-22 21:46:48', '2016-10-22 21:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (542, 3, '2016-10-23 01:31:48', '2016-10-23 01:31:48', '2016-10-23 01:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (543, 3, '2016-10-23 03:16:48', '2016-10-23 03:16:48', '2016-10-23 03:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (544, 3, '2016-10-23 07:46:47', '2016-10-23 07:46:47', '2016-10-23 07:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (545, 3, '2016-10-23 10:31:47', '2016-10-23 10:31:47', '2016-10-23 10:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (546, 3, '2016-10-23 12:46:47', '2016-10-23 12:46:47', '2016-10-23 12:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (547, 3, '2016-10-23 15:01:47', '2016-10-23 15:01:47', '2016-10-23 15:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (548, 3, '2016-10-23 17:31:46', '2016-10-23 17:31:46', '2016-10-23 17:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (549, 3, '2016-10-23 19:16:46', '2016-10-23 19:16:46', '2016-10-23 19:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (550, 3, '2016-10-23 22:46:46', '2016-10-23 22:46:46', '2016-10-23 22:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (551, 3, '2016-10-24 01:01:46', '2016-10-24 01:01:46', '2016-10-24 01:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (552, 3, '2016-10-24 03:16:46', '2016-10-24 03:16:46', '2016-10-24 03:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (553, 3, '2016-10-24 06:46:48', '2016-10-24 06:46:48', '2016-10-24 06:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (554, 3, '2016-10-24 08:16:48', '2016-10-24 08:16:48', '2016-10-24 08:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (555, 3, '2016-10-25 07:46:55', '2016-10-25 07:46:55', '2016-10-25 07:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (556, 3, '2016-10-25 11:31:55', '2016-10-25 11:31:55', '2016-10-25 11:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (557, 3, '2016-10-25 14:01:55', '2016-10-25 14:01:55', '2016-10-25 14:01:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (558, 3, '2016-10-25 15:01:55', '2016-10-25 15:01:55', '2016-10-25 15:01:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (559, 3, '2016-10-25 18:16:54', '2016-10-25 18:16:54', '2016-10-25 18:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (560, 3, '2016-10-25 22:16:54', '2016-10-25 22:16:54', '2016-10-25 22:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (561, 3, '2016-10-25 23:16:54', '2016-10-25 23:16:54', '2016-10-25 23:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (562, 3, '2016-10-26 02:46:54', '2016-10-26 02:46:54', '2016-10-26 02:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (563, 3, '2016-10-26 06:16:50', '2016-10-26 06:16:50', '2016-10-26 06:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (564, 3, '2016-10-27 07:16:56', '2016-10-27 07:16:56', '2016-10-27 07:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (565, 3, '2016-10-27 08:46:56', '2016-10-27 08:46:56', '2016-10-27 08:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (566, 3, '2016-10-27 12:16:56', '2016-10-27 12:16:56', '2016-10-27 12:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (567, 3, '2016-10-27 13:47:05', '2016-10-27 13:47:05', '2016-10-27 13:47:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (568, 3, '2016-10-27 16:32:05', '2016-10-27 16:32:05', '2016-10-27 16:32:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (569, 3, '2016-10-27 19:02:05', '2016-10-27 19:02:05', '2016-10-27 19:02:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (570, 3, '2016-10-27 21:47:04', '2016-10-27 21:47:04', '2016-10-27 21:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (571, 3, '2016-10-27 22:47:04', '2016-10-27 22:47:04', '2016-10-27 22:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (572, 3, '2016-10-28 03:02:04', '2016-10-28 03:02:04', '2016-10-28 03:02:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (573, 3, '2016-10-28 05:47:04', '2016-10-28 05:47:04', '2016-10-28 05:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (574, 3, '2016-10-29 07:46:57', '2016-10-29 07:46:57', '2016-10-29 07:46:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (575, 3, '2016-10-29 11:01:57', '2016-10-29 11:01:57', '2016-10-29 11:01:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (576, 3, '2016-10-29 13:31:57', '2016-10-29 13:31:57', '2016-10-29 13:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (577, 3, '2016-10-29 14:31:57', '2016-10-29 14:31:57', '2016-10-29 14:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (578, 3, '2016-10-29 19:01:56', '2016-10-29 19:01:56', '2016-10-29 19:01:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (579, 3, '2016-10-29 20:01:56', '2016-10-29 20:01:56', '2016-10-29 20:01:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (580, 3, '2016-10-29 21:46:56', '2016-10-29 21:46:56', '2016-10-29 21:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (581, 3, '2016-10-30 01:46:56', '2016-10-30 01:46:56', '2016-10-30 01:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (582, 3, '2016-10-30 03:16:56', '2016-10-30 03:16:56', '2016-10-30 03:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (583, 3, '2016-10-30 07:46:51', '2016-10-30 07:46:51', '2016-10-30 07:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (584, 3, '2016-10-30 09:01:51', '2016-10-30 09:01:51', '2016-10-30 09:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (585, 3, '2016-10-30 12:16:51', '2016-10-30 12:16:51', '2016-10-30 12:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (586, 3, '2016-10-30 14:16:51', '2016-10-30 14:16:51', '2016-10-30 14:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (587, 3, '2016-10-30 17:16:50', '2016-10-30 17:16:50', '2016-10-30 17:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (588, 3, '2016-10-30 19:31:50', '2016-10-30 19:31:50', '2016-10-30 19:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (589, 3, '2016-10-30 21:31:50', '2016-10-30 21:31:50', '2016-10-30 21:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (590, 3, '2016-10-30 23:31:50', '2016-10-30 23:31:50', '2016-10-30 23:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (591, 3, '2016-10-31 03:46:49', '2016-10-31 03:46:49', '2016-10-31 03:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (592, 3, '2016-10-31 06:46:52', '2016-10-31 06:46:52', '2016-10-31 06:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (593, 3, '2016-10-31 09:16:52', '2016-10-31 09:16:52', '2016-10-31 09:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (594, 3, '2016-10-31 11:46:52', '2016-10-31 11:46:52', '2016-10-31 11:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (595, 3, '2016-10-31 13:01:52', '2016-10-31 13:01:52', '2016-10-31 13:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (596, 3, '2016-10-31 14:31:52', '2016-10-31 14:31:52', '2016-10-31 14:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (597, 3, '2016-10-31 17:31:51', '2016-10-31 17:31:51', '2016-10-31 17:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (598, 3, '2016-10-31 20:46:51', '2016-10-31 20:46:51', '2016-10-31 20:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (599, 3, '2016-10-31 22:01:51', '2016-10-31 22:01:51', '2016-10-31 22:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (600, 3, '2016-11-01 00:46:51', '2016-11-01 00:46:51', '2016-11-01 00:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 2);
INSERT INTO observation VALUES (601, 4, '2016-10-01 06:31:54', '2016-10-01 06:31:54', '2016-10-01 06:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (602, 4, '2016-10-01 07:01:54', '2016-10-01 07:01:54', '2016-10-01 07:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (603, 4, '2016-10-01 09:31:54', '2016-10-01 09:31:54', '2016-10-01 09:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (604, 4, '2016-10-01 13:16:53', '2016-10-01 13:16:53', '2016-10-01 13:16:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (605, 4, '2016-10-01 16:01:53', '2016-10-01 16:01:53', '2016-10-01 16:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (606, 4, '2016-10-01 17:31:53', '2016-10-01 17:31:53', '2016-10-01 17:31:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (607, 4, '2016-10-01 21:01:52', '2016-10-01 21:01:52', '2016-10-01 21:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (608, 4, '2016-10-01 23:16:52', '2016-10-01 23:16:52', '2016-10-01 23:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (609, 4, '2016-10-02 01:31:52', '2016-10-02 01:31:52', '2016-10-02 01:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (610, 4, '2016-10-02 03:16:52', '2016-10-02 03:16:52', '2016-10-02 03:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (611, 4, '2016-10-02 07:46:48', '2016-10-02 07:46:48', '2016-10-02 07:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (612, 4, '2016-10-02 09:46:48', '2016-10-02 09:46:48', '2016-10-02 09:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (613, 4, '2016-10-02 12:31:48', '2016-10-02 12:31:48', '2016-10-02 12:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (614, 4, '2016-10-03 07:01:52', '2016-10-03 07:01:52', '2016-10-03 07:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (615, 4, '2016-10-03 09:31:52', '2016-10-03 09:31:52', '2016-10-03 09:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (616, 4, '2016-10-03 12:31:52', '2016-10-03 12:31:52', '2016-10-03 12:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (617, 4, '2016-10-03 16:01:51', '2016-10-03 16:01:51', '2016-10-03 16:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (618, 4, '2016-10-03 17:46:51', '2016-10-03 17:46:51', '2016-10-03 17:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (619, 4, '2016-10-03 21:31:51', '2016-10-03 21:31:51', '2016-10-03 21:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (620, 4, '2016-10-03 23:46:50', '2016-10-03 23:46:50', '2016-10-03 23:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (621, 4, '2016-10-04 01:16:50', '2016-10-04 01:16:50', '2016-10-04 01:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (622, 4, '2016-10-04 04:46:50', '2016-10-04 04:46:50', '2016-10-04 04:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (623, 4, '2016-10-04 06:31:46', '2016-10-04 06:31:46', '2016-10-04 06:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (624, 4, '2016-10-05 09:16:53', '2016-10-05 09:16:53', '2016-10-05 09:16:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (625, 4, '2016-10-05 10:16:53', '2016-10-05 10:16:53', '2016-10-05 10:16:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (626, 4, '2016-10-05 13:01:53', '2016-10-05 13:01:53', '2016-10-05 13:01:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (627, 4, '2016-10-05 15:46:52', '2016-10-05 15:46:52', '2016-10-05 15:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (628, 4, '2016-10-05 19:16:52', '2016-10-05 19:16:52', '2016-10-05 19:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (629, 4, '2016-10-05 21:16:52', '2016-10-05 21:16:52', '2016-10-05 21:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (630, 4, '2016-10-06 01:01:51', '2016-10-06 01:01:51', '2016-10-06 01:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (631, 4, '2016-10-06 03:16:51', '2016-10-06 03:16:51', '2016-10-06 03:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (632, 4, '2016-10-06 05:31:51', '2016-10-06 05:31:51', '2016-10-06 05:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (633, 4, '2016-10-06 08:16:50', '2016-10-06 08:16:50', '2016-10-06 08:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (634, 4, '2016-10-06 11:31:49', '2016-10-06 11:31:49', '2016-10-06 11:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (635, 4, '2016-10-06 14:02:01', '2016-10-06 14:02:01', '2016-10-06 14:02:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (636, 4, '2016-10-06 14:47:01', '2016-10-06 14:47:01', '2016-10-06 14:47:01', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (637, 4, '2016-10-06 18:32:00', '2016-10-06 18:32:00', '2016-10-06 18:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (638, 4, '2016-10-06 19:32:00', '2016-10-06 19:32:00', '2016-10-06 19:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (639, 4, '2016-10-06 21:47:00', '2016-10-06 21:47:00', '2016-10-06 21:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (640, 4, '2016-10-07 01:32:00', '2016-10-07 01:32:00', '2016-10-07 01:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (641, 4, '2016-10-07 03:17:00', '2016-10-07 03:17:00', '2016-10-07 03:17:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (642, 4, '2016-10-07 06:16:47', '2016-10-07 06:16:47', '2016-10-07 06:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (643, 4, '2016-10-07 10:01:47', '2016-10-07 10:01:47', '2016-10-07 10:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (644, 4, '2016-10-07 11:46:46', '2016-10-07 11:46:46', '2016-10-07 11:46:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (645, 4, '2016-10-07 15:16:46', '2016-10-07 15:16:46', '2016-10-07 15:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (646, 4, '2016-10-07 16:31:46', '2016-10-07 16:31:46', '2016-10-07 16:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (647, 4, '2016-10-07 19:16:46', '2016-10-07 19:16:46', '2016-10-07 19:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (648, 4, '2016-10-07 22:46:45', '2016-10-07 22:46:45', '2016-10-07 22:46:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (649, 4, '2016-10-08 01:31:45', '2016-10-08 01:31:45', '2016-10-08 01:31:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (650, 4, '2016-10-08 03:31:45', '2016-10-08 03:31:45', '2016-10-08 03:31:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (651, 4, '2016-10-08 05:16:45', '2016-10-08 05:16:45', '2016-10-08 05:16:45', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (652, 4, '2016-10-08 08:01:50', '2016-10-08 08:01:50', '2016-10-08 08:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (653, 4, '2016-10-08 11:16:50', '2016-10-08 11:16:50', '2016-10-08 11:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (654, 4, '2016-10-08 14:16:49', '2016-10-08 14:16:49', '2016-10-08 14:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (655, 4, '2016-10-08 16:16:49', '2016-10-08 16:16:49', '2016-10-08 16:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (656, 4, '2016-10-08 18:31:49', '2016-10-08 18:31:49', '2016-10-08 18:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (657, 4, '2016-10-08 21:01:48', '2016-10-08 21:01:48', '2016-10-08 21:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (658, 4, '2016-10-09 00:16:48', '2016-10-09 00:16:48', '2016-10-09 00:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (659, 4, '2016-10-09 02:46:48', '2016-10-09 02:46:48', '2016-10-09 02:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (660, 4, '2016-10-09 03:16:48', '2016-10-09 03:16:48', '2016-10-09 03:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (661, 4, '2016-10-09 07:16:51', '2016-10-09 07:16:51', '2016-10-09 07:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (662, 4, '2016-10-10 09:31:52', '2016-10-10 09:31:52', '2016-10-10 09:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (663, 4, '2016-10-10 10:46:52', '2016-10-10 10:46:52', '2016-10-10 10:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (664, 4, '2016-10-10 13:31:51', '2016-10-10 13:31:51', '2016-10-10 13:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (665, 4, '2016-10-10 16:16:51', '2016-10-10 16:16:51', '2016-10-10 16:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (666, 4, '2016-10-10 18:46:51', '2016-10-10 18:46:51', '2016-10-10 18:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (667, 4, '2016-10-10 21:31:50', '2016-10-10 21:31:50', '2016-10-10 21:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (668, 4, '2016-10-11 00:31:50', '2016-10-11 00:31:50', '2016-10-11 00:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (669, 4, '2016-10-11 01:46:50', '2016-10-11 01:46:50', '2016-10-11 01:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (670, 4, '2016-10-11 04:46:50', '2016-10-11 04:46:50', '2016-10-11 04:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (671, 4, '2016-10-12 06:31:54', '2016-10-12 06:31:54', '2016-10-12 06:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (672, 4, '2016-10-12 10:01:54', '2016-10-12 10:01:54', '2016-10-12 10:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (673, 4, '2016-10-13 08:16:51', '2016-10-13 08:16:51', '2016-10-13 08:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (674, 4, '2016-10-13 10:16:51', '2016-10-13 10:16:51', '2016-10-13 10:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (675, 4, '2016-10-13 11:46:51', '2016-10-13 11:46:51', '2016-10-13 11:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (676, 4, '2016-10-13 15:47:03', '2016-10-13 15:47:03', '2016-10-13 15:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (677, 4, '2016-10-13 18:02:03', '2016-10-13 18:02:03', '2016-10-13 18:02:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (678, 4, '2016-10-13 19:47:03', '2016-10-13 19:47:03', '2016-10-13 19:47:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (679, 4, '2016-10-13 23:32:03', '2016-10-13 23:32:03', '2016-10-13 23:32:03', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (680, 4, '2016-10-14 01:02:02', '2016-10-14 01:02:02', '2016-10-14 01:02:02', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (681, 4, '2016-10-14 04:17:02', '2016-10-14 04:17:02', '2016-10-14 04:17:02', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (682, 4, '2016-10-14 07:01:49', '2016-10-14 07:01:49', '2016-10-14 07:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (683, 4, '2016-10-14 08:46:49', '2016-10-14 08:46:49', '2016-10-14 08:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (684, 4, '2016-10-14 11:46:49', '2016-10-14 11:46:49', '2016-10-14 11:46:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (685, 4, '2016-10-14 13:31:49', '2016-10-14 13:31:49', '2016-10-14 13:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (686, 4, '2016-10-14 17:31:48', '2016-10-14 17:31:48', '2016-10-14 17:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (687, 4, '2016-10-15 06:31:52', '2016-10-15 06:31:52', '2016-10-15 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (688, 4, '2016-10-15 09:16:52', '2016-10-15 09:16:52', '2016-10-15 09:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (689, 4, '2016-10-15 11:46:52', '2016-10-15 11:46:52', '2016-10-15 11:46:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (690, 4, '2016-10-15 15:01:51', '2016-10-15 15:01:51', '2016-10-15 15:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (691, 4, '2016-10-15 17:46:51', '2016-10-15 17:46:51', '2016-10-15 17:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (692, 4, '2016-10-15 20:46:51', '2016-10-15 20:46:51', '2016-10-15 20:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (693, 4, '2016-10-15 22:01:51', '2016-10-15 22:01:51', '2016-10-15 22:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (694, 4, '2016-10-16 00:46:51', '2016-10-16 00:46:51', '2016-10-16 00:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (695, 4, '2016-10-16 03:16:51', '2016-10-16 03:16:51', '2016-10-16 03:16:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (696, 4, '2016-10-16 05:01:51', '2016-10-16 05:01:51', '2016-10-16 05:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (697, 4, '2016-10-16 08:46:48', '2016-10-16 08:46:48', '2016-10-16 08:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (698, 4, '2016-10-16 10:31:48', '2016-10-16 10:31:48', '2016-10-16 10:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (699, 4, '2016-10-16 12:46:48', '2016-10-16 12:46:48', '2016-10-16 12:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (700, 4, '2016-10-16 15:01:47', '2016-10-16 15:01:47', '2016-10-16 15:01:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (701, 4, '2016-10-16 19:46:47', '2016-10-16 19:46:47', '2016-10-16 19:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (702, 4, '2016-10-16 21:31:47', '2016-10-16 21:31:47', '2016-10-16 21:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (703, 4, '2016-10-17 00:16:47', '2016-10-17 00:16:47', '2016-10-17 00:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (704, 4, '2016-10-17 03:01:46', '2016-10-17 03:01:46', '2016-10-17 03:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (705, 4, '2016-10-17 05:31:46', '2016-10-17 05:31:46', '2016-10-17 05:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (706, 4, '2016-10-18 06:46:55', '2016-10-18 06:46:55', '2016-10-18 06:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (707, 4, '2016-10-18 09:31:55', '2016-10-18 09:31:55', '2016-10-18 09:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (708, 4, '2016-10-18 10:46:55', '2016-10-18 10:46:55', '2016-10-18 10:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (709, 4, '2016-10-18 15:31:55', '2016-10-18 15:31:55', '2016-10-18 15:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (710, 4, '2016-10-18 17:46:54', '2016-10-18 17:46:54', '2016-10-18 17:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (711, 4, '2016-10-18 19:31:54', '2016-10-18 19:31:54', '2016-10-18 19:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (712, 4, '2016-10-18 21:46:54', '2016-10-18 21:46:54', '2016-10-18 21:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (713, 4, '2016-10-19 00:46:54', '2016-10-19 00:46:54', '2016-10-19 00:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (714, 4, '2016-10-19 03:46:54', '2016-10-19 03:46:54', '2016-10-19 03:46:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (715, 4, '2016-10-19 06:46:48', '2016-10-19 06:46:48', '2016-10-19 06:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (716, 4, '2016-10-20 07:16:52', '2016-10-20 07:16:52', '2016-10-20 07:16:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (717, 4, '2016-10-20 10:01:52', '2016-10-20 10:01:52', '2016-10-20 10:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (718, 4, '2016-10-20 13:32:00', '2016-10-20 13:32:00', '2016-10-20 13:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (719, 4, '2016-10-20 16:02:00', '2016-10-20 16:02:00', '2016-10-20 16:02:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (720, 4, '2016-10-20 17:32:00', '2016-10-20 17:32:00', '2016-10-20 17:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (721, 4, '2016-10-20 20:02:00', '2016-10-20 20:02:00', '2016-10-20 20:02:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (722, 4, '2016-10-20 21:47:00', '2016-10-20 21:47:00', '2016-10-20 21:47:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (723, 4, '2016-10-21 00:32:00', '2016-10-21 00:32:00', '2016-10-21 00:32:00', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (724, 4, '2016-10-21 05:01:59', '2016-10-21 05:01:59', '2016-10-21 05:01:59', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (725, 4, '2016-10-21 07:01:50', '2016-10-21 07:01:50', '2016-10-21 07:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (726, 4, '2016-10-21 10:16:50', '2016-10-21 10:16:50', '2016-10-21 10:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (727, 4, '2016-10-21 12:31:50', '2016-10-21 12:31:50', '2016-10-21 12:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (728, 4, '2016-10-21 15:01:50', '2016-10-21 15:01:50', '2016-10-21 15:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (729, 4, '2016-10-21 16:46:50', '2016-10-21 16:46:50', '2016-10-21 16:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (730, 4, '2016-10-21 19:16:49', '2016-10-21 19:16:49', '2016-10-21 19:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (731, 4, '2016-10-21 22:31:49', '2016-10-21 22:31:49', '2016-10-21 22:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (732, 4, '2016-10-22 00:16:49', '2016-10-22 00:16:49', '2016-10-22 00:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (733, 4, '2016-10-22 03:16:49', '2016-10-22 03:16:49', '2016-10-22 03:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (734, 4, '2016-10-22 05:31:49', '2016-10-22 05:31:49', '2016-10-22 05:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (735, 4, '2016-10-22 08:16:49', '2016-10-22 08:16:49', '2016-10-22 08:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (736, 4, '2016-10-22 10:16:49', '2016-10-22 10:16:49', '2016-10-22 10:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (737, 4, '2016-10-22 14:01:49', '2016-10-22 14:01:49', '2016-10-22 14:01:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (738, 4, '2016-10-22 14:31:49', '2016-10-22 14:31:49', '2016-10-22 14:31:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (739, 4, '2016-10-22 17:31:48', '2016-10-22 17:31:48', '2016-10-22 17:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (740, 4, '2016-10-22 20:16:48', '2016-10-22 20:16:48', '2016-10-22 20:16:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (741, 4, '2016-10-22 21:46:48', '2016-10-22 21:46:48', '2016-10-22 21:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (742, 4, '2016-10-23 00:31:48', '2016-10-23 00:31:48', '2016-10-23 00:31:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (743, 4, '2016-10-23 03:01:48', '2016-10-23 03:01:48', '2016-10-23 03:01:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (744, 4, '2016-10-23 05:46:48', '2016-10-23 05:46:48', '2016-10-23 05:46:48', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (745, 4, '2016-10-23 08:46:47', '2016-10-23 08:46:47', '2016-10-23 08:46:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (746, 4, '2016-10-23 11:31:47', '2016-10-23 11:31:47', '2016-10-23 11:31:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (747, 4, '2016-10-23 15:16:47', '2016-10-23 15:16:47', '2016-10-23 15:16:47', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (748, 4, '2016-10-23 17:01:46', '2016-10-23 17:01:46', '2016-10-23 17:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (749, 4, '2016-10-23 19:01:46', '2016-10-23 19:01:46', '2016-10-23 19:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (750, 4, '2016-10-23 20:31:46', '2016-10-23 20:31:46', '2016-10-23 20:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (751, 4, '2016-10-23 23:16:46', '2016-10-23 23:16:46', '2016-10-23 23:16:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (752, 4, '2016-10-24 04:01:46', '2016-10-24 04:01:46', '2016-10-24 04:01:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (753, 4, '2016-10-24 05:31:46', '2016-10-24 05:31:46', '2016-10-24 05:31:46', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (754, 4, '2016-10-25 06:31:55', '2016-10-25 06:31:55', '2016-10-25 06:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (755, 4, '2016-10-25 08:31:55', '2016-10-25 08:31:55', '2016-10-25 08:31:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (756, 4, '2016-10-25 11:16:55', '2016-10-25 11:16:55', '2016-10-25 11:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (757, 4, '2016-10-25 13:46:55', '2016-10-25 13:46:55', '2016-10-25 13:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (758, 4, '2016-10-25 15:16:55', '2016-10-25 15:16:55', '2016-10-25 15:16:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (759, 4, '2016-10-25 19:31:54', '2016-10-25 19:31:54', '2016-10-25 19:31:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (760, 4, '2016-10-25 21:01:54', '2016-10-25 21:01:54', '2016-10-25 21:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (761, 4, '2016-10-25 23:01:54', '2016-10-25 23:01:54', '2016-10-25 23:01:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (762, 4, '2016-10-26 01:16:54', '2016-10-26 01:16:54', '2016-10-26 01:16:54', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (763, 4, '2016-10-26 04:16:53', '2016-10-26 04:16:53', '2016-10-26 04:16:53', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (764, 4, '2016-10-27 06:31:56', '2016-10-27 06:31:56', '2016-10-27 06:31:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (765, 4, '2016-10-27 09:16:56', '2016-10-27 09:16:56', '2016-10-27 09:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (766, 4, '2016-10-27 10:46:56', '2016-10-27 10:46:56', '2016-10-27 10:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (767, 4, '2016-10-27 14:47:05', '2016-10-27 14:47:05', '2016-10-27 14:47:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (768, 4, '2016-10-27 16:47:05', '2016-10-27 16:47:05', '2016-10-27 16:47:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (769, 4, '2016-10-27 18:02:05', '2016-10-27 18:02:05', '2016-10-27 18:02:05', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (770, 4, '2016-10-27 21:02:04', '2016-10-27 21:02:04', '2016-10-27 21:02:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (771, 4, '2016-10-27 22:47:04', '2016-10-27 22:47:04', '2016-10-27 22:47:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (772, 4, '2016-10-28 03:17:04', '2016-10-28 03:17:04', '2016-10-28 03:17:04', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (773, 4, '2016-10-28 06:16:49', '2016-10-28 06:16:49', '2016-10-28 06:16:49', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (774, 4, '2016-10-29 08:46:57', '2016-10-29 08:46:57', '2016-10-29 08:46:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (775, 4, '2016-10-29 10:31:57', '2016-10-29 10:31:57', '2016-10-29 10:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (776, 4, '2016-10-29 12:46:57', '2016-10-29 12:46:57', '2016-10-29 12:46:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (777, 4, '2016-10-29 14:31:57', '2016-10-29 14:31:57', '2016-10-29 14:31:57', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (778, 4, '2016-10-29 16:46:56', '2016-10-29 16:46:56', '2016-10-29 16:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (779, 4, '2016-10-29 19:46:56', '2016-10-29 19:46:56', '2016-10-29 19:46:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (780, 4, '2016-10-29 22:16:56', '2016-10-29 22:16:56', '2016-10-29 22:16:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (781, 4, '2016-10-30 01:01:56', '2016-10-30 01:01:56', '2016-10-30 01:01:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (782, 4, '2016-10-30 03:01:56', '2016-10-30 03:01:56', '2016-10-30 03:01:56', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (783, 4, '2016-10-30 05:46:55', '2016-10-30 05:46:55', '2016-10-30 05:46:55', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (784, 4, '2016-10-30 09:46:51', '2016-10-30 09:46:51', '2016-10-30 09:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (785, 4, '2016-10-30 11:46:51', '2016-10-30 11:46:51', '2016-10-30 11:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (786, 4, '2016-10-30 13:46:51', '2016-10-30 13:46:51', '2016-10-30 13:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (787, 4, '2016-10-30 16:01:51', '2016-10-30 16:01:51', '2016-10-30 16:01:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (788, 4, '2016-10-30 18:46:50', '2016-10-30 18:46:50', '2016-10-30 18:46:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (789, 4, '2016-10-30 22:01:50', '2016-10-30 22:01:50', '2016-10-30 22:01:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (790, 4, '2016-10-31 00:16:50', '2016-10-31 00:16:50', '2016-10-31 00:16:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (791, 4, '2016-10-31 03:31:50', '2016-10-31 03:31:50', '2016-10-31 03:31:50', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (792, 4, '2016-10-31 06:31:52', '2016-10-31 06:31:52', '2016-10-31 06:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (793, 4, '2016-10-31 07:31:52', '2016-10-31 07:31:52', '2016-10-31 07:31:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (794, 4, '2016-10-31 11:01:52', '2016-10-31 11:01:52', '2016-10-31 11:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (795, 4, '2016-10-31 13:01:52', '2016-10-31 13:01:52', '2016-10-31 13:01:52', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (796, 4, '2016-10-31 16:46:51', '2016-10-31 16:46:51', '2016-10-31 16:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (797, 4, '2016-10-31 18:46:51', '2016-10-31 18:46:51', '2016-10-31 18:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (798, 4, '2016-10-31 20:31:51', '2016-10-31 20:31:51', '2016-10-31 20:31:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (799, 4, '2016-10-31 22:46:51', '2016-10-31 22:46:51', '2016-10-31 22:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);
INSERT INTO observation VALUES (800, 4, '2016-11-01 00:46:51', '2016-11-01 00:46:51', '2016-11-01 00:46:51', 'F', NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, 3);


--
-- TOC entry 3976 (class 0 OID 20620)
-- Dependencies: 219
-- Data for Name: observationconstellation; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO observationconstellation VALUES (1, 1, 1, 1, 1, 'F', 'F');
INSERT INTO observationconstellation VALUES (4, 4, 1, 1, 1, 'F', 'F');
INSERT INTO observationconstellation VALUES (3, 3, 1, 1, 1, 'F', 'F');
INSERT INTO observationconstellation VALUES (2, 2, 1, 1, 1, 'F', 'F');


--
-- TOC entry 4181 (class 0 OID 0)
-- Dependencies: 242
-- Name: observationconstellationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observationconstellationid_seq', 4, true);


--
-- TOC entry 3977 (class 0 OID 20629)
-- Dependencies: 220
-- Data for Name: observationhasoffering; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO observationhasoffering VALUES (1, 1);
INSERT INTO observationhasoffering VALUES (2, 1);
INSERT INTO observationhasoffering VALUES (3, 1);
INSERT INTO observationhasoffering VALUES (4, 1);
INSERT INTO observationhasoffering VALUES (5, 1);
INSERT INTO observationhasoffering VALUES (6, 1);
INSERT INTO observationhasoffering VALUES (7, 1);
INSERT INTO observationhasoffering VALUES (8, 1);
INSERT INTO observationhasoffering VALUES (9, 1);
INSERT INTO observationhasoffering VALUES (10, 1);
INSERT INTO observationhasoffering VALUES (11, 1);
INSERT INTO observationhasoffering VALUES (12, 1);
INSERT INTO observationhasoffering VALUES (13, 1);
INSERT INTO observationhasoffering VALUES (14, 1);
INSERT INTO observationhasoffering VALUES (15, 1);
INSERT INTO observationhasoffering VALUES (16, 1);
INSERT INTO observationhasoffering VALUES (17, 1);
INSERT INTO observationhasoffering VALUES (18, 1);
INSERT INTO observationhasoffering VALUES (19, 1);
INSERT INTO observationhasoffering VALUES (20, 1);
INSERT INTO observationhasoffering VALUES (21, 1);
INSERT INTO observationhasoffering VALUES (22, 1);
INSERT INTO observationhasoffering VALUES (23, 1);
INSERT INTO observationhasoffering VALUES (24, 1);
INSERT INTO observationhasoffering VALUES (25, 1);
INSERT INTO observationhasoffering VALUES (26, 1);
INSERT INTO observationhasoffering VALUES (27, 1);
INSERT INTO observationhasoffering VALUES (28, 1);
INSERT INTO observationhasoffering VALUES (29, 1);
INSERT INTO observationhasoffering VALUES (30, 1);
INSERT INTO observationhasoffering VALUES (31, 1);
INSERT INTO observationhasoffering VALUES (32, 1);
INSERT INTO observationhasoffering VALUES (33, 1);
INSERT INTO observationhasoffering VALUES (34, 1);
INSERT INTO observationhasoffering VALUES (35, 1);
INSERT INTO observationhasoffering VALUES (36, 1);
INSERT INTO observationhasoffering VALUES (37, 1);
INSERT INTO observationhasoffering VALUES (38, 1);
INSERT INTO observationhasoffering VALUES (39, 1);
INSERT INTO observationhasoffering VALUES (40, 1);
INSERT INTO observationhasoffering VALUES (41, 1);
INSERT INTO observationhasoffering VALUES (42, 1);
INSERT INTO observationhasoffering VALUES (43, 1);
INSERT INTO observationhasoffering VALUES (44, 1);
INSERT INTO observationhasoffering VALUES (45, 1);
INSERT INTO observationhasoffering VALUES (46, 1);
INSERT INTO observationhasoffering VALUES (47, 1);
INSERT INTO observationhasoffering VALUES (48, 1);
INSERT INTO observationhasoffering VALUES (49, 1);
INSERT INTO observationhasoffering VALUES (50, 1);
INSERT INTO observationhasoffering VALUES (51, 1);
INSERT INTO observationhasoffering VALUES (52, 1);
INSERT INTO observationhasoffering VALUES (53, 1);
INSERT INTO observationhasoffering VALUES (54, 1);
INSERT INTO observationhasoffering VALUES (55, 1);
INSERT INTO observationhasoffering VALUES (56, 1);
INSERT INTO observationhasoffering VALUES (57, 1);
INSERT INTO observationhasoffering VALUES (58, 1);
INSERT INTO observationhasoffering VALUES (59, 1);
INSERT INTO observationhasoffering VALUES (60, 1);
INSERT INTO observationhasoffering VALUES (61, 1);
INSERT INTO observationhasoffering VALUES (62, 1);
INSERT INTO observationhasoffering VALUES (63, 1);
INSERT INTO observationhasoffering VALUES (64, 1);
INSERT INTO observationhasoffering VALUES (65, 1);
INSERT INTO observationhasoffering VALUES (66, 1);
INSERT INTO observationhasoffering VALUES (67, 1);
INSERT INTO observationhasoffering VALUES (68, 1);
INSERT INTO observationhasoffering VALUES (69, 1);
INSERT INTO observationhasoffering VALUES (70, 1);
INSERT INTO observationhasoffering VALUES (71, 1);
INSERT INTO observationhasoffering VALUES (72, 1);
INSERT INTO observationhasoffering VALUES (73, 1);
INSERT INTO observationhasoffering VALUES (74, 1);
INSERT INTO observationhasoffering VALUES (75, 1);
INSERT INTO observationhasoffering VALUES (76, 1);
INSERT INTO observationhasoffering VALUES (77, 1);
INSERT INTO observationhasoffering VALUES (78, 1);
INSERT INTO observationhasoffering VALUES (79, 1);
INSERT INTO observationhasoffering VALUES (80, 1);
INSERT INTO observationhasoffering VALUES (81, 1);
INSERT INTO observationhasoffering VALUES (82, 1);
INSERT INTO observationhasoffering VALUES (83, 1);
INSERT INTO observationhasoffering VALUES (84, 1);
INSERT INTO observationhasoffering VALUES (85, 1);
INSERT INTO observationhasoffering VALUES (86, 1);
INSERT INTO observationhasoffering VALUES (87, 1);
INSERT INTO observationhasoffering VALUES (88, 1);
INSERT INTO observationhasoffering VALUES (89, 1);
INSERT INTO observationhasoffering VALUES (90, 1);
INSERT INTO observationhasoffering VALUES (91, 1);
INSERT INTO observationhasoffering VALUES (92, 1);
INSERT INTO observationhasoffering VALUES (93, 1);
INSERT INTO observationhasoffering VALUES (94, 1);
INSERT INTO observationhasoffering VALUES (95, 1);
INSERT INTO observationhasoffering VALUES (96, 1);
INSERT INTO observationhasoffering VALUES (97, 1);
INSERT INTO observationhasoffering VALUES (98, 1);
INSERT INTO observationhasoffering VALUES (99, 1);
INSERT INTO observationhasoffering VALUES (100, 1);
INSERT INTO observationhasoffering VALUES (101, 1);
INSERT INTO observationhasoffering VALUES (102, 1);
INSERT INTO observationhasoffering VALUES (103, 1);
INSERT INTO observationhasoffering VALUES (104, 1);
INSERT INTO observationhasoffering VALUES (105, 1);
INSERT INTO observationhasoffering VALUES (106, 1);
INSERT INTO observationhasoffering VALUES (107, 1);
INSERT INTO observationhasoffering VALUES (108, 1);
INSERT INTO observationhasoffering VALUES (109, 1);
INSERT INTO observationhasoffering VALUES (110, 1);
INSERT INTO observationhasoffering VALUES (111, 1);
INSERT INTO observationhasoffering VALUES (112, 1);
INSERT INTO observationhasoffering VALUES (113, 1);
INSERT INTO observationhasoffering VALUES (114, 1);
INSERT INTO observationhasoffering VALUES (115, 1);
INSERT INTO observationhasoffering VALUES (116, 1);
INSERT INTO observationhasoffering VALUES (117, 1);
INSERT INTO observationhasoffering VALUES (118, 1);
INSERT INTO observationhasoffering VALUES (119, 1);
INSERT INTO observationhasoffering VALUES (120, 1);
INSERT INTO observationhasoffering VALUES (121, 1);
INSERT INTO observationhasoffering VALUES (122, 1);
INSERT INTO observationhasoffering VALUES (123, 1);
INSERT INTO observationhasoffering VALUES (124, 1);
INSERT INTO observationhasoffering VALUES (125, 1);
INSERT INTO observationhasoffering VALUES (126, 1);
INSERT INTO observationhasoffering VALUES (127, 1);
INSERT INTO observationhasoffering VALUES (128, 1);
INSERT INTO observationhasoffering VALUES (129, 1);
INSERT INTO observationhasoffering VALUES (130, 1);
INSERT INTO observationhasoffering VALUES (131, 1);
INSERT INTO observationhasoffering VALUES (132, 1);
INSERT INTO observationhasoffering VALUES (133, 1);
INSERT INTO observationhasoffering VALUES (134, 1);
INSERT INTO observationhasoffering VALUES (135, 1);
INSERT INTO observationhasoffering VALUES (136, 1);
INSERT INTO observationhasoffering VALUES (137, 1);
INSERT INTO observationhasoffering VALUES (138, 1);
INSERT INTO observationhasoffering VALUES (139, 1);
INSERT INTO observationhasoffering VALUES (140, 1);
INSERT INTO observationhasoffering VALUES (141, 1);
INSERT INTO observationhasoffering VALUES (142, 1);
INSERT INTO observationhasoffering VALUES (143, 1);
INSERT INTO observationhasoffering VALUES (144, 1);
INSERT INTO observationhasoffering VALUES (145, 1);
INSERT INTO observationhasoffering VALUES (146, 1);
INSERT INTO observationhasoffering VALUES (147, 1);
INSERT INTO observationhasoffering VALUES (148, 1);
INSERT INTO observationhasoffering VALUES (149, 1);
INSERT INTO observationhasoffering VALUES (150, 1);
INSERT INTO observationhasoffering VALUES (151, 1);
INSERT INTO observationhasoffering VALUES (152, 1);
INSERT INTO observationhasoffering VALUES (153, 1);
INSERT INTO observationhasoffering VALUES (154, 1);
INSERT INTO observationhasoffering VALUES (155, 1);
INSERT INTO observationhasoffering VALUES (156, 1);
INSERT INTO observationhasoffering VALUES (157, 1);
INSERT INTO observationhasoffering VALUES (158, 1);
INSERT INTO observationhasoffering VALUES (159, 1);
INSERT INTO observationhasoffering VALUES (160, 1);
INSERT INTO observationhasoffering VALUES (161, 1);
INSERT INTO observationhasoffering VALUES (162, 1);
INSERT INTO observationhasoffering VALUES (163, 1);
INSERT INTO observationhasoffering VALUES (164, 1);
INSERT INTO observationhasoffering VALUES (165, 1);
INSERT INTO observationhasoffering VALUES (166, 1);
INSERT INTO observationhasoffering VALUES (167, 1);
INSERT INTO observationhasoffering VALUES (168, 1);
INSERT INTO observationhasoffering VALUES (169, 1);
INSERT INTO observationhasoffering VALUES (170, 1);
INSERT INTO observationhasoffering VALUES (171, 1);
INSERT INTO observationhasoffering VALUES (172, 1);
INSERT INTO observationhasoffering VALUES (173, 1);
INSERT INTO observationhasoffering VALUES (174, 1);
INSERT INTO observationhasoffering VALUES (175, 1);
INSERT INTO observationhasoffering VALUES (176, 1);
INSERT INTO observationhasoffering VALUES (177, 1);
INSERT INTO observationhasoffering VALUES (178, 1);
INSERT INTO observationhasoffering VALUES (179, 1);
INSERT INTO observationhasoffering VALUES (180, 1);
INSERT INTO observationhasoffering VALUES (181, 1);
INSERT INTO observationhasoffering VALUES (182, 1);
INSERT INTO observationhasoffering VALUES (183, 1);
INSERT INTO observationhasoffering VALUES (184, 1);
INSERT INTO observationhasoffering VALUES (185, 1);
INSERT INTO observationhasoffering VALUES (186, 1);
INSERT INTO observationhasoffering VALUES (187, 1);
INSERT INTO observationhasoffering VALUES (188, 1);
INSERT INTO observationhasoffering VALUES (189, 1);
INSERT INTO observationhasoffering VALUES (190, 1);
INSERT INTO observationhasoffering VALUES (191, 1);
INSERT INTO observationhasoffering VALUES (192, 1);
INSERT INTO observationhasoffering VALUES (193, 1);
INSERT INTO observationhasoffering VALUES (194, 1);
INSERT INTO observationhasoffering VALUES (195, 1);
INSERT INTO observationhasoffering VALUES (196, 1);
INSERT INTO observationhasoffering VALUES (197, 1);
INSERT INTO observationhasoffering VALUES (198, 1);
INSERT INTO observationhasoffering VALUES (199, 1);
INSERT INTO observationhasoffering VALUES (200, 1);
INSERT INTO observationhasoffering VALUES (201, 1);
INSERT INTO observationhasoffering VALUES (202, 1);
INSERT INTO observationhasoffering VALUES (203, 1);
INSERT INTO observationhasoffering VALUES (204, 1);
INSERT INTO observationhasoffering VALUES (205, 1);
INSERT INTO observationhasoffering VALUES (206, 1);
INSERT INTO observationhasoffering VALUES (207, 1);
INSERT INTO observationhasoffering VALUES (208, 1);
INSERT INTO observationhasoffering VALUES (209, 1);
INSERT INTO observationhasoffering VALUES (210, 1);
INSERT INTO observationhasoffering VALUES (211, 1);
INSERT INTO observationhasoffering VALUES (212, 1);
INSERT INTO observationhasoffering VALUES (213, 1);
INSERT INTO observationhasoffering VALUES (214, 1);
INSERT INTO observationhasoffering VALUES (215, 1);
INSERT INTO observationhasoffering VALUES (216, 1);
INSERT INTO observationhasoffering VALUES (217, 1);
INSERT INTO observationhasoffering VALUES (218, 1);
INSERT INTO observationhasoffering VALUES (219, 1);
INSERT INTO observationhasoffering VALUES (220, 1);
INSERT INTO observationhasoffering VALUES (221, 1);
INSERT INTO observationhasoffering VALUES (222, 1);
INSERT INTO observationhasoffering VALUES (223, 1);
INSERT INTO observationhasoffering VALUES (224, 1);
INSERT INTO observationhasoffering VALUES (225, 1);
INSERT INTO observationhasoffering VALUES (226, 1);
INSERT INTO observationhasoffering VALUES (227, 1);
INSERT INTO observationhasoffering VALUES (228, 1);
INSERT INTO observationhasoffering VALUES (229, 1);
INSERT INTO observationhasoffering VALUES (230, 1);
INSERT INTO observationhasoffering VALUES (231, 1);
INSERT INTO observationhasoffering VALUES (232, 1);
INSERT INTO observationhasoffering VALUES (233, 1);
INSERT INTO observationhasoffering VALUES (234, 1);
INSERT INTO observationhasoffering VALUES (235, 1);
INSERT INTO observationhasoffering VALUES (236, 1);
INSERT INTO observationhasoffering VALUES (237, 1);
INSERT INTO observationhasoffering VALUES (238, 1);
INSERT INTO observationhasoffering VALUES (239, 1);
INSERT INTO observationhasoffering VALUES (240, 1);
INSERT INTO observationhasoffering VALUES (241, 1);
INSERT INTO observationhasoffering VALUES (242, 1);
INSERT INTO observationhasoffering VALUES (243, 1);
INSERT INTO observationhasoffering VALUES (244, 1);
INSERT INTO observationhasoffering VALUES (245, 1);
INSERT INTO observationhasoffering VALUES (246, 1);
INSERT INTO observationhasoffering VALUES (247, 1);
INSERT INTO observationhasoffering VALUES (248, 1);
INSERT INTO observationhasoffering VALUES (249, 1);
INSERT INTO observationhasoffering VALUES (250, 1);
INSERT INTO observationhasoffering VALUES (251, 1);
INSERT INTO observationhasoffering VALUES (252, 1);
INSERT INTO observationhasoffering VALUES (253, 1);
INSERT INTO observationhasoffering VALUES (254, 1);
INSERT INTO observationhasoffering VALUES (255, 1);
INSERT INTO observationhasoffering VALUES (256, 1);
INSERT INTO observationhasoffering VALUES (257, 1);
INSERT INTO observationhasoffering VALUES (258, 1);
INSERT INTO observationhasoffering VALUES (259, 1);
INSERT INTO observationhasoffering VALUES (260, 1);
INSERT INTO observationhasoffering VALUES (261, 1);
INSERT INTO observationhasoffering VALUES (262, 1);
INSERT INTO observationhasoffering VALUES (263, 1);
INSERT INTO observationhasoffering VALUES (264, 1);
INSERT INTO observationhasoffering VALUES (265, 1);
INSERT INTO observationhasoffering VALUES (266, 1);
INSERT INTO observationhasoffering VALUES (267, 1);
INSERT INTO observationhasoffering VALUES (268, 1);
INSERT INTO observationhasoffering VALUES (269, 1);
INSERT INTO observationhasoffering VALUES (270, 1);
INSERT INTO observationhasoffering VALUES (271, 1);
INSERT INTO observationhasoffering VALUES (272, 1);
INSERT INTO observationhasoffering VALUES (273, 1);
INSERT INTO observationhasoffering VALUES (274, 1);
INSERT INTO observationhasoffering VALUES (275, 1);
INSERT INTO observationhasoffering VALUES (276, 1);
INSERT INTO observationhasoffering VALUES (277, 1);
INSERT INTO observationhasoffering VALUES (278, 1);
INSERT INTO observationhasoffering VALUES (279, 1);
INSERT INTO observationhasoffering VALUES (280, 1);
INSERT INTO observationhasoffering VALUES (281, 1);
INSERT INTO observationhasoffering VALUES (282, 1);
INSERT INTO observationhasoffering VALUES (283, 1);
INSERT INTO observationhasoffering VALUES (284, 1);
INSERT INTO observationhasoffering VALUES (285, 1);
INSERT INTO observationhasoffering VALUES (286, 1);
INSERT INTO observationhasoffering VALUES (287, 1);
INSERT INTO observationhasoffering VALUES (288, 1);
INSERT INTO observationhasoffering VALUES (289, 1);
INSERT INTO observationhasoffering VALUES (290, 1);
INSERT INTO observationhasoffering VALUES (291, 1);
INSERT INTO observationhasoffering VALUES (292, 1);
INSERT INTO observationhasoffering VALUES (293, 1);
INSERT INTO observationhasoffering VALUES (294, 1);
INSERT INTO observationhasoffering VALUES (295, 1);
INSERT INTO observationhasoffering VALUES (296, 1);
INSERT INTO observationhasoffering VALUES (297, 1);
INSERT INTO observationhasoffering VALUES (298, 1);
INSERT INTO observationhasoffering VALUES (299, 1);
INSERT INTO observationhasoffering VALUES (300, 1);
INSERT INTO observationhasoffering VALUES (301, 1);
INSERT INTO observationhasoffering VALUES (302, 1);
INSERT INTO observationhasoffering VALUES (303, 1);
INSERT INTO observationhasoffering VALUES (304, 1);
INSERT INTO observationhasoffering VALUES (305, 1);
INSERT INTO observationhasoffering VALUES (306, 1);
INSERT INTO observationhasoffering VALUES (307, 1);
INSERT INTO observationhasoffering VALUES (308, 1);
INSERT INTO observationhasoffering VALUES (309, 1);
INSERT INTO observationhasoffering VALUES (310, 1);
INSERT INTO observationhasoffering VALUES (311, 1);
INSERT INTO observationhasoffering VALUES (312, 1);
INSERT INTO observationhasoffering VALUES (313, 1);
INSERT INTO observationhasoffering VALUES (314, 1);
INSERT INTO observationhasoffering VALUES (315, 1);
INSERT INTO observationhasoffering VALUES (316, 1);
INSERT INTO observationhasoffering VALUES (317, 1);
INSERT INTO observationhasoffering VALUES (318, 1);
INSERT INTO observationhasoffering VALUES (319, 1);
INSERT INTO observationhasoffering VALUES (320, 1);
INSERT INTO observationhasoffering VALUES (321, 1);
INSERT INTO observationhasoffering VALUES (322, 1);
INSERT INTO observationhasoffering VALUES (323, 1);
INSERT INTO observationhasoffering VALUES (324, 1);
INSERT INTO observationhasoffering VALUES (325, 1);
INSERT INTO observationhasoffering VALUES (326, 1);
INSERT INTO observationhasoffering VALUES (327, 1);
INSERT INTO observationhasoffering VALUES (328, 1);
INSERT INTO observationhasoffering VALUES (329, 1);
INSERT INTO observationhasoffering VALUES (330, 1);
INSERT INTO observationhasoffering VALUES (331, 1);
INSERT INTO observationhasoffering VALUES (332, 1);
INSERT INTO observationhasoffering VALUES (333, 1);
INSERT INTO observationhasoffering VALUES (334, 1);
INSERT INTO observationhasoffering VALUES (335, 1);
INSERT INTO observationhasoffering VALUES (336, 1);
INSERT INTO observationhasoffering VALUES (337, 1);
INSERT INTO observationhasoffering VALUES (338, 1);
INSERT INTO observationhasoffering VALUES (339, 1);
INSERT INTO observationhasoffering VALUES (340, 1);
INSERT INTO observationhasoffering VALUES (341, 1);
INSERT INTO observationhasoffering VALUES (342, 1);
INSERT INTO observationhasoffering VALUES (343, 1);
INSERT INTO observationhasoffering VALUES (344, 1);
INSERT INTO observationhasoffering VALUES (345, 1);
INSERT INTO observationhasoffering VALUES (346, 1);
INSERT INTO observationhasoffering VALUES (347, 1);
INSERT INTO observationhasoffering VALUES (348, 1);
INSERT INTO observationhasoffering VALUES (349, 1);
INSERT INTO observationhasoffering VALUES (350, 1);
INSERT INTO observationhasoffering VALUES (351, 1);
INSERT INTO observationhasoffering VALUES (352, 1);
INSERT INTO observationhasoffering VALUES (353, 1);
INSERT INTO observationhasoffering VALUES (354, 1);
INSERT INTO observationhasoffering VALUES (355, 1);
INSERT INTO observationhasoffering VALUES (356, 1);
INSERT INTO observationhasoffering VALUES (357, 1);
INSERT INTO observationhasoffering VALUES (358, 1);
INSERT INTO observationhasoffering VALUES (359, 1);
INSERT INTO observationhasoffering VALUES (360, 1);
INSERT INTO observationhasoffering VALUES (361, 1);
INSERT INTO observationhasoffering VALUES (362, 1);
INSERT INTO observationhasoffering VALUES (363, 1);
INSERT INTO observationhasoffering VALUES (364, 1);
INSERT INTO observationhasoffering VALUES (365, 1);
INSERT INTO observationhasoffering VALUES (366, 1);
INSERT INTO observationhasoffering VALUES (367, 1);
INSERT INTO observationhasoffering VALUES (368, 1);
INSERT INTO observationhasoffering VALUES (369, 1);
INSERT INTO observationhasoffering VALUES (370, 1);
INSERT INTO observationhasoffering VALUES (371, 1);
INSERT INTO observationhasoffering VALUES (372, 1);
INSERT INTO observationhasoffering VALUES (373, 1);
INSERT INTO observationhasoffering VALUES (374, 1);
INSERT INTO observationhasoffering VALUES (375, 1);
INSERT INTO observationhasoffering VALUES (376, 1);
INSERT INTO observationhasoffering VALUES (377, 1);
INSERT INTO observationhasoffering VALUES (378, 1);
INSERT INTO observationhasoffering VALUES (379, 1);
INSERT INTO observationhasoffering VALUES (380, 1);
INSERT INTO observationhasoffering VALUES (381, 1);
INSERT INTO observationhasoffering VALUES (382, 1);
INSERT INTO observationhasoffering VALUES (383, 1);
INSERT INTO observationhasoffering VALUES (384, 1);
INSERT INTO observationhasoffering VALUES (385, 1);
INSERT INTO observationhasoffering VALUES (386, 1);
INSERT INTO observationhasoffering VALUES (387, 1);
INSERT INTO observationhasoffering VALUES (388, 1);
INSERT INTO observationhasoffering VALUES (389, 1);
INSERT INTO observationhasoffering VALUES (390, 1);
INSERT INTO observationhasoffering VALUES (391, 1);
INSERT INTO observationhasoffering VALUES (392, 1);
INSERT INTO observationhasoffering VALUES (393, 1);
INSERT INTO observationhasoffering VALUES (394, 1);
INSERT INTO observationhasoffering VALUES (395, 1);
INSERT INTO observationhasoffering VALUES (396, 1);
INSERT INTO observationhasoffering VALUES (397, 1);
INSERT INTO observationhasoffering VALUES (398, 1);
INSERT INTO observationhasoffering VALUES (399, 1);
INSERT INTO observationhasoffering VALUES (400, 1);
INSERT INTO observationhasoffering VALUES (401, 1);
INSERT INTO observationhasoffering VALUES (402, 1);
INSERT INTO observationhasoffering VALUES (403, 1);
INSERT INTO observationhasoffering VALUES (404, 1);
INSERT INTO observationhasoffering VALUES (405, 1);
INSERT INTO observationhasoffering VALUES (406, 1);
INSERT INTO observationhasoffering VALUES (407, 1);
INSERT INTO observationhasoffering VALUES (408, 1);
INSERT INTO observationhasoffering VALUES (409, 1);
INSERT INTO observationhasoffering VALUES (410, 1);
INSERT INTO observationhasoffering VALUES (411, 1);
INSERT INTO observationhasoffering VALUES (412, 1);
INSERT INTO observationhasoffering VALUES (413, 1);
INSERT INTO observationhasoffering VALUES (414, 1);
INSERT INTO observationhasoffering VALUES (415, 1);
INSERT INTO observationhasoffering VALUES (416, 1);
INSERT INTO observationhasoffering VALUES (417, 1);
INSERT INTO observationhasoffering VALUES (418, 1);
INSERT INTO observationhasoffering VALUES (419, 1);
INSERT INTO observationhasoffering VALUES (420, 1);
INSERT INTO observationhasoffering VALUES (421, 1);
INSERT INTO observationhasoffering VALUES (422, 1);
INSERT INTO observationhasoffering VALUES (423, 1);
INSERT INTO observationhasoffering VALUES (424, 1);
INSERT INTO observationhasoffering VALUES (425, 1);
INSERT INTO observationhasoffering VALUES (426, 1);
INSERT INTO observationhasoffering VALUES (427, 1);
INSERT INTO observationhasoffering VALUES (428, 1);
INSERT INTO observationhasoffering VALUES (429, 1);
INSERT INTO observationhasoffering VALUES (430, 1);
INSERT INTO observationhasoffering VALUES (431, 1);
INSERT INTO observationhasoffering VALUES (432, 1);
INSERT INTO observationhasoffering VALUES (433, 1);
INSERT INTO observationhasoffering VALUES (434, 1);
INSERT INTO observationhasoffering VALUES (435, 1);
INSERT INTO observationhasoffering VALUES (436, 1);
INSERT INTO observationhasoffering VALUES (437, 1);
INSERT INTO observationhasoffering VALUES (438, 1);
INSERT INTO observationhasoffering VALUES (439, 1);
INSERT INTO observationhasoffering VALUES (440, 1);
INSERT INTO observationhasoffering VALUES (441, 1);
INSERT INTO observationhasoffering VALUES (442, 1);
INSERT INTO observationhasoffering VALUES (443, 1);
INSERT INTO observationhasoffering VALUES (444, 1);
INSERT INTO observationhasoffering VALUES (445, 1);
INSERT INTO observationhasoffering VALUES (446, 1);
INSERT INTO observationhasoffering VALUES (447, 1);
INSERT INTO observationhasoffering VALUES (448, 1);
INSERT INTO observationhasoffering VALUES (449, 1);
INSERT INTO observationhasoffering VALUES (450, 1);
INSERT INTO observationhasoffering VALUES (451, 1);
INSERT INTO observationhasoffering VALUES (452, 1);
INSERT INTO observationhasoffering VALUES (453, 1);
INSERT INTO observationhasoffering VALUES (454, 1);
INSERT INTO observationhasoffering VALUES (455, 1);
INSERT INTO observationhasoffering VALUES (456, 1);
INSERT INTO observationhasoffering VALUES (457, 1);
INSERT INTO observationhasoffering VALUES (458, 1);
INSERT INTO observationhasoffering VALUES (459, 1);
INSERT INTO observationhasoffering VALUES (460, 1);
INSERT INTO observationhasoffering VALUES (461, 1);
INSERT INTO observationhasoffering VALUES (462, 1);
INSERT INTO observationhasoffering VALUES (463, 1);
INSERT INTO observationhasoffering VALUES (464, 1);
INSERT INTO observationhasoffering VALUES (465, 1);
INSERT INTO observationhasoffering VALUES (466, 1);
INSERT INTO observationhasoffering VALUES (467, 1);
INSERT INTO observationhasoffering VALUES (468, 1);
INSERT INTO observationhasoffering VALUES (469, 1);
INSERT INTO observationhasoffering VALUES (470, 1);
INSERT INTO observationhasoffering VALUES (471, 1);
INSERT INTO observationhasoffering VALUES (472, 1);
INSERT INTO observationhasoffering VALUES (473, 1);
INSERT INTO observationhasoffering VALUES (474, 1);
INSERT INTO observationhasoffering VALUES (475, 1);
INSERT INTO observationhasoffering VALUES (476, 1);
INSERT INTO observationhasoffering VALUES (477, 1);
INSERT INTO observationhasoffering VALUES (478, 1);
INSERT INTO observationhasoffering VALUES (479, 1);
INSERT INTO observationhasoffering VALUES (480, 1);
INSERT INTO observationhasoffering VALUES (481, 1);
INSERT INTO observationhasoffering VALUES (482, 1);
INSERT INTO observationhasoffering VALUES (483, 1);
INSERT INTO observationhasoffering VALUES (484, 1);
INSERT INTO observationhasoffering VALUES (485, 1);
INSERT INTO observationhasoffering VALUES (486, 1);
INSERT INTO observationhasoffering VALUES (487, 1);
INSERT INTO observationhasoffering VALUES (488, 1);
INSERT INTO observationhasoffering VALUES (489, 1);
INSERT INTO observationhasoffering VALUES (490, 1);
INSERT INTO observationhasoffering VALUES (491, 1);
INSERT INTO observationhasoffering VALUES (492, 1);
INSERT INTO observationhasoffering VALUES (493, 1);
INSERT INTO observationhasoffering VALUES (494, 1);
INSERT INTO observationhasoffering VALUES (495, 1);
INSERT INTO observationhasoffering VALUES (496, 1);
INSERT INTO observationhasoffering VALUES (497, 1);
INSERT INTO observationhasoffering VALUES (498, 1);
INSERT INTO observationhasoffering VALUES (499, 1);
INSERT INTO observationhasoffering VALUES (500, 1);
INSERT INTO observationhasoffering VALUES (501, 1);
INSERT INTO observationhasoffering VALUES (502, 1);
INSERT INTO observationhasoffering VALUES (503, 1);
INSERT INTO observationhasoffering VALUES (504, 1);
INSERT INTO observationhasoffering VALUES (505, 1);
INSERT INTO observationhasoffering VALUES (506, 1);
INSERT INTO observationhasoffering VALUES (507, 1);
INSERT INTO observationhasoffering VALUES (508, 1);
INSERT INTO observationhasoffering VALUES (509, 1);
INSERT INTO observationhasoffering VALUES (510, 1);
INSERT INTO observationhasoffering VALUES (511, 1);
INSERT INTO observationhasoffering VALUES (512, 1);
INSERT INTO observationhasoffering VALUES (513, 1);
INSERT INTO observationhasoffering VALUES (514, 1);
INSERT INTO observationhasoffering VALUES (515, 1);
INSERT INTO observationhasoffering VALUES (516, 1);
INSERT INTO observationhasoffering VALUES (517, 1);
INSERT INTO observationhasoffering VALUES (518, 1);
INSERT INTO observationhasoffering VALUES (519, 1);
INSERT INTO observationhasoffering VALUES (520, 1);
INSERT INTO observationhasoffering VALUES (521, 1);
INSERT INTO observationhasoffering VALUES (522, 1);
INSERT INTO observationhasoffering VALUES (523, 1);
INSERT INTO observationhasoffering VALUES (524, 1);
INSERT INTO observationhasoffering VALUES (525, 1);
INSERT INTO observationhasoffering VALUES (526, 1);
INSERT INTO observationhasoffering VALUES (527, 1);
INSERT INTO observationhasoffering VALUES (528, 1);
INSERT INTO observationhasoffering VALUES (529, 1);
INSERT INTO observationhasoffering VALUES (530, 1);
INSERT INTO observationhasoffering VALUES (531, 1);
INSERT INTO observationhasoffering VALUES (532, 1);
INSERT INTO observationhasoffering VALUES (533, 1);
INSERT INTO observationhasoffering VALUES (534, 1);
INSERT INTO observationhasoffering VALUES (535, 1);
INSERT INTO observationhasoffering VALUES (536, 1);
INSERT INTO observationhasoffering VALUES (537, 1);
INSERT INTO observationhasoffering VALUES (538, 1);
INSERT INTO observationhasoffering VALUES (539, 1);
INSERT INTO observationhasoffering VALUES (540, 1);
INSERT INTO observationhasoffering VALUES (541, 1);
INSERT INTO observationhasoffering VALUES (542, 1);
INSERT INTO observationhasoffering VALUES (543, 1);
INSERT INTO observationhasoffering VALUES (544, 1);
INSERT INTO observationhasoffering VALUES (545, 1);
INSERT INTO observationhasoffering VALUES (546, 1);
INSERT INTO observationhasoffering VALUES (547, 1);
INSERT INTO observationhasoffering VALUES (548, 1);
INSERT INTO observationhasoffering VALUES (549, 1);
INSERT INTO observationhasoffering VALUES (550, 1);
INSERT INTO observationhasoffering VALUES (551, 1);
INSERT INTO observationhasoffering VALUES (552, 1);
INSERT INTO observationhasoffering VALUES (553, 1);
INSERT INTO observationhasoffering VALUES (554, 1);
INSERT INTO observationhasoffering VALUES (555, 1);
INSERT INTO observationhasoffering VALUES (556, 1);
INSERT INTO observationhasoffering VALUES (557, 1);
INSERT INTO observationhasoffering VALUES (558, 1);
INSERT INTO observationhasoffering VALUES (559, 1);
INSERT INTO observationhasoffering VALUES (560, 1);
INSERT INTO observationhasoffering VALUES (561, 1);
INSERT INTO observationhasoffering VALUES (562, 1);
INSERT INTO observationhasoffering VALUES (563, 1);
INSERT INTO observationhasoffering VALUES (564, 1);
INSERT INTO observationhasoffering VALUES (565, 1);
INSERT INTO observationhasoffering VALUES (566, 1);
INSERT INTO observationhasoffering VALUES (567, 1);
INSERT INTO observationhasoffering VALUES (568, 1);
INSERT INTO observationhasoffering VALUES (569, 1);
INSERT INTO observationhasoffering VALUES (570, 1);
INSERT INTO observationhasoffering VALUES (571, 1);
INSERT INTO observationhasoffering VALUES (572, 1);
INSERT INTO observationhasoffering VALUES (573, 1);
INSERT INTO observationhasoffering VALUES (574, 1);
INSERT INTO observationhasoffering VALUES (575, 1);
INSERT INTO observationhasoffering VALUES (576, 1);
INSERT INTO observationhasoffering VALUES (577, 1);
INSERT INTO observationhasoffering VALUES (578, 1);
INSERT INTO observationhasoffering VALUES (579, 1);
INSERT INTO observationhasoffering VALUES (580, 1);
INSERT INTO observationhasoffering VALUES (581, 1);
INSERT INTO observationhasoffering VALUES (582, 1);
INSERT INTO observationhasoffering VALUES (583, 1);
INSERT INTO observationhasoffering VALUES (584, 1);
INSERT INTO observationhasoffering VALUES (585, 1);
INSERT INTO observationhasoffering VALUES (586, 1);
INSERT INTO observationhasoffering VALUES (587, 1);
INSERT INTO observationhasoffering VALUES (588, 1);
INSERT INTO observationhasoffering VALUES (589, 1);
INSERT INTO observationhasoffering VALUES (590, 1);
INSERT INTO observationhasoffering VALUES (591, 1);
INSERT INTO observationhasoffering VALUES (592, 1);
INSERT INTO observationhasoffering VALUES (593, 1);
INSERT INTO observationhasoffering VALUES (594, 1);
INSERT INTO observationhasoffering VALUES (595, 1);
INSERT INTO observationhasoffering VALUES (596, 1);
INSERT INTO observationhasoffering VALUES (597, 1);
INSERT INTO observationhasoffering VALUES (598, 1);
INSERT INTO observationhasoffering VALUES (599, 1);
INSERT INTO observationhasoffering VALUES (600, 1);
INSERT INTO observationhasoffering VALUES (601, 1);
INSERT INTO observationhasoffering VALUES (602, 1);
INSERT INTO observationhasoffering VALUES (603, 1);
INSERT INTO observationhasoffering VALUES (604, 1);
INSERT INTO observationhasoffering VALUES (605, 1);
INSERT INTO observationhasoffering VALUES (606, 1);
INSERT INTO observationhasoffering VALUES (607, 1);
INSERT INTO observationhasoffering VALUES (608, 1);
INSERT INTO observationhasoffering VALUES (609, 1);
INSERT INTO observationhasoffering VALUES (610, 1);
INSERT INTO observationhasoffering VALUES (611, 1);
INSERT INTO observationhasoffering VALUES (612, 1);
INSERT INTO observationhasoffering VALUES (613, 1);
INSERT INTO observationhasoffering VALUES (614, 1);
INSERT INTO observationhasoffering VALUES (615, 1);
INSERT INTO observationhasoffering VALUES (616, 1);
INSERT INTO observationhasoffering VALUES (617, 1);
INSERT INTO observationhasoffering VALUES (618, 1);
INSERT INTO observationhasoffering VALUES (619, 1);
INSERT INTO observationhasoffering VALUES (620, 1);
INSERT INTO observationhasoffering VALUES (621, 1);
INSERT INTO observationhasoffering VALUES (622, 1);
INSERT INTO observationhasoffering VALUES (623, 1);
INSERT INTO observationhasoffering VALUES (624, 1);
INSERT INTO observationhasoffering VALUES (625, 1);
INSERT INTO observationhasoffering VALUES (626, 1);
INSERT INTO observationhasoffering VALUES (627, 1);
INSERT INTO observationhasoffering VALUES (628, 1);
INSERT INTO observationhasoffering VALUES (629, 1);
INSERT INTO observationhasoffering VALUES (630, 1);
INSERT INTO observationhasoffering VALUES (631, 1);
INSERT INTO observationhasoffering VALUES (632, 1);
INSERT INTO observationhasoffering VALUES (633, 1);
INSERT INTO observationhasoffering VALUES (634, 1);
INSERT INTO observationhasoffering VALUES (635, 1);
INSERT INTO observationhasoffering VALUES (636, 1);
INSERT INTO observationhasoffering VALUES (637, 1);
INSERT INTO observationhasoffering VALUES (638, 1);
INSERT INTO observationhasoffering VALUES (639, 1);
INSERT INTO observationhasoffering VALUES (640, 1);
INSERT INTO observationhasoffering VALUES (641, 1);
INSERT INTO observationhasoffering VALUES (642, 1);
INSERT INTO observationhasoffering VALUES (643, 1);
INSERT INTO observationhasoffering VALUES (644, 1);
INSERT INTO observationhasoffering VALUES (645, 1);
INSERT INTO observationhasoffering VALUES (646, 1);
INSERT INTO observationhasoffering VALUES (647, 1);
INSERT INTO observationhasoffering VALUES (648, 1);
INSERT INTO observationhasoffering VALUES (649, 1);
INSERT INTO observationhasoffering VALUES (650, 1);
INSERT INTO observationhasoffering VALUES (651, 1);
INSERT INTO observationhasoffering VALUES (652, 1);
INSERT INTO observationhasoffering VALUES (653, 1);
INSERT INTO observationhasoffering VALUES (654, 1);
INSERT INTO observationhasoffering VALUES (655, 1);
INSERT INTO observationhasoffering VALUES (656, 1);
INSERT INTO observationhasoffering VALUES (657, 1);
INSERT INTO observationhasoffering VALUES (658, 1);
INSERT INTO observationhasoffering VALUES (659, 1);
INSERT INTO observationhasoffering VALUES (660, 1);
INSERT INTO observationhasoffering VALUES (661, 1);
INSERT INTO observationhasoffering VALUES (662, 1);
INSERT INTO observationhasoffering VALUES (663, 1);
INSERT INTO observationhasoffering VALUES (664, 1);
INSERT INTO observationhasoffering VALUES (665, 1);
INSERT INTO observationhasoffering VALUES (666, 1);
INSERT INTO observationhasoffering VALUES (667, 1);
INSERT INTO observationhasoffering VALUES (668, 1);
INSERT INTO observationhasoffering VALUES (669, 1);
INSERT INTO observationhasoffering VALUES (670, 1);
INSERT INTO observationhasoffering VALUES (671, 1);
INSERT INTO observationhasoffering VALUES (672, 1);
INSERT INTO observationhasoffering VALUES (673, 1);
INSERT INTO observationhasoffering VALUES (674, 1);
INSERT INTO observationhasoffering VALUES (675, 1);
INSERT INTO observationhasoffering VALUES (676, 1);
INSERT INTO observationhasoffering VALUES (677, 1);
INSERT INTO observationhasoffering VALUES (678, 1);
INSERT INTO observationhasoffering VALUES (679, 1);
INSERT INTO observationhasoffering VALUES (680, 1);
INSERT INTO observationhasoffering VALUES (681, 1);
INSERT INTO observationhasoffering VALUES (682, 1);
INSERT INTO observationhasoffering VALUES (683, 1);
INSERT INTO observationhasoffering VALUES (684, 1);
INSERT INTO observationhasoffering VALUES (685, 1);
INSERT INTO observationhasoffering VALUES (686, 1);
INSERT INTO observationhasoffering VALUES (687, 1);
INSERT INTO observationhasoffering VALUES (688, 1);
INSERT INTO observationhasoffering VALUES (689, 1);
INSERT INTO observationhasoffering VALUES (690, 1);
INSERT INTO observationhasoffering VALUES (691, 1);
INSERT INTO observationhasoffering VALUES (692, 1);
INSERT INTO observationhasoffering VALUES (693, 1);
INSERT INTO observationhasoffering VALUES (694, 1);
INSERT INTO observationhasoffering VALUES (695, 1);
INSERT INTO observationhasoffering VALUES (696, 1);
INSERT INTO observationhasoffering VALUES (697, 1);
INSERT INTO observationhasoffering VALUES (698, 1);
INSERT INTO observationhasoffering VALUES (699, 1);
INSERT INTO observationhasoffering VALUES (700, 1);
INSERT INTO observationhasoffering VALUES (701, 1);
INSERT INTO observationhasoffering VALUES (702, 1);
INSERT INTO observationhasoffering VALUES (703, 1);
INSERT INTO observationhasoffering VALUES (704, 1);
INSERT INTO observationhasoffering VALUES (705, 1);
INSERT INTO observationhasoffering VALUES (706, 1);
INSERT INTO observationhasoffering VALUES (707, 1);
INSERT INTO observationhasoffering VALUES (708, 1);
INSERT INTO observationhasoffering VALUES (709, 1);
INSERT INTO observationhasoffering VALUES (710, 1);
INSERT INTO observationhasoffering VALUES (711, 1);
INSERT INTO observationhasoffering VALUES (712, 1);
INSERT INTO observationhasoffering VALUES (713, 1);
INSERT INTO observationhasoffering VALUES (714, 1);
INSERT INTO observationhasoffering VALUES (715, 1);
INSERT INTO observationhasoffering VALUES (716, 1);
INSERT INTO observationhasoffering VALUES (717, 1);
INSERT INTO observationhasoffering VALUES (718, 1);
INSERT INTO observationhasoffering VALUES (719, 1);
INSERT INTO observationhasoffering VALUES (720, 1);
INSERT INTO observationhasoffering VALUES (721, 1);
INSERT INTO observationhasoffering VALUES (722, 1);
INSERT INTO observationhasoffering VALUES (723, 1);
INSERT INTO observationhasoffering VALUES (724, 1);
INSERT INTO observationhasoffering VALUES (725, 1);
INSERT INTO observationhasoffering VALUES (726, 1);
INSERT INTO observationhasoffering VALUES (727, 1);
INSERT INTO observationhasoffering VALUES (728, 1);
INSERT INTO observationhasoffering VALUES (729, 1);
INSERT INTO observationhasoffering VALUES (730, 1);
INSERT INTO observationhasoffering VALUES (731, 1);
INSERT INTO observationhasoffering VALUES (732, 1);
INSERT INTO observationhasoffering VALUES (733, 1);
INSERT INTO observationhasoffering VALUES (734, 1);
INSERT INTO observationhasoffering VALUES (735, 1);
INSERT INTO observationhasoffering VALUES (736, 1);
INSERT INTO observationhasoffering VALUES (737, 1);
INSERT INTO observationhasoffering VALUES (738, 1);
INSERT INTO observationhasoffering VALUES (739, 1);
INSERT INTO observationhasoffering VALUES (740, 1);
INSERT INTO observationhasoffering VALUES (741, 1);
INSERT INTO observationhasoffering VALUES (742, 1);
INSERT INTO observationhasoffering VALUES (743, 1);
INSERT INTO observationhasoffering VALUES (744, 1);
INSERT INTO observationhasoffering VALUES (745, 1);
INSERT INTO observationhasoffering VALUES (746, 1);
INSERT INTO observationhasoffering VALUES (747, 1);
INSERT INTO observationhasoffering VALUES (748, 1);
INSERT INTO observationhasoffering VALUES (749, 1);
INSERT INTO observationhasoffering VALUES (750, 1);
INSERT INTO observationhasoffering VALUES (751, 1);
INSERT INTO observationhasoffering VALUES (752, 1);
INSERT INTO observationhasoffering VALUES (753, 1);
INSERT INTO observationhasoffering VALUES (754, 1);
INSERT INTO observationhasoffering VALUES (755, 1);
INSERT INTO observationhasoffering VALUES (756, 1);
INSERT INTO observationhasoffering VALUES (757, 1);
INSERT INTO observationhasoffering VALUES (758, 1);
INSERT INTO observationhasoffering VALUES (759, 1);
INSERT INTO observationhasoffering VALUES (760, 1);
INSERT INTO observationhasoffering VALUES (761, 1);
INSERT INTO observationhasoffering VALUES (762, 1);
INSERT INTO observationhasoffering VALUES (763, 1);
INSERT INTO observationhasoffering VALUES (764, 1);
INSERT INTO observationhasoffering VALUES (765, 1);
INSERT INTO observationhasoffering VALUES (766, 1);
INSERT INTO observationhasoffering VALUES (767, 1);
INSERT INTO observationhasoffering VALUES (768, 1);
INSERT INTO observationhasoffering VALUES (769, 1);
INSERT INTO observationhasoffering VALUES (770, 1);
INSERT INTO observationhasoffering VALUES (771, 1);
INSERT INTO observationhasoffering VALUES (772, 1);
INSERT INTO observationhasoffering VALUES (773, 1);
INSERT INTO observationhasoffering VALUES (774, 1);
INSERT INTO observationhasoffering VALUES (775, 1);
INSERT INTO observationhasoffering VALUES (776, 1);
INSERT INTO observationhasoffering VALUES (777, 1);
INSERT INTO observationhasoffering VALUES (778, 1);
INSERT INTO observationhasoffering VALUES (779, 1);
INSERT INTO observationhasoffering VALUES (780, 1);
INSERT INTO observationhasoffering VALUES (781, 1);
INSERT INTO observationhasoffering VALUES (782, 1);
INSERT INTO observationhasoffering VALUES (783, 1);
INSERT INTO observationhasoffering VALUES (784, 1);
INSERT INTO observationhasoffering VALUES (785, 1);
INSERT INTO observationhasoffering VALUES (786, 1);
INSERT INTO observationhasoffering VALUES (787, 1);
INSERT INTO observationhasoffering VALUES (788, 1);
INSERT INTO observationhasoffering VALUES (789, 1);
INSERT INTO observationhasoffering VALUES (790, 1);
INSERT INTO observationhasoffering VALUES (791, 1);
INSERT INTO observationhasoffering VALUES (792, 1);
INSERT INTO observationhasoffering VALUES (793, 1);
INSERT INTO observationhasoffering VALUES (794, 1);
INSERT INTO observationhasoffering VALUES (795, 1);
INSERT INTO observationhasoffering VALUES (796, 1);
INSERT INTO observationhasoffering VALUES (797, 1);
INSERT INTO observationhasoffering VALUES (798, 1);
INSERT INTO observationhasoffering VALUES (799, 1);
INSERT INTO observationhasoffering VALUES (800, 1);


--
-- TOC entry 4182 (class 0 OID 0)
-- Dependencies: 243
-- Name: observationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observationid_seq', 800, true);


--
-- TOC entry 3978 (class 0 OID 20634)
-- Dependencies: 221
-- Data for Name: observationtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO observationtype VALUES (1, 'http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement');


--
-- TOC entry 4183 (class 0 OID 0)
-- Dependencies: 244
-- Name: observationtypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('observationtypeid_seq', 1, true);


--
-- TOC entry 3979 (class 0 OID 20639)
-- Dependencies: 222
-- Data for Name: offering; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO offering VALUES (1, 'T', 'wxt520', NULL, 'field_0', NULL, NULL, 'F');


--
-- TOC entry 3980 (class 0 OID 20649)
-- Dependencies: 223
-- Data for Name: offeringallowedfeaturetype; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO offeringallowedfeaturetype VALUES (1, 1);


--
-- TOC entry 3981 (class 0 OID 20654)
-- Dependencies: 224
-- Data for Name: offeringallowedobservationtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO offeringallowedobservationtype VALUES (1, 1);


--
-- TOC entry 3982 (class 0 OID 20659)
-- Dependencies: 225
-- Data for Name: offeringhasrelatedfeature; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 4184 (class 0 OID 0)
-- Dependencies: 245
-- Name: offeringid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('offeringid_seq', 1, true);


--
-- TOC entry 3983 (class 0 OID 20664)
-- Dependencies: 226
-- Data for Name: parameter; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 4185 (class 0 OID 0)
-- Dependencies: 246
-- Name: parameterid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('parameterid_seq', 1, false);


--
-- TOC entry 4186 (class 0 OID 0)
-- Dependencies: 247
-- Name: procdescformatid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('procdescformatid_seq', 1, true);


--
-- TOC entry 3962 (class 0 OID 20523)
-- Dependencies: 205
-- Data for Name: procedure; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO procedure VALUES (1, 'T', 1, 'wxt520', NULL, NULL, NULL, NULL, 'F', 'F', NULL, 'F');


--
-- TOC entry 3984 (class 0 OID 20672)
-- Dependencies: 227
-- Data for Name: proceduredescriptionformat; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO proceduredescriptionformat VALUES (1, 'http://www.opengis.net/sensorML/1.0.1');


--
-- TOC entry 4187 (class 0 OID 0)
-- Dependencies: 248
-- Name: procedureid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('procedureid_seq', 1, true);


--
-- TOC entry 3985 (class 0 OID 20677)
-- Dependencies: 228
-- Data for Name: relatedfeature; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3986 (class 0 OID 20682)
-- Dependencies: 229
-- Data for Name: relatedfeaturehasrole; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 4188 (class 0 OID 0)
-- Dependencies: 249
-- Name: relatedfeatureid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('relatedfeatureid_seq', 1, false);


--
-- TOC entry 3987 (class 0 OID 20687)
-- Dependencies: 230
-- Data for Name: relatedfeaturerole; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 4189 (class 0 OID 0)
-- Dependencies: 250
-- Name: relatedfeatureroleid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('relatedfeatureroleid_seq', 1, false);


--
-- TOC entry 3988 (class 0 OID 20692)
-- Dependencies: 231
-- Data for Name: resulttemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 4190 (class 0 OID 0)
-- Dependencies: 251
-- Name: resulttemplateid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('resulttemplateid_seq', 1, false);


--
-- TOC entry 3989 (class 0 OID 20700)
-- Dependencies: 232
-- Data for Name: sensorsystem; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3990 (class 0 OID 20705)
-- Dependencies: 233
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO series VALUES (2, 1, 4, 1, 'F', 'T', '2016-10-01 06:31:54', '2016-11-01 00:46:51', 12.5, 6.79999999999999982, 1);
INSERT INTO series VALUES (3, 1, 3, 1, 'F', 'T', '2016-10-01 06:31:54', '2016-11-01 00:46:51', 85, 90, 2);
INSERT INTO series VALUES (4, 1, 2, 1, 'F', 'T', '2016-10-01 06:31:54', '2016-11-01 00:46:51', 1003.20000000000005, 1017.5, 3);
INSERT INTO series VALUES (1, 1, 1, 1, 'F', 'T', '2016-10-01 06:31:54', '2016-11-01 00:46:51', 12.5, 6.79999999999999982, 1);


--
-- TOC entry 4191 (class 0 OID 0)
-- Dependencies: 252
-- Name: seriesid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('seriesid_seq', 4, true);


--
-- TOC entry 3649 (class 0 OID 18738)
-- Dependencies: 185
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3991 (class 0 OID 20714)
-- Dependencies: 234
-- Data for Name: swedataarrayvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3992 (class 0 OID 20722)
-- Dependencies: 235
-- Data for Name: textvalue; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3993 (class 0 OID 20730)
-- Dependencies: 236
-- Data for Name: unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO unit VALUES (1, 'degC');
INSERT INTO unit VALUES (2, '%');
INSERT INTO unit VALUES (3, 'hPa');


--
-- TOC entry 4192 (class 0 OID 0)
-- Dependencies: 253
-- Name: unitid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('unitid_seq', 3, true);


--
-- TOC entry 3994 (class 0 OID 20735)
-- Dependencies: 237
-- Data for Name: validproceduretime; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO validproceduretime VALUES (1, 1, 1, '2016-11-16 15:35:09.435', NULL, '<sml:SensorML xmlns:sml="http://www.opengis.net/sensorML/1.0.1" xmlns:gml="http://www.opengis.net/gml" xmlns:swe="http://www.opengis.net/swe/1.0.1" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.0.1">
  <sml:member>
    <sml:System>
      <sml:keywords>
        <sml:KeywordList>
          <sml:keyword>AirTemperature</sml:keyword>
          <sml:keyword>WindSpeedAverage</sml:keyword>
          <sml:keyword>WindDirectionMaximum</sml:keyword>
          <sml:keyword>HailAccumulated</sml:keyword>
          <sml:keyword>Vaisala-WXT520</sml:keyword>
          <sml:keyword>RainfallPeakIntensity</sml:keyword>
          <sml:keyword>Humidity</sml:keyword>
          <sml:keyword>HailPeakIntensity</sml:keyword>
          <sml:keyword>WindSpeedMinimum</sml:keyword>
          <sml:keyword>RainfallDuration</sml:keyword>
          <sml:keyword>wxt520</sml:keyword>
          <sml:keyword>RainfallAccumulated</sml:keyword>
          <sml:keyword>WindSpeedMaximum</sml:keyword>
          <sml:keyword>InSystemTemperature</sml:keyword>
          <sml:keyword>HailDuration</sml:keyword>
          <sml:keyword>WindDirectionMinimum</sml:keyword>
          <sml:keyword>Vaisala_WXT520</sml:keyword>
          <sml:keyword>HailIntensity</sml:keyword>
          <sml:keyword>RainfallIntensity</sml:keyword>
          <sml:keyword>52n-wxt520</sml:keyword>
          <sml:keyword>AthmosphericPressure</sml:keyword>
          <sml:keyword>WindDirectionAverage</sml:keyword>
        </sml:KeywordList>
      </sml:keywords>
      <sml:identification>
        <sml:IdentifierList>
          <sml:identifier name="uniqueID">
            <sml:Term definition="urn:ogc:def:identifier:OGC:1.0:uniqueID">
              <sml:value>wxt520</sml:value>
            </sml:Term>
          </sml:identifier>
          <sml:identifier name="longName">
            <sml:Term definition="urn:ogc:def:identifier:OGC:1.0:longName">
              <sml:value>52n-wxt520</sml:value>
            </sml:Term>
          </sml:identifier>
          <sml:identifier name="shortName">
            <sml:Term definition="urn:ogc:def:identifier:OGC:1.0:shortName">
              <sml:value>52n-wxt520</sml:value>
            </sml:Term>
          </sml:identifier>
        </sml:IdentifierList>
      </sml:identification>
      <sml:classification>
        <sml:ClassifierList>
          <sml:classifier name="intendedApplication">
            <sml:Term definition="urn:ogc:def:classifier:OGC:1.0:application">
              <sml:value>HailAccumulated, WindSpeedMinimum, AirTemperature, WindSpeedAverage, HailIntensity, RainfallAccumulated, RainfallPeakIntensity, WindSpeedMaximum, WindDirectionMaximum, Humidity, RainfallIntensity, WindDirectionMinimum, HailDuration, RainfallDuration, InSystemTemperature, AthmosphericPressure, HailPeakIntensity, WindDirectionAverage</sml:value>
            </sml:Term>
          </sml:classifier>
        </sml:ClassifierList>
      </sml:classification>
      <sml:validTime>
        <gml:TimePeriod>
          <gml:beginPosition>2015-05-18T13:42:21.149Z</gml:beginPosition>
          <gml:endPosition indeterminatePosition="unknown"/>
        </gml:TimePeriod>
      </sml:validTime>
      <sml:capabilities name="featuresOfInterest">
        <swe:DataRecord>
          <swe:field name="featureOfInterestID">
            <swe:Text definition="http://www.opengis.net/def/featureOfInterest/identifier">
              <swe:value>Vaisala-WXT520</swe:value>
            </swe:Text>
          </swe:field>
        </swe:DataRecord>
      </sml:capabilities>
      <sml:capabilities name="collectingStatus">
        <swe:DataRecord>
          <swe:field name="status">
            <swe:Boolean definition="urn:ogc:def:classifier:OGC:1.0:collectingStatus">
              <swe:value>true</swe:value>
            </swe:Boolean>
          </swe:field>
        </swe:DataRecord>
      </sml:capabilities>
      <sml:capabilities name="observedBBOX">
        <swe:DataRecord>
          <swe:field name="observedBBOX">
            <swe:Envelope definition="urn:ogc:def:property:OGC:1.0:observedBBOX" referenceFrame="4326">
              <swe:lowerCorner>
                <swe:Vector>
                  <swe:coordinate name="easting">
                    <swe:Quantity axisID="x">
                      <swe:uom code="degree"/>
                      <swe:value>7.65237522125244</swe:value>
                    </swe:Quantity>
                  </swe:coordinate>
                  <swe:coordinate name="northing">
                    <swe:Quantity axisID="y">
                      <swe:uom code="degree"/>
                      <swe:value>51.9347763061523</swe:value>
                    </swe:Quantity>
                  </swe:coordinate>
                </swe:Vector>
              </swe:lowerCorner>
              <swe:upperCorner>
                <swe:Vector>
                  <swe:coordinate name="easting">
                    <swe:Quantity axisID="x">
                      <swe:uom code="degree"/>
                      <swe:value>7.652375221252441</swe:value>
                    </swe:Quantity>
                  </swe:coordinate>
                  <swe:coordinate name="northing">
                    <swe:Quantity axisID="y">
                      <swe:uom code="degree"/>
                      <swe:value>51.934776306152344</swe:value>
                    </swe:Quantity>
                  </swe:coordinate>
                </swe:Vector>
              </swe:upperCorner>
            </swe:Envelope>
          </swe:field>
        </swe:DataRecord>
      </sml:capabilities>
      <sml:contact>
        <sml:ContactList>
          <sml:member xlink:role="Point of Contact">
            <sml:ResponsibleParty>
              <sml:individualName>Jürrens, Eike Hinderk</sml:individualName>
              <sml:organizationName>52North</sml:organizationName>
              <sml:positionName>Service Maintainer</sml:positionName>
              <sml:contactInfo>
                <sml:phone>
                  <sml:voice>+49(0)251/396 371-33</sml:voice>
                </sml:phone>
                <sml:address>
                  <sml:deliveryPoint>Martin-Luther-King-Weg 24</sml:deliveryPoint>
                  <sml:city>Münster</sml:city>
                  <sml:postalCode>48155</sml:postalCode>
                  <sml:country>Germany</sml:country>
                  <sml:electronicMailAddress>e.h.juerrens@52north.org</sml:electronicMailAddress>
                </sml:address>
                <sml:onlineResource xlink:href="http://52north.org/"/>
              </sml:contactInfo>
            </sml:ResponsibleParty>
          </sml:member>
        </sml:ContactList>
      </sml:contact>
      <sml:position name="sensorPosition">
        <swe:Position fixed="false" referenceFrame="urn:ogc:def:crs:EPSG::4326">
          <swe:location>
            <swe:Vector>
              <swe:coordinate name="northing">
                <swe:Quantity axisID="y">
                  <swe:uom code="degree"/>
                  <swe:value>51.934776306152344</swe:value>
                </swe:Quantity>
              </swe:coordinate>
              <swe:coordinate name="easting">
                <swe:Quantity axisID="x">
                  <swe:uom code="degree"/>
                  <swe:value>7.652375221252441</swe:value>
                </swe:Quantity>
              </swe:coordinate>
              <swe:coordinate name="altitude">
                <swe:Quantity axisID="z">
                  <swe:uom code="UNIT_NOT_SET"/>
                  <swe:value>-INF</swe:value>
                </swe:Quantity>
              </swe:coordinate>
            </swe:Vector>
          </swe:location>
        </swe:Position>
      </sml:position>
      <sml:inputs>
        <sml:InputList>
          <sml:input name="HailAccumulated">
            <swe:ObservableProperty definition="HailAccumulated"/>
          </sml:input>
          <sml:input name="WindSpeedMinimum">
            <swe:ObservableProperty definition="WindSpeedMinimum"/>
          </sml:input>
          <sml:input name="AirTemperature">
            <swe:ObservableProperty definition="AirTemperature"/>
          </sml:input>
          <sml:input name="WindSpeedAverage">
            <swe:ObservableProperty definition="WindSpeedAverage"/>
          </sml:input>
          <sml:input name="HailIntensity">
            <swe:ObservableProperty definition="HailIntensity"/>
          </sml:input>
          <sml:input name="RainfallAccumulated">
            <swe:ObservableProperty definition="RainfallAccumulated"/>
          </sml:input>
          <sml:input name="RainfallPeakIntensity">
            <swe:ObservableProperty definition="RainfallPeakIntensity"/>
          </sml:input>
          <sml:input name="WindSpeedMaximum">
            <swe:ObservableProperty definition="WindSpeedMaximum"/>
          </sml:input>
          <sml:input name="WindDirectionMaximum">
            <swe:ObservableProperty definition="WindDirectionMaximum"/>
          </sml:input>
          <sml:input name="Humidity">
            <swe:ObservableProperty definition="Humidity"/>
          </sml:input>
          <sml:input name="RainfallIntensity">
            <swe:ObservableProperty definition="RainfallIntensity"/>
          </sml:input>
          <sml:input name="WindDirectionMinimum">
            <swe:ObservableProperty definition="WindDirectionMinimum"/>
          </sml:input>
          <sml:input name="HailDuration">
            <swe:ObservableProperty definition="HailDuration"/>
          </sml:input>
          <sml:input name="RainfallDuration">
            <swe:ObservableProperty definition="RainfallDuration"/>
          </sml:input>
          <sml:input name="InSystemTemperature">
            <swe:ObservableProperty definition="InSystemTemperature"/>
          </sml:input>
          <sml:input name="AthmosphericPressure">
            <swe:ObservableProperty definition="AthmosphericPressure"/>
          </sml:input>
          <sml:input name="HailPeakIntensity">
            <swe:ObservableProperty definition="HailPeakIntensity"/>
          </sml:input>
          <sml:input name="WindDirectionAverage">
            <swe:ObservableProperty definition="WindDirectionAverage"/>
          </sml:input>
        </sml:InputList>
      </sml:inputs>
      <sml:outputs>
        <sml:OutputList>
          <sml:output name="HailAccumulated">
            <swe:Quantity definition="HailAccumulated">
              <swe:uom code="hits_cm-2"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="WindSpeedMinimum">
            <swe:Quantity definition="WindSpeedMinimum">
              <swe:uom code="m_s"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="AirTemperature">
            <swe:Quantity definition="AirTemperature">
              <swe:uom code="degC"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="WindSpeedAverage">
            <swe:Quantity definition="WindSpeedAverage">
              <swe:uom code="m_s"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="HailIntensity">
            <swe:Quantity definition="HailIntensity">
              <swe:uom code="hits_cm-2_h"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="RainfallAccumulated">
            <swe:Quantity definition="RainfallAccumulated">
              <swe:uom code="mm"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="RainfallPeakIntensity">
            <swe:Quantity definition="RainfallPeakIntensity">
              <swe:uom code="mm_h"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="WindSpeedMaximum">
            <swe:Quantity definition="WindSpeedMaximum">
              <swe:uom code="m_s"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="WindDirectionMaximum">
            <swe:Quantity definition="WindDirectionMaximum">
              <swe:uom code="deg"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="Humidity">
            <swe:Quantity definition="Humidity">
              <swe:uom code="%"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="RainfallIntensity">
            <swe:Quantity definition="RainfallIntensity">
              <swe:uom code="mm_h"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="WindDirectionMinimum">
            <swe:Quantity definition="WindDirectionMinimum">
              <swe:uom code="deg"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="HailDuration">
            <swe:Quantity definition="HailDuration">
              <swe:uom code="s"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="RainfallDuration">
            <swe:Quantity definition="RainfallDuration">
              <swe:uom code="s"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="InSystemTemperature">
            <swe:Quantity definition="InSystemTemperature">
              <swe:uom code="degC"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="AthmosphericPressure">
            <swe:Quantity definition="AthmosphericPressure">
              <swe:uom code="hPa"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="HailPeakIntensity">
            <swe:Quantity definition="HailPeakIntensity">
              <swe:uom code="hits_cm-2_h"/>
            </swe:Quantity>
          </sml:output>
          <sml:output name="WindDirectionAverage">
            <swe:Quantity definition="WindDirectionAverage">
              <swe:uom code="deg"/>
            </swe:Quantity>
          </sml:output>
        </sml:OutputList>
      </sml:outputs>
    </sml:System>
  </sml:member>
</sml:SensorML>');


--
-- TOC entry 4193 (class 0 OID 0)
-- Dependencies: 254
-- Name: validproceduretimeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('validproceduretimeid_seq', 1, true);


SET search_path = topology, pg_catalog;

--
-- TOC entry 3650 (class 0 OID 19918)
-- Dependencies: 200
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--



--
-- TOC entry 3651 (class 0 OID 19931)
-- Dependencies: 201
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--



SET search_path = public, pg_catalog;

--
-- TOC entry 3679 (class 2606 OID 20541)
-- Name: blobvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blobvalue
    ADD CONSTRAINT blobvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3681 (class 2606 OID 20548)
-- Name: booleanvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY booleanvalue
    ADD CONSTRAINT booleanvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3683 (class 2606 OID 20553)
-- Name: categoryvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categoryvalue
    ADD CONSTRAINT categoryvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3685 (class 2606 OID 20558)
-- Name: codespace_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY codespace
    ADD CONSTRAINT codespace_pkey PRIMARY KEY (codespaceid);


--
-- TOC entry 3687 (class 2606 OID 20746)
-- Name: codespaceuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY codespace
    ADD CONSTRAINT codespaceuk UNIQUE (codespace);


--
-- TOC entry 3689 (class 2606 OID 20563)
-- Name: compositephenomenon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compositephenomenon
    ADD CONSTRAINT compositephenomenon_pkey PRIMARY KEY (childobservablepropertyid, parentobservablepropertyid);


--
-- TOC entry 3691 (class 2606 OID 20568)
-- Name: countvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY countvalue
    ADD CONSTRAINT countvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3693 (class 2606 OID 20576)
-- Name: featureofinterest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featureofinterest_pkey PRIMARY KEY (featureofinterestid);


--
-- TOC entry 3699 (class 2606 OID 20581)
-- Name: featureofinteresttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinteresttype
    ADD CONSTRAINT featureofinteresttype_pkey PRIMARY KEY (featureofinteresttypeid);


--
-- TOC entry 3703 (class 2606 OID 20586)
-- Name: featurerelation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featurerelation
    ADD CONSTRAINT featurerelation_pkey PRIMARY KEY (childfeatureid, parentfeatureid);


--
-- TOC entry 3701 (class 2606 OID 20752)
-- Name: featuretypeuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinteresttype
    ADD CONSTRAINT featuretypeuk UNIQUE (featureofinteresttype);


--
-- TOC entry 3695 (class 2606 OID 20750)
-- Name: featureurl; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featureurl UNIQUE (url);


--
-- TOC entry 3697 (class 2606 OID 20748)
-- Name: foiidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT foiidentifieruk UNIQUE (identifier);


--
-- TOC entry 3705 (class 2606 OID 20594)
-- Name: geometryvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY geometryvalue
    ADD CONSTRAINT geometryvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3707 (class 2606 OID 20599)
-- Name: numericvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY numericvalue
    ADD CONSTRAINT numericvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3709 (class 2606 OID 20609)
-- Name: observableproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT observableproperty_pkey PRIMARY KEY (observablepropertyid);


--
-- TOC entry 3713 (class 2606 OID 20619)
-- Name: observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observation_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3726 (class 2606 OID 20628)
-- Name: observationconstellation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT observationconstellation_pkey PRIMARY KEY (observationconstellationid);


--
-- TOC entry 3730 (class 2606 OID 20633)
-- Name: observationhasoffering_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationhasoffering
    ADD CONSTRAINT observationhasoffering_pkey PRIMARY KEY (observationid, offeringid);


--
-- TOC entry 3715 (class 2606 OID 20756)
-- Name: observationidentity; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observationidentity UNIQUE (seriesid, phenomenontimestart, phenomenontimeend, resulttime);


--
-- TOC entry 3734 (class 2606 OID 20638)
-- Name: observationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationtype
    ADD CONSTRAINT observationtype_pkey PRIMARY KEY (observationtypeid);


--
-- TOC entry 3736 (class 2606 OID 20771)
-- Name: observationtypeuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationtype
    ADD CONSTRAINT observationtypeuk UNIQUE (observationtype);


--
-- TOC entry 3717 (class 2606 OID 20758)
-- Name: obsidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT obsidentifieruk UNIQUE (identifier);


--
-- TOC entry 3728 (class 2606 OID 20764)
-- Name: obsnconstellationidentity; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsnconstellationidentity UNIQUE (observablepropertyid, procedureid, offeringid);


--
-- TOC entry 3711 (class 2606 OID 20754)
-- Name: obspropidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT obspropidentifieruk UNIQUE (identifier);


--
-- TOC entry 3738 (class 2606 OID 20648)
-- Name: offering_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offering_pkey PRIMARY KEY (offeringid);


--
-- TOC entry 3742 (class 2606 OID 20653)
-- Name: offeringallowedfeaturetype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedfeaturetype
    ADD CONSTRAINT offeringallowedfeaturetype_pkey PRIMARY KEY (offeringid, featureofinteresttypeid);


--
-- TOC entry 3744 (class 2606 OID 20658)
-- Name: offeringallowedobservationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedobservationtype
    ADD CONSTRAINT offeringallowedobservationtype_pkey PRIMARY KEY (offeringid, observationtypeid);


--
-- TOC entry 3746 (class 2606 OID 20663)
-- Name: offeringhasrelatedfeature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringhasrelatedfeature
    ADD CONSTRAINT offeringhasrelatedfeature_pkey PRIMARY KEY (offeringid, relatedfeatureid);


--
-- TOC entry 3740 (class 2606 OID 20773)
-- Name: offidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offidentifieruk UNIQUE (identifier);


--
-- TOC entry 3748 (class 2606 OID 20671)
-- Name: parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY parameter
    ADD CONSTRAINT parameter_pkey PRIMARY KEY (parameterid);


--
-- TOC entry 3750 (class 2606 OID 20775)
-- Name: procdescformatuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proceduredescriptionformat
    ADD CONSTRAINT procdescformatuk UNIQUE (proceduredescriptionformat);


--
-- TOC entry 3675 (class 2606 OID 20536)
-- Name: procedure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procedure_pkey PRIMARY KEY (procedureid);


--
-- TOC entry 3752 (class 2606 OID 20676)
-- Name: proceduredescriptionformat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proceduredescriptionformat
    ADD CONSTRAINT proceduredescriptionformat_pkey PRIMARY KEY (proceduredescriptionformatid);


--
-- TOC entry 3677 (class 2606 OID 20744)
-- Name: procidentifieruk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procidentifieruk UNIQUE (identifier);


--
-- TOC entry 3754 (class 2606 OID 20681)
-- Name: relatedfeature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeature
    ADD CONSTRAINT relatedfeature_pkey PRIMARY KEY (relatedfeatureid);


--
-- TOC entry 3756 (class 2606 OID 20686)
-- Name: relatedfeaturehasrole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturehasrole
    ADD CONSTRAINT relatedfeaturehasrole_pkey PRIMARY KEY (relatedfeatureid, relatedfeatureroleid);


--
-- TOC entry 3758 (class 2606 OID 20691)
-- Name: relatedfeaturerole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturerole
    ADD CONSTRAINT relatedfeaturerole_pkey PRIMARY KEY (relatedfeatureroleid);


--
-- TOC entry 3760 (class 2606 OID 20777)
-- Name: relfeatroleuk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturerole
    ADD CONSTRAINT relfeatroleuk UNIQUE (relatedfeaturerole);


--
-- TOC entry 3764 (class 2606 OID 20699)
-- Name: resulttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplate_pkey PRIMARY KEY (resulttemplateid);


--
-- TOC entry 3768 (class 2606 OID 20704)
-- Name: sensorsystem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sensorsystem
    ADD CONSTRAINT sensorsystem_pkey PRIMARY KEY (childsensorid, parentsensorid);


--
-- TOC entry 3770 (class 2606 OID 20713)
-- Name: series_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_pkey PRIMARY KEY (seriesid);


--
-- TOC entry 3773 (class 2606 OID 20783)
-- Name: seriesidentity; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesidentity UNIQUE (featureofinterestid, observablepropertyid, procedureid);


--
-- TOC entry 3777 (class 2606 OID 20721)
-- Name: swedataarrayvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY swedataarrayvalue
    ADD CONSTRAINT swedataarrayvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3779 (class 2606 OID 20729)
-- Name: textvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY textvalue
    ADD CONSTRAINT textvalue_pkey PRIMARY KEY (observationid);


--
-- TOC entry 3781 (class 2606 OID 20734)
-- Name: unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (unitid);


--
-- TOC entry 3783 (class 2606 OID 20788)
-- Name: unituk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY unit
    ADD CONSTRAINT unituk UNIQUE (unit);


--
-- TOC entry 3785 (class 2606 OID 20742)
-- Name: validproceduretime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validproceduretime
    ADD CONSTRAINT validproceduretime_pkey PRIMARY KEY (validproceduretimeid);


--
-- TOC entry 3722 (class 1259 OID 20765)
-- Name: obsconstobspropidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsconstobspropidx ON observationconstellation USING btree (observablepropertyid);


--
-- TOC entry 3723 (class 1259 OID 20767)
-- Name: obsconstofferingidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsconstofferingidx ON observationconstellation USING btree (offeringid);


--
-- TOC entry 3724 (class 1259 OID 20766)
-- Name: obsconstprocedureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsconstprocedureidx ON observationconstellation USING btree (procedureid);


--
-- TOC entry 3731 (class 1259 OID 20768)
-- Name: obshasoffobservationidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obshasoffobservationidx ON observationhasoffering USING btree (observationid);


--
-- TOC entry 3732 (class 1259 OID 20769)
-- Name: obshasoffofferingidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obshasoffofferingidx ON observationhasoffering USING btree (offeringid);


--
-- TOC entry 3718 (class 1259 OID 20761)
-- Name: obsphentimeendidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsphentimeendidx ON observation USING btree (phenomenontimeend);


--
-- TOC entry 3719 (class 1259 OID 20760)
-- Name: obsphentimestartidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsphentimestartidx ON observation USING btree (phenomenontimestart);


--
-- TOC entry 3720 (class 1259 OID 20762)
-- Name: obsresulttimeidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsresulttimeidx ON observation USING btree (resulttime);


--
-- TOC entry 3721 (class 1259 OID 20759)
-- Name: obsseriesidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX obsseriesidx ON observation USING btree (seriesid);


--
-- TOC entry 3761 (class 1259 OID 20779)
-- Name: resulttempeobspropidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempeobspropidx ON resulttemplate USING btree (observablepropertyid);


--
-- TOC entry 3762 (class 1259 OID 20781)
-- Name: resulttempidentifieridx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempidentifieridx ON resulttemplate USING btree (identifier);


--
-- TOC entry 3765 (class 1259 OID 20778)
-- Name: resulttempofferingidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempofferingidx ON resulttemplate USING btree (offeringid);


--
-- TOC entry 3766 (class 1259 OID 20780)
-- Name: resulttempprocedureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX resulttempprocedureidx ON resulttemplate USING btree (procedureid);


--
-- TOC entry 3771 (class 1259 OID 20784)
-- Name: seriesfeatureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX seriesfeatureidx ON series USING btree (featureofinterestid);


--
-- TOC entry 3774 (class 1259 OID 20785)
-- Name: seriesobspropidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX seriesobspropidx ON series USING btree (observablepropertyid);


--
-- TOC entry 3775 (class 1259 OID 20786)
-- Name: seriesprocedureidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX seriesprocedureidx ON series USING btree (procedureid);


--
-- TOC entry 3786 (class 1259 OID 20790)
-- Name: validproceduretimeendtimeidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX validproceduretimeendtimeidx ON validproceduretime USING btree (endtime);


--
-- TOC entry 3787 (class 1259 OID 20789)
-- Name: validproceduretimestarttimeidx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX validproceduretimestarttimeidx ON validproceduretime USING btree (starttime);


--
-- TOC entry 3798 (class 2606 OID 20841)
-- Name: featurecodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featurecodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3799 (class 2606 OID 20846)
-- Name: featurecodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featurecodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3797 (class 2606 OID 20836)
-- Name: featurefeaturetypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featureofinterest
    ADD CONSTRAINT featurefeaturetypefk FOREIGN KEY (featureofinteresttypeid) REFERENCES featureofinteresttype(featureofinteresttypeid);


--
-- TOC entry 3800 (class 2606 OID 20851)
-- Name: featureofinterestchildfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featurerelation
    ADD CONSTRAINT featureofinterestchildfk FOREIGN KEY (childfeatureid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3801 (class 2606 OID 20856)
-- Name: featureofinterestparentfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featurerelation
    ADD CONSTRAINT featureofinterestparentfk FOREIGN KEY (parentfeatureid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3819 (class 2606 OID 20946)
-- Name: fk_6vvrdxvd406n48gkm706ow1pt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedfeaturetype
    ADD CONSTRAINT fk_6vvrdxvd406n48gkm706ow1pt FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3826 (class 2606 OID 20981)
-- Name: fk_6ynwkk91xe8p1uibmjt98sog3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturehasrole
    ADD CONSTRAINT fk_6ynwkk91xe8p1uibmjt98sog3 FOREIGN KEY (relatedfeatureid) REFERENCES relatedfeature(relatedfeatureid);


--
-- TOC entry 3815 (class 2606 OID 20926)
-- Name: fk_9ex7hawh3dbplkllmw5w3kvej; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationhasoffering
    ADD CONSTRAINT fk_9ex7hawh3dbplkllmw5w3kvej FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3821 (class 2606 OID 20956)
-- Name: fk_lkljeohulvu7cr26pduyp5bd0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedobservationtype
    ADD CONSTRAINT fk_lkljeohulvu7cr26pduyp5bd0 FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3807 (class 2606 OID 20886)
-- Name: obscodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT obscodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3808 (class 2606 OID 20891)
-- Name: obscodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT obscodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3812 (class 2606 OID 20911)
-- Name: obsconstobservationiypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsconstobservationiypefk FOREIGN KEY (observationtypeid) REFERENCES observationtype(observationtypeid);


--
-- TOC entry 3810 (class 2606 OID 20901)
-- Name: obsconstobspropfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsconstobspropfk FOREIGN KEY (observablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3813 (class 2606 OID 20916)
-- Name: obsconstofferingfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsconstofferingfk FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3794 (class 2606 OID 20821)
-- Name: observablepropertychildfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compositephenomenon
    ADD CONSTRAINT observablepropertychildfk FOREIGN KEY (childobservablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3795 (class 2606 OID 20826)
-- Name: observablepropertyparentfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compositephenomenon
    ADD CONSTRAINT observablepropertyparentfk FOREIGN KEY (parentobservablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3791 (class 2606 OID 20806)
-- Name: observationblobvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blobvalue
    ADD CONSTRAINT observationblobvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3792 (class 2606 OID 20811)
-- Name: observationbooleanvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY booleanvalue
    ADD CONSTRAINT observationbooleanvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3793 (class 2606 OID 20816)
-- Name: observationcategoryvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categoryvalue
    ADD CONSTRAINT observationcategoryvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3796 (class 2606 OID 20831)
-- Name: observationcountvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY countvalue
    ADD CONSTRAINT observationcountvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3802 (class 2606 OID 20861)
-- Name: observationgeometryvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY geometryvalue
    ADD CONSTRAINT observationgeometryvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3803 (class 2606 OID 20866)
-- Name: observationnumericvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY numericvalue
    ADD CONSTRAINT observationnumericvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3814 (class 2606 OID 20921)
-- Name: observationofferingfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationhasoffering
    ADD CONSTRAINT observationofferingfk FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3806 (class 2606 OID 20881)
-- Name: observationseriesfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observationseriesfk FOREIGN KEY (seriesid) REFERENCES series(seriesid);


--
-- TOC entry 3837 (class 2606 OID 21036)
-- Name: observationswedataarrayvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY swedataarrayvalue
    ADD CONSTRAINT observationswedataarrayvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3838 (class 2606 OID 21041)
-- Name: observationtextvaluefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY textvalue
    ADD CONSTRAINT observationtextvaluefk FOREIGN KEY (observationid) REFERENCES observation(observationid);


--
-- TOC entry 3809 (class 2606 OID 20896)
-- Name: observationunitfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observationunitfk FOREIGN KEY (unitid) REFERENCES unit(unitid);


--
-- TOC entry 3811 (class 2606 OID 20906)
-- Name: obsnconstprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observationconstellation
    ADD CONSTRAINT obsnconstprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3804 (class 2606 OID 20871)
-- Name: obspropcodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT obspropcodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3805 (class 2606 OID 20876)
-- Name: obspropcodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY observableproperty
    ADD CONSTRAINT obspropcodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3816 (class 2606 OID 20931)
-- Name: offcodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offcodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3817 (class 2606 OID 20936)
-- Name: offcodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offering
    ADD CONSTRAINT offcodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3818 (class 2606 OID 20941)
-- Name: offeringfeaturetypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedfeaturetype
    ADD CONSTRAINT offeringfeaturetypefk FOREIGN KEY (featureofinteresttypeid) REFERENCES featureofinteresttype(featureofinteresttypeid);


--
-- TOC entry 3820 (class 2606 OID 20951)
-- Name: offeringobservationtypefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringallowedobservationtype
    ADD CONSTRAINT offeringobservationtypefk FOREIGN KEY (observationtypeid) REFERENCES observationtype(observationtypeid);


--
-- TOC entry 3823 (class 2606 OID 20966)
-- Name: offeringrelatedfeaturefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringhasrelatedfeature
    ADD CONSTRAINT offeringrelatedfeaturefk FOREIGN KEY (relatedfeatureid) REFERENCES relatedfeature(relatedfeatureid);


--
-- TOC entry 3789 (class 2606 OID 20796)
-- Name: proccodespaceidentifierfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT proccodespaceidentifierfk FOREIGN KEY (codespace) REFERENCES codespace(codespaceid);


--
-- TOC entry 3790 (class 2606 OID 20801)
-- Name: proccodespacenamefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT proccodespacenamefk FOREIGN KEY (codespacename) REFERENCES codespace(codespaceid);


--
-- TOC entry 3831 (class 2606 OID 21006)
-- Name: procedurechildfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sensorsystem
    ADD CONSTRAINT procedurechildfk FOREIGN KEY (childsensorid) REFERENCES procedure(procedureid);


--
-- TOC entry 3832 (class 2606 OID 21011)
-- Name: procedureparenffk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sensorsystem
    ADD CONSTRAINT procedureparenffk FOREIGN KEY (parentsensorid) REFERENCES procedure(procedureid);


--
-- TOC entry 3788 (class 2606 OID 20791)
-- Name: procprocdescformatfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procprocdescformatfk FOREIGN KEY (proceduredescriptionformatid) REFERENCES proceduredescriptionformat(proceduredescriptionformatid);


--
-- TOC entry 3825 (class 2606 OID 20976)
-- Name: relatedfeatrelatedfeatrolefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeaturehasrole
    ADD CONSTRAINT relatedfeatrelatedfeatrolefk FOREIGN KEY (relatedfeatureroleid) REFERENCES relatedfeaturerole(relatedfeatureroleid);


--
-- TOC entry 3824 (class 2606 OID 20971)
-- Name: relatedfeaturefeaturefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY relatedfeature
    ADD CONSTRAINT relatedfeaturefeaturefk FOREIGN KEY (featureofinterestid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3822 (class 2606 OID 20961)
-- Name: relatedfeatureofferingfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY offeringhasrelatedfeature
    ADD CONSTRAINT relatedfeatureofferingfk FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3830 (class 2606 OID 21001)
-- Name: resulttemplatefeatureidx; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplatefeatureidx FOREIGN KEY (featureofinterestid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3828 (class 2606 OID 20991)
-- Name: resulttemplateobspropfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplateobspropfk FOREIGN KEY (observablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3827 (class 2606 OID 20986)
-- Name: resulttemplateofferingidx; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplateofferingidx FOREIGN KEY (offeringid) REFERENCES offering(offeringid);


--
-- TOC entry 3829 (class 2606 OID 20996)
-- Name: resulttemplateprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY resulttemplate
    ADD CONSTRAINT resulttemplateprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3833 (class 2606 OID 21016)
-- Name: seriesfeaturefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesfeaturefk FOREIGN KEY (featureofinterestid) REFERENCES featureofinterest(featureofinterestid);


--
-- TOC entry 3834 (class 2606 OID 21021)
-- Name: seriesobpropfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesobpropfk FOREIGN KEY (observablepropertyid) REFERENCES observableproperty(observablepropertyid);


--
-- TOC entry 3835 (class 2606 OID 21026)
-- Name: seriesprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3836 (class 2606 OID 21031)
-- Name: seriesunitfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT seriesunitfk FOREIGN KEY (unitid) REFERENCES unit(unitid);


--
-- TOC entry 3839 (class 2606 OID 21046)
-- Name: validproceduretimeprocedurefk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validproceduretime
    ADD CONSTRAINT validproceduretimeprocedurefk FOREIGN KEY (procedureid) REFERENCES procedure(procedureid);


--
-- TOC entry 3840 (class 2606 OID 21051)
-- Name: validprocprocdescformatfk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validproceduretime
    ADD CONSTRAINT validprocprocdescformatfk FOREIGN KEY (proceduredescriptionformatid) REFERENCES proceduredescriptionformat(proceduredescriptionformatid);


--
-- TOC entry 4018 (class 0 OID 0)
-- Dependencies: 8
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2016-11-16 16:41:55 CET

--
-- PostgreSQL database dump complete
--

